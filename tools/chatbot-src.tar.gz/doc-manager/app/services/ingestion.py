import uuid
import hashlib
from pathlib import Path
from fastapi import UploadFile
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader

UPLOAD_DIR = Path("/data/documents")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

class DocumentIngestionService:
    def __init__(self):
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=50,
            separators=["\n\n", "\n", ".", " ", ""],
        )

    async def process(self, file: UploadFile) -> dict:
        content = await file.read()
        doc_id = str(uuid.uuid4())
        content_hash = hashlib.sha256(content).hexdigest()

        ext = Path(file.filename).suffix.lower()
        file_path = UPLOAD_DIR / f"{doc_id}{ext}"
        file_path.write_bytes(content)

        if ext == ".pdf":
            loader = PyPDFLoader(str(file_path))
            pages = loader.load()
            full_text = "\n\n".join([p.page_content for p in pages])
        elif ext == ".txt":
            full_text = content.decode("utf-8", errors="replace")
        else:
            full_text = content.decode("utf-8", errors="replace")

        chunks = self.splitter.split_text(full_text)

        return {
            "document_id": doc_id,
            "filename": file.filename,
            "content_hash": content_hash,
            "file_size": len(content),
            "chunk_count": len(chunks),
            "status": "completed",
        }
