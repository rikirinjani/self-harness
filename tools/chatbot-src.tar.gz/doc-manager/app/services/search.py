import chromadb
from chromadb.config import Settings

class DocumentSearchService:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path="/data/chromadb",
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name="documents",
            metadata={"hnsw:space": "cosine"},
        )
        self._docs = {}

    def add_chunks(self, doc_id: str, chunks: list[str], metadatas: list[dict] = None):
        ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
        meta = metadatas or [{"doc_id": doc_id} for _ in chunks]
        self.collection.add(documents=chunks, metadatas=meta, ids=ids)
        self._docs[doc_id] = {"chunk_count": len(chunks), "status": "indexed"}

    def search(self, query: str, doc_id: str = None, top_k: int = 5) -> list[dict]:
        where = {"doc_id": doc_id} if doc_id else None
        results = self.collection.query(
            query_texts=[query],
            n_results=top_k,
            where=where,
        )
        docs = []
        for i in range(len(results["ids"][0])):
            docs.append({
                "id": results["ids"][0][i],
                "content": results["documents"][0][i],
                "score": results["distances"][0][i] if results["distances"] else 0,
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
            })
        return docs

    def list_all(self) -> list[dict]:
        return [{"id": k, **v} for k, v in self._docs.items()]

    def delete(self, doc_id: str):
        self.collection.delete(where={"doc_id": doc_id})
        self._docs.pop(doc_id, None)
