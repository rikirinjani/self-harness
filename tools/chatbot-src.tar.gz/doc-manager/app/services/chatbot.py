from app.services.search import DocumentSearchService
from openai import AsyncOpenAI

client = AsyncOpenAI(
    api_key="",  # Set via env DEEPSEEK_API_KEY
    base_url="https://api.deepseek.com/v1",
)

class DocChatbot:
    def __init__(self):
        self.search = DocumentSearchService()

    async def answer(self, question: str, doc_id: str = None, top_k: int = 5) -> dict:
        chunks = self.search.search(question, doc_id, top_k)
        context = "\n\n".join([c["content"] for c in chunks])

        if not context:
            return {"answer": "No relevant documents found.", "sources": []}

        messages = [
            {
                "role": "system",
                "content": f"You are a document Q&A assistant. Answer based solely on the provided context.\n\nContext:\n{context}",
            },
            {"role": "user", "content": question},
        ]

        resp = await client.chat.completions.create(
            model="deepseek-v4-flash",
            messages=messages,
            temperature=0.3,
            max_tokens=1024,
        )

        return {
            "answer": resp.choices[0].message.content,
            "sources": [
                {"id": c["id"], "content_preview": c["content"][:200], "score": c["score"]}
                for c in chunks
            ],
        }
