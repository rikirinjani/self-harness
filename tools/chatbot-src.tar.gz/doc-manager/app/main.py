from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
from app.services.ingestion import DocumentIngestionService
from app.services.search import DocumentSearchService
from app.services.chatbot import DocChatbot

app = FastAPI(title="Document Manager")
ingestion = DocumentIngestionService()
search = DocumentSearchService()
chatbot = DocChatbot()

class QueryRequest(BaseModel):
    document_id: str = None
    question: str
    top_k: int = 5

class QueryResponse(BaseModel):
    answer: str
    sources: list[dict]

@app.get("/health")
async def health():
    return {"status": "ok", "service": "doc-manager"}

@app.post("/documents/upload")
async def upload_document(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(400, "No file provided")
    result = await ingestion.process(file)
    return result

@app.get("/documents")
async def list_documents():
    return search.list_all()

@app.delete("/documents/{doc_id}")
async def delete_document(doc_id: str):
    search.delete(doc_id)
    return {"deleted": True}

@app.post("/query", response_model=QueryResponse)
async def query_document(req: QueryRequest):
    result = await chatbot.answer(req.question, req.document_id, req.top_k)
    return QueryResponse(**result)
