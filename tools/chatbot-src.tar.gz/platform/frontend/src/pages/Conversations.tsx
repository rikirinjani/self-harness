import { useEffect, useState } from "react";

export default function Conversations() {
  const [convs, setConvs] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/conversations").then((r) => r.json()).then(setConvs);
  }, []);

  return (
    <div>
      <h1>Conversations</h1>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 16 }}>
        <thead>
          <tr style={{ background: "#fff", textAlign: "left" }}>
            <th style={thStyle}>Channel</th>
            <th style={thStyle}>User</th>
            <th style={thStyle}>Messages</th>
            <th style={thStyle}>Status</th>
            <th style={thStyle}>Started</th>
          </tr>
        </thead>
        <tbody>
          {convs.map((c) => (
            <tr key={c.id} style={{ background: "#fff", borderBottom: "1px solid #eee" }}>
              <td style={tdStyle}>{c.channel}</td>
              <td style={tdStyle}>{c.user_name ?? c.external_user_id}</td>
              <td style={tdStyle}>{c.message_count}</td>
              <td style={tdStyle}>{c.status}</td>
              <td style={tdStyle}>{new Date(c.created_at).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const thStyle: React.CSSProperties = { padding: "12px 16px", borderBottom: "2px solid #eee", fontSize: 13, color: "#666" };
const tdStyle: React.CSSProperties = { padding: "12px 16px", fontSize: 14 };
