import { useEffect, useState } from "react";

export default function Knowledge() {
  const [entries, setEntries] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/knowledge").then((r) => r.json()).then(setEntries);
  }, []);

  return (
    <div>
      <h1>Knowledge Base</h1>
      <div style={{ marginTop: 16 }}>
        {entries.map((e) => (
          <div key={e.id} style={{ background: "#fff", padding: 16, borderRadius: 8, marginBottom: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
            <h3 style={{ margin: "0 0 8px" }}>{e.title}</h3>
            <p style={{ color: "#666", fontSize: 14, margin: 0 }}>{e.content.substring(0, 200)}...</p>
            <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
              <span style={badgeStyle}>{e.category}</span>
              <span style={badgeStyle}>{e.source}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const badgeStyle: React.CSSProperties = {
  background: "#e0e7ff",
  color: "#4338ca",
  padding: "2px 8px",
  borderRadius: 4,
  fontSize: 12,
};
