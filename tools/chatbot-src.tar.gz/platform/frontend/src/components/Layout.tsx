import { ReactNode } from "react";

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", margin: 0, fontFamily: "system-ui, sans-serif" }}>
      <nav style={{ width: 220, background: "#1a1a2e", color: "#fff", padding: 24 }}>
        <h2 style={{ fontSize: 18, marginBottom: 32 }}>Chatbot AI</h2>
        <a href="/" style={linkStyle}>Dashboard</a>
        <a href="/conversations" style={linkStyle}>Conversations</a>
        <a href="/knowledge" style={linkStyle}>Knowledge Base</a>
      </nav>
      <main style={{ flex: 1, padding: 32, background: "#f5f5f5" }}>{children}</main>
    </div>
  );
}

const linkStyle: React.CSSProperties = {
  display: "block",
  color: "#ccc",
  textDecoration: "none",
  padding: "8px 0",
  fontSize: 14,
};
