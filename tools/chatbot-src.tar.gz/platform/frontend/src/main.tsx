import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Conversations from "./pages/Conversations";
import Knowledge from "./pages/Knowledge";
import Layout from "./components/Layout";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/conversations" element={<Conversations />} />
          <Route path="/knowledge" element={<Knowledge />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  </StrictMode>
);
