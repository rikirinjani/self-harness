import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://platform-api:8000",
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
    },
  },
});
