from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app
from app.config import settings
from app.database import init_db
from app.routers import auth, conversations, knowledge

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield

app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins.split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/metrics", make_asgi_app())

app.include_router(auth.router)
app.include_router(conversations.router)
app.include_router(knowledge.router)

@app.get("/health")
async def health():
    return {"status": "ok", "app": settings.app_name}

@app.post("/webhook/conversation")
async def ingest_conversation(req: Request):
    data = await req.json()
    return {"received": True, "message": "Conversation logged"}
