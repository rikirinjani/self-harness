from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.models.conversation import Conversation, Message

router = APIRouter(prefix="/conversations", tags=["conversations"])

@router.get("")
async def list_conversations(
    channel: str = None,
    status: str = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Conversation).order_by(Conversation.created_at.desc())

    if channel:
        stmt = stmt.where(Conversation.channel == channel)
    if status:
        stmt = stmt.where(Conversation.status == status)

    stmt = stmt.offset(offset).limit(limit)
    result = await db.execute(stmt)
    return result.scalars().all()

@router.get("/{conversation_id}/messages")
async def get_messages(conversation_id: str, db: AsyncSession = Depends(get_db)):
    stmt = (
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at)
    )
    result = await db.execute(stmt)
    return result.scalars().all()

@router.get("/stats/overview")
async def conversation_stats(db: AsyncSession = Depends(get_db)):
    total = await db.execute(select(func.count(Conversation.id)))
    by_channel = await db.execute(
        select(Conversation.channel, func.count(Conversation.id))
        .group_by(Conversation.channel)
    )
    return {
        "total_conversations": total.scalar(),
        "by_channel": dict(by_channel.all()),
    }
