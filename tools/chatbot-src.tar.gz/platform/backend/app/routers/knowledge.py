from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.models.knowledge import KnowledgeBase

router = APIRouter(prefix="/knowledge", tags=["knowledge"])

class KBEntry(BaseModel):
    title: str
    content: str
    category: str = None
    tags: list[str] = []
    is_active: bool = True

@router.get("")
async def list_knowledge(category: str = None, db: AsyncSession = Depends(get_db)):
    stmt = select(KnowledgeBase).where(KnowledgeBase.is_active == True)
    if category:
        stmt = stmt.where(KnowledgeBase.category == category)
    stmt = stmt.order_by(KnowledgeBase.updated_at.desc())
    result = await db.execute(stmt)
    return result.scalars().all()

@router.post("")
async def create_knowledge(entry: KBEntry, db: AsyncSession = Depends(get_db)):
    kb = KnowledgeBase(**entry.model_dump())
    db.add(kb)
    await db.flush()
    return kb

@router.delete("/{kb_id}")
async def delete_knowledge(kb_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(KnowledgeBase).where(KnowledgeBase.id == kb_id))
    kb = result.scalar_one_or_none()
    if not kb:
        raise HTTPException(status_code=404, detail="Not found")
    await db.delete(kb)
    return {"deleted": True}
