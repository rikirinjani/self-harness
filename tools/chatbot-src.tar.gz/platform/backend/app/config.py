from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "Chatbot AI Platform"
    debug: bool = False

    database_url: str = "postgresql+asyncpg://chatbot:chatbot_secret@postgres:5432/chatbot"
    redis_url: str = "redis://redis:6379/0"

    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 1440

    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com/v1"
    llm_model: str = "deepseek-v4-flash"
    llm_temperature: float = 0.7

    minio_endpoint: str = "minio:9000"
    minio_access_key: str = "minioadmin"
    minio_secret_key: str = "minioadmin"
    minio_bucket: str = "chatbot-documents"

    platform_api_key: str = "plat-api-key-change-me"

    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    class Config:
        env_file = ".env"

settings = Settings()
