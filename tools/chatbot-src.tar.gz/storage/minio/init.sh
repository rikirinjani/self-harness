#!/bin/bash
mc alias set local http://minio:9000 ${MINIO_ROOT_USER} ${MINIO_ROOT_PASSWORD}
mc mb local/chatbot-documents --ignore-existing
mc mb local/chatbot-backups --ignore-existing
mc policy set download local/chatbot-documents
echo "MinIO buckets initialized"
