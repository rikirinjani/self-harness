# Contoh Pengetahuan

## Tentang Platform
Ini adalah platform chatbot AI multi-channel yang terintegrasi dengan WhatsApp, Telegram, Instagram, dan Facebook Messenger.

## Fitur Utama
- Multi-channel messaging bridge
- LLM-powered expert system dengan RAG
- Document management dengan vector search
- Dashboard analytics real-time

## Panduan Penggunaan
1. Tambahkan knowledge base entries melalui dashboard
2. Upload dokumen melalui Document Manager
3. Chatbot akan otomatis menggunakan RAG untuk menjawab pertanyaan
