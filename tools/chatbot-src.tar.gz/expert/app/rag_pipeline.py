import chromadb
from chromadb.config import Settings as ChromaSettings
from app.config import settings
from app.llm_provider import generate_embedding

class RAGPipeline:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=settings.chroma_persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name="knowledge_base",
            metadata={"hnsw:space": "cosine"},
        )

    def add_documents(self, texts: list[str], metadatas: list[dict], ids: list[str]):
        self.collection.add(documents=texts, metadatas=metadatas, ids=ids)

    async def search(self, query: str, top_k: int = None) -> list[dict]:
        k = top_k or settings.rag_top_k
        results = self.collection.query(query_texts=[query], n_results=k)
        docs = []
        for i in range(len(results["ids"][0])):
            docs.append({
                "id": results["ids"][0][i],
                "content": results["documents"][0][i],
                "score": results["distances"][0][i] if results["distances"] else 0,
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
            })
        return docs

    async def rag_query(self, query: str, system_prompt: str = None) -> tuple[list[dict], list[dict]]:
        context_chunks = await self.search(query)
        context = "\n\n".join([c["content"] for c in context_chunks])

        if not system_prompt:
            system_prompt = "You are a helpful AI assistant. Answer based on the provided context."

        messages = [
            {"role": "system", "content": f"{system_prompt}\n\nContext:\n{context}"},
            {"role": "user", "content": query},
        ]
        return messages, context_chunks

    def delete_document(self, doc_id: str):
        self.collection.delete(ids=[doc_id])

    def get_stats(self) -> dict:
        count = self.collection.count()
        return {"total_chunks": count}
