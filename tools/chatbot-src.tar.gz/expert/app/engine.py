import json
from app.llm_provider import chat_completion
from app.knowledge_base import KnowledgeBaseManager
from app.rag_pipeline import RAGPipeline

kb = KnowledgeBaseManager()
rag = RAGPipeline()

class ExpertEngine:
    def __init__(self):
        self.system_prompt = """You are an expert AI assistant integrated into a multi-channel chatbot platform.
You have access to a knowledge base and a RAG pipeline for retrieving relevant context.

Guidelines:
- Be concise, accurate, and helpful.
- If you don't know something, say so honestly.
- Always ground responses in the provided context when available.
- For health/medical queries, include a disclaimer to consult professionals.
- Maintain conversation context naturally."""

    async def process_message(
        self,
        message: str,
        conversation_history: list[dict] | None = None,
    ) -> dict:
        use_rag = len(message) > 10

        if use_rag:
            messages, context_chunks = await rag.rag_query(message, self.system_prompt)
        else:
            messages = [{"role": "system", "content": self.system_prompt}]
            context_chunks = []

        if conversation_history:
            for msg in conversation_history[-10:]:
                messages.append(msg)

        messages.append({"role": "user", "content": message})
        response = await chat_completion(messages)

        return {
            "response": response,
            "rag_used": use_rag,
            "context_chunks": [
                {"id": c["id"], "score": c["score"]}
                for c in context_chunks
            ] if context_chunks else [],
        }

    async def analyze_intent(self, message: str) -> dict:
        messages = [
            {"role": "system", "content": "Classify the user's intent. Return JSON with fields: intent (greeting|question|command|complaint|chitchat|unknown), confidence (0-1), topics (list), requires_kb (bool)"},
            {"role": "user", "content": message},
        ]
        result = await chat_completion(messages, model="deepseek-chat", max_tokens=300)
        try:
            return json.loads(result)
        except json.JSONDecodeError:
            return {"intent": "unknown", "confidence": 0, "topics": [], "requires_kb": False}
