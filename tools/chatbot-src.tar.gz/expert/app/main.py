from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.engine import ExpertEngine

app = FastAPI(title="Expert System")
engine = ExpertEngine()

class QueryRequest(BaseModel):
    message: str
    conversation_id: str = None
    history: list[dict] = []

class QueryResponse(BaseModel):
    response: str
    rag_used: bool
    context_chunks: list[dict]

class AnalyzeRequest(BaseModel):
    message: str

@app.get("/health")
async def health():
    return {"status": "ok", "service": "expert-system"}

@app.post("/chat", response_model=QueryResponse)
async def chat(req: QueryRequest):
    result = await engine.process_message(req.message, req.history)
    return QueryResponse(**result)

@app.post("/analyze")
async def analyze(req: AnalyzeRequest):
    result = await engine.analyze_intent(req.message)
    return {"intent": result}

@app.get("/knowledge/stats")
async def knowledge_stats():
    return {
        "files": len(kb.list_entries()),
        "categories": kb.list_categories(),
        "rag": rag.get_stats(),
    }

from app.knowledge_base import KnowledgeBaseManager as kb_mgr
from app.rag_pipeline import RAGPipeline as rag_pipeline
kb = kb_mgr()
rag = rag_pipeline()
