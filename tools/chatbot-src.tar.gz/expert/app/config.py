from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com/v1"
    llm_model: str = "deepseek-v4-flash"
    llm_temperature: float = 0.7
    embedding_model: str = "BAAI/bge-small-en-v1.5"

    chroma_persist_dir: str = "/data/chromadb"
    knowledge_dir: str = "/app/knowledge"

    rag_chunk_size: int = 500
    rag_chunk_overlap: int = 50
    rag_top_k: int = 5

    platform_api_url: str = "http://platform-api:8000"
    platform_api_key: str = "plat-api-key-change-me"

    class Config:
        env_file = ".env"

settings = Settings()
