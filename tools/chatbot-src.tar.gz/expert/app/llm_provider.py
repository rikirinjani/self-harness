from openai import AsyncOpenAI
from app.config import settings

client = AsyncOpenAI(
    api_key=settings.deepseek_api_key,
    base_url=settings.deepseek_base_url,
)

async def chat_completion(
    messages: list[dict],
    model: str = None,
    temperature: float = None,
    max_tokens: int = 2048,
) -> str:
    resp = await client.chat.completions.create(
        model=model or settings.llm_model,
        messages=messages,
        temperature=temperature or settings.llm_temperature,
        max_tokens=max_tokens,
    )
    return resp.choices[0].message.content

async def generate_embedding(text: str) -> list[float]:
    resp = await client.embeddings.create(
        model="text-embedding-ada-002",
        input=text,
    )
    return resp.data[0].embedding
