import os
from pathlib import Path
from app.config import settings

class KnowledgeBaseManager:
    def __init__(self):
        self.knowledge_dir = Path(settings.knowledge_dir)
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)

    def list_categories(self) -> list[str]:
        return [d.name for d in self.knowledge_dir.iterdir() if d.is_dir()]

    def list_entries(self, category: str = None) -> list[dict]:
        entries = []
        source = self.knowledge_dir
        if category:
            source = source / category
        if source.is_dir():
            for f in sorted(source.glob("*.md")):
                entries.append({
                    "title": f.stem,
                    "path": str(f.relative_to(self.knowledge_dir)),
                    "category": category or "general",
                })
            for f in sorted(source.glob("*.txt")):
                entries.append({
                    "title": f.stem,
                    "path": str(f.relative_to(self.knowledge_dir)),
                    "category": category or "general",
                })
        return entries

    def read_entry(self, path: str) -> str:
        full_path = self.knowledge_dir / path
        if not full_path.exists() or not full_path.is_relative_to(self.knowledge_dir):
            return ""
        return full_path.read_text(encoding="utf-8")

    def get_all_text(self) -> str:
        texts = []
        for f in self.knowledge_dir.rglob("*"):
            if f.is_file() and f.suffix in (".md", ".txt"):
                texts.append(f"--- {f.relative_to(self.knowledge_dir)} ---\n{f.read_text(encoding='utf-8')}")
        return "\n\n".join(texts)
