import http from 'http';
import express from 'express';
import { config } from './dist/config/index.js';

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

const app = express();
app.use(express.json());
const server = app.listen(config.PORT, () => console.log('[Webhook] up'));
