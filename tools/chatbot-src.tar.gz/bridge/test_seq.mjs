import http from 'http';
import express from 'express';
import { config } from './dist/config/index.js';
import { WebhookServer } from './dist/core/webhook-server.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

const webhook = new WebhookServer();

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[1] health up'));

// Wait a bit, then start webhook
setTimeout(async () => {
  console.log('[2] starting webhook...');
  await webhook.start(config.PORT);
  console.log('[3] webhook up');
  
  console.log('[4] loading KB...');
  await knowledgeBase.load();
  console.log('[5] KB up');
}, 1000);

// Periodic pings
setInterval(() => console.log('[PING] alive at', process.uptime().toFixed(0) + 's'), 5000);
