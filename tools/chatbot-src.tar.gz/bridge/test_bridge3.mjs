import http from 'http';
import { config } from './dist/config/index.js';

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

// DON'T load KB - just start the server
console.log('Server running without KB');
