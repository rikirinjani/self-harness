import { createServer } from 'http';
import { config } from './dist/config/index.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

console.log('STARTING');
const t0 = Date.now();

// Health
createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime(), t: Date.now() - t0 }));
}).listen(config.HEALTH_PORT, () => console.log('Health up after', Date.now() - t0, 'ms'));

setTimeout(async () => {
  console.log('Loading KB at', Date.now() - t0, 'ms');
  
  try {
    const kbLoad = knowledgeBase.load();
    const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('KB timeout')), 120000));
    await Promise.race([kbLoad, timeoutPromise]);
    console.log('KB loaded at', Date.now() - t0, 'ms, chunks:', knowledgeBase.chunks?.length);
  } catch (err) {
    console.error('KB error:', err.message);
  }
}, 2000);
