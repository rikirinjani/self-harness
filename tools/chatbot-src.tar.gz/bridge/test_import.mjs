import http from 'http';
import { config } from './dist/config/index.js';

// Just test the import
console.log('importing KB...');
const t0 = Date.now();
const { knowledgeBase } = await import('./dist/core/knowledge-base.js');
console.log('import took', Date.now() - t0, 'ms');

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

console.log('Server up, waiting...');
