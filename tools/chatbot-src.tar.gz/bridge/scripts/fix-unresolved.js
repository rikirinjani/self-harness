const fs = require('fs');
const p = '/Users/ptpakdefarma/chatbot/bridge/data/unanswered.jsonl';
const lines = fs.readFileSync(p, 'utf-8').trim().split('\n').filter(Boolean);
let count = 0;
const updated = lines.map(l => {
  const r = JSON.parse(l);
  if (!r.resolved) {
    r.resolved = true;
    r.answer = r.answer || '(bulk cleanup)';
    r.resolvedAt = Date.now();
    count++;
  }
  return JSON.stringify(r);
});
fs.writeFileSync(p, updated.join('\n') + '\n');
console.log(`Marked ${count} as resolved. Total: ${updated.length}`);
