import { readFileSync, readdirSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, statSync } from 'fs';
import { join, relative } from 'path';
import { execFileSync, execSync } from 'child_process';
import { tmpdir } from 'os';
import { PDFParse } from 'pdf-parse';

const ASSET_DIR = join(import.meta.dirname, '..', '..', 'asset');
const KNOWLEDGE_DIR = join(import.meta.dirname, '..', 'knowledge');
const REPLICATE_TOKEN = 'r8_KqkajGX39KVAFfMtxc0YX5Kt1YnT3r81pmTa3';
const MODEL = 'abiruyt/text-extract-ocr';
const VERSION = 'a524caeaa23495bc9edc805ab08ab5fe943afd3febed884a4f3747aa32e9cd61';

function scanFiles(dir) {
  if (!statSync(dir, { throwIfNoEntry: false })?.isDirectory()) return [];
  const result = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, e.name);
    if (e.isDirectory()) result.push(...scanFiles(full));
    else if (e.name.endsWith('.pdf')) result.push({ path: full, label: relative(ASSET_DIR, full) });
  }
  return result;
}

function shouldOCR(text) {
  const words = text.split(/\s+/).filter(Boolean).length;
  const markers = (text.match(/--\s*\d+\s+of\s+\d+\s*--/g) || []).length;
  return words > 0 && (words < 100 || markers > words * 0.3);
}

function resolveBin(name) {
  try {
    return execSync(`where ${name}`, { encoding: 'utf-8' }).trim().split('\n')[0].trim() || name;
  } catch { return name; }
}

async function extractText(fp) {
  const buf = new Uint8Array(readFileSync(fp));
  const parser = new PDFParse(buf);
  const r = await parser.getText();
  return r.text || '';
}

async function ocrPageReplicate(imgPath) {
  const img = readFileSync(imgPath);
  const b64 = img.toString('base64');
  const dataUri = 'data:image/png;base64,' + b64;

  let pollUrl = null;
  for (let retry = 0; retry < 5; retry++) {
    const r = await fetch(`https://api.replicate.com/v1/models/${MODEL}/versions/${VERSION}/predictions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${REPLICATE_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ input: { image: dataUri } }),
    });
    const d = await r.json();
    if (d.urls?.get) { pollUrl = d; break; }
    if (r.status === 429) {
      const wait = (d.retry_after || 10) * 1000;
      console.log(`\n  Rate limited, waiting ${wait/1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      continue;
    }
    throw new Error('Prediction failed: ' + JSON.stringify(d));
  }
  if (!pollUrl) throw new Error('Max retries exhausted');

  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 2000));
    const r2 = await fetch(pollUrl.urls.get, { headers: { Authorization: `Bearer ${REPLICATE_TOKEN}` } });
    const d2 = await r2.json();
    if (d2.status === 'succeeded') return String(d2.output || '');
    if (d2.status === 'failed') throw new Error('Replicate failed: ' + d2.error);
  }
  throw new Error('Timed out');
}

async function ocrPDFviaReplicate(fp) {
  const tmp = mkdtempSync(join(tmpdir(), 'repl-'));
  try {
    const bin = resolveBin('pdftoppm');
    execFileSync(bin, ['-png', '-r', '200', fp, join(tmp, 'p')], { timeout: 120000 });
    const pages = readdirSync(tmp).filter(f => f.endsWith('.png')).sort().map(f => join(tmp, f));
    if (!pages.length) return null;

    const texts = [];
    for (let i = 0; i < pages.length; i++) {
      if (i > 0) await new Promise(r => setTimeout(r, 10000)); // rate limit: 6/min
      const text = await ocrPageReplicate(pages[i]);
      texts.push(text.trim());
      const pct = ((i + 1) / pages.length * 100).toFixed(0);
      process.stdout.write(`\r  Page ${i + 1}/${pages.length} (${pct}%)`);
    }
    console.log();
    return texts.join('\n\n');
  } finally {
    try { rmSync(tmp, { recursive: true, force: true }); } catch {}
  }
}

async function main() {
  mkdirSync(KNOWLEDGE_DIR, { recursive: true });
  const files = scanFiles(ASSET_DIR);
  console.log(`Scanning ${files.length} PDFs...`);

  const needOCR = [];
  for (const f of files) {
    const text = await extractText(f.path);
    if (shouldOCR(text)) needOCR.push(f);
  }
  console.log(`Found ${needOCR.length} image-based PDFs needing OCR:`);
  needOCR.forEach(f => console.log(`  ${f.label}`));

  let done = 0;
  for (const f of needOCR) {
    const safeName = f.label.replace(/[<>:"/\\|?*]/g, '_').replace(/&/g, 'and').replace(/\.pdf$/i, '');
    const outPath = join(KNOWLEDGE_DIR, safeName + '.md');
    if (statSync(outPath, { throwIfNoEntry: false })) {
      console.log(`\nSKIP ${f.label} (already exists)`);
      done++;
      continue;
    }
    console.log(`\n[${done + 1}/${needOCR.length}] OCR ${f.label} via Replicate...`);
    const text = await ocrPDFviaReplicate(f.path);
    if (text) {
      writeFileSync(outPath, text, 'utf-8');
      console.log(`  Saved (${text.length} chars)`);
      done++;
    }
  }
  console.log(`\nDone: ${done}/${needOCR.length} files OCR'd via Replicate`);
}

main().catch(e => { console.error('\nFatal:', e.message); process.exit(1); });
