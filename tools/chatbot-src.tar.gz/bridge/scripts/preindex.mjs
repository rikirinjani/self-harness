import { readFileSync, readdirSync, statSync, mkdirSync, writeFileSync, mkdtempSync, rmSync } from 'fs';
import { join, relative } from 'path';
import { execFileSync, execSync } from 'child_process';
import { tmpdir } from 'os';
import { PDFParse } from 'pdf-parse';

const KNOWLEDGE_DIR = join(import.meta.dirname, '..', 'knowledge');
const ASSET_DIR = join(import.meta.dirname, '..', '..', 'asset');

function scanFiles(dir) {
  if (!statSync(dir, { throwIfNoEntry: false })?.isDirectory()) return [];
  const result = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, e.name);
    if (e.isDirectory()) result.push(...scanFiles(full));
    else {
      const ext = e.name.split('.').pop()?.toLowerCase() || '';
      if (ext === 'pdf') result.push({ path: full, ext, label: relative(ASSET_DIR, full) });
    }
  }
  return result;
}

function shouldOCR(text) {
  const words = text.split(/\s+/).filter(Boolean).length;
  const markers = (text.match(/--\s*\d+\s+of\s+\d+\s*--/g) || []).length;
  return words > 0 && (words < 100 || markers > words * 0.3);
}

function resolveBin(name) {
  try {
    return execSync(`where ${name}`, { encoding: 'utf-8' }).trim().split('\n')[0].trim() || name;
  } catch { return name; }
}

async function extractText(fp) {
  try {
    const buf = new Uint8Array(readFileSync(fp));
    const parser = new PDFParse(buf);
    const r = await parser.getText();
    return r.text || '';
  } catch { return null; }
}

async function runOCR(fp) {
  const tmp = mkdtempSync(join(tmpdir(), 'preidx-'));
  try {
    const bin = resolveBin('pdftoppm');
    execFileSync(bin, ['-png', '-r', '200', fp, join(tmp, 'p')], { timeout: 120000 });
    const pages = readdirSync(tmp).filter(f => f.endsWith('.png')).sort().map(f => join(tmp, f));
    if (!pages.length) return null;

    const py = resolveBin('python');
    const script = join(import.meta.dirname, '..', 'ocr_helper.py');
    const out = execFileSync(py, [script], {
      input: JSON.stringify(pages), encoding: 'utf-8', timeout: 600000,
      maxBuffer: 100 << 20, env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
    });
    const json = out.trim().split('\n').filter(l => l.startsWith('{')).join('\n');
    if (!json) return null;
    return Object.values(JSON.parse(json)).join('\n\n');
  } catch (e) {
    console.error(`  OCR failed:`, e.message);
    return null;
  } finally {
    try { rmSync(tmp, { recursive: true, force: true }); } catch {}
  }
}

async function main() {
  const files = scanFiles(ASSET_DIR);
  console.log(`Found ${files.length} PDFs`);

  mkdirSync(KNOWLEDGE_DIR, { recursive: true });

  let processed = 0, ocrCount = 0;
  for (const f of files) {
    const safeName = f.label.replace(/[<>:"/\\|?*]/g, '_').replace(/&/g, 'and');
    const outPath = join(KNOWLEDGE_DIR, safeName.replace(/\.pdf$/i, '') + '.md');

    if (statSync(outPath, { throwIfNoEntry: false })) {
      console.log(`  SKIP ${f.label} (exists)`);
      processed++;
      continue;
    }

    const text = await extractText(f.path);
    if (text === null) { console.log(`  FAIL ${f.label} (unreadable)`); continue; }

    if (shouldOCR(text)) {
      console.log(`  OCR ${f.label}...`);
      const ocrText = await runOCR(f.path);
      if (ocrText) {
        writeFileSync(outPath, ocrText, 'utf-8');
        ocrCount++;
        console.log(`  -> ${safeName}.md (${ocrText.length} chars from OCR)`);
      } else {
        writeFileSync(outPath, text, 'utf-8');
        console.log(`  -> ${safeName}.md (fallback: ${text.length} chars)`);
      }
    } else {
      writeFileSync(outPath, text, 'utf-8');
      console.log(`  -> ${safeName}.md (${text.length} chars)`);
    }
    processed++;
  }
  console.log(`\nDone: ${processed} files (${ocrCount} OCR'd). Bridge reads knowledge/ instantly.`);
}

main().catch(e => { console.error(e); process.exit(1); });
