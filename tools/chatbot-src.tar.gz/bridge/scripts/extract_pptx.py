import json, sys, os
from pptx import Presentation

paths = json.loads(sys.stdin.read())
results = {}
for p in paths:
    prs = Presentation(p)
    text = []
    for slide in prs.slides:
        lines = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                lines.append(shape.text.strip())
        if lines:
            text.append(" | ".join(lines))
    results[p] = "\n\n".join(text)
print(json.dumps(results, ensure_ascii=False))
