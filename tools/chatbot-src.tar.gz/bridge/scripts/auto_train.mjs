import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';
import { knowledgeBase } from '../dist/core/knowledge-base.js';
import { llmClient } from '../dist/core/llm-client.js';

const QUESTIONS = join(import.meta.dirname, '..', '..', '..', 'Desktop', 'all_questions.txt');
const OUT_DIR = join(import.meta.dirname, '..', 'knowledge', 'faq', '_generated');
const REPORT = join(import.meta.dirname, '..', 'data', 'training_report.json');

async function main() {
  console.log('[Train] Loading knowledge base...');
  await knowledgeBase.load();

  const qText = readFileSync(QUESTIONS, 'utf-8');
  const lines = qText.split('\n').filter(l => /^\d+./.test(l));

  mkdirSync(OUT_DIR, { recursive: true });

  const results = { total: lines.length, answered: 0, generated: 0, skipped: 0 };
  const generatedEntries = [];

  for (let i = 0; i < lines.length; i++) {
    const q = lines[i].replace(/^\d+\.\s*/, '').trim();
    if (!q || q.length < 10 || q.match(/^[*#>\d]/)) {
      results.skipped++;
      continue;
    }

    process.stdout.write(`[${i + 1}/${lines.length}] ${q.slice(0, 80)}... `);

    try {
      // Test if RAG can answer
      const { context } = await knowledgeBase.search(q);
      if (context && context.length > 200) {
        // RAG found good context — skip
        results.answered++;
        console.log('✅ covered');
        continue;
      }

      // RAG didn't find good context — generate answer
      const prompt = `Jawab pertanyaan berikut sebagai Asisten Kolegium Farmasi. Jawab singkat dan tepat sasaran. Jika tidak tahu, bilang saja.

Pertanyaan: ${q}

Jawaban:`;
      const answer = await llmClient.chat([{ role: 'user', content: prompt }]);

      if (answer && answer.length > 20 && !answer.includes('tidak tahu') && !answer.includes('maaf')) {
        generatedEntries.push({ q, a: answer });
        results.generated++;
        console.log(`🆕 generated (${answer.length} chars)`);
      } else {
        results.skipped++;
        console.log('⏭️ skipped (low quality)');
      }

      // Rate limit: 1 query per 3 seconds
      await new Promise(r => setTimeout(r, 3000));
    } catch (err) {
      console.log(`❌ error: ${err.message}`);
      results.skipped++;
    }
  }

  // Write generated as categorized FAQ files
  const cats = {};
  for (const { q, a } of generatedEntries) {
    const ql = q.toLowerCase();
    let cat = 'umum';
    if (/serkom|sertifikat kompetensi/.test(ql)) cat = 'serkom';
    else if (/skp|satuan kredit/.test(ql)) cat = 'skp';
    else if (/str|registrasi/.test(ql)) cat = 'str';
    else if (/sip|izin praktik/.test(ql)) cat = 'sip';
    else if (/ukom|ujian kompetensi/.test(ql)) cat = 'ukom';
    cats[cat] = cats[cat] || [];
    cats[cat].push({ q, a });
  }

  for (const [cat, entries] of Object.entries(cats)) {
    let md = `# FAQ Auto-Generated — ${cat.toUpperCase()}\n\n`;
    for (const e of entries) {
      md += `Q: ${e.q}\nA: ${e.a}\n\n`;
    }
    writeFileSync(join(OUT_DIR, `${cat}.md`), md, 'utf-8');
    console.log(`  ${cat}: ${entries.length} entries`);
  }

  writeFileSync(REPORT, JSON.stringify(results, null, 2), 'utf-8');
  console.log(`\nDone: ${results.answered} covered, ${results.generated} new, ${results.skipped} skipped`);
}

main().catch(e => { console.error(e); process.exit(1); });
