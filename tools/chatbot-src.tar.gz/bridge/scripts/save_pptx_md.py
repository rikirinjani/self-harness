import json, sys, os, re
from pptx import Presentation

base = sys.argv[1]  # path to New Asset
out = sys.argv[2]   # path to knowledge

for f in os.listdir(base):
    if not f.endswith('.pptx'): continue
    fp = os.path.join(base, f)
    prs = Presentation(fp)
    text = []
    for slide in prs.slides:
        lines = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                lines.append(shape.text.strip())
        if lines:
            text.append(" | ".join(lines))
    content = "\n\n".join(text)
    stem = re.sub(r'[\/:*?"<>|]', '_', os.path.splitext(f)[0])
    outpath = os.path.join(out, f"[New Asset] {stem}.md")
    with open(outpath, 'w', encoding='utf-8') as fh:
        fh.write(content)
    print(f"Saved {outpath} ({len(content)} chars)")
