// Rebuild all user transcripts from audit log files
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join('/Users/ptpakdefarma/chatbot/bridge', 'data');
const USERS_DIR = path.join('/Users/ptpakdefarma/chatbot/bridge', 'docs', 'users');

fs.mkdirSync(USERS_DIR, { recursive: true });

// Read all audit files
const files = fs.readdirSync(DATA_DIR)
  .filter(f => f.startsWith('audit-') && f.endsWith('.jsonl'))
  .sort();

const byUser = new Map();

for (const file of files) {
  const lines = fs.readFileSync(path.join(DATA_DIR, file), 'utf-8').split('\n').filter(Boolean);
  for (const line of lines) {
    try {
      const e = JSON.parse(line);
      if (!byUser.has(e.u)) {
        byUser.set(e.u, { name: e.uname || '', entries: [] });
      }
      const user = byUser.get(e.u);
      if (e.uname) user.name = e.uname;
      user.entries.push({
        timestamp: new Date(e.t).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
        question: e.q,
        answer: e.a,
        source: e.src,
        reviewId: e.rid,
        admin: e.admin,
      });
    } catch { /* skip */ }
  }
}

const srcLabel = {
  curated: '📌 Jawaban Baku',
  llm: '🤖 AI (LLM)',
  'llm-retry': '🤖 AI (retry)',
  review: '👁 Review',
  unanswered: '❓ Belum Terjawab',
  vague: '💬 Vague',
  edit: '✏️ Admin Edit',
  acc: '✅ Admin Approve',
};

let totalEntries = 0;
for (const [userId, data] of byUser) {
  const file = path.join(USERS_DIR, `${userId}.md`);
  const header = `# Transkrip Percakapan — ${data.name || userId}\n\n` +
    `**User ID:** ${userId}\n` +
    `**Nama:** ${data.name || '(tidak diketahui)'}\n` +
    `**Total Percakapan:** ${data.entries.length}\n` +
    `**Dibuat:** ${new Date().toISOString()} (rebuild dari audit log)\n\n---\n\n`;

  let body = '';
  for (const e of data.entries) {
    const adminNote = e.admin ? ` (oleh: ${e.admin})` : '';
    const ridNote = e.reviewId ? ` [${e.reviewId}]` : '';
    body +=
      `### ${e.timestamp}${ridNote}\n\n` +
      `**Pertanyaan:**\n${e.question}\n\n` +
      `**Jawaban (${srcLabel[e.source] || e.source})${adminNote}:**\n${e.answer}\n\n---\n\n`;
  }

  fs.writeFileSync(file, header + body, 'utf-8');
  totalEntries += data.entries.length;
}

console.log(`Rebuilt transcripts for ${byUser.size} users, ${totalEntries} entries.`);
console.log(`Files written to: ${USERS_DIR}`);
