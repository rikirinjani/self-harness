$ErrorActionPreference = "Stop"
Set-Location "C:\Users\think\chatbot\bridge"
node dist/index.js
