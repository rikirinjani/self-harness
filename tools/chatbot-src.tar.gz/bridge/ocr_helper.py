"""OCR helper for image-based PDF slides. Called by Node.js bridge."""
import sys, json, easyocr

def main():
    paths = json.loads(sys.stdin.read())
    reader = easyocr.Reader(['en'], gpu=False)
    results = {}
    for p in paths:
        lines = reader.readtext(p, detail=0)
        results[p] = ' '.join(lines)
    print(json.dumps(results, ensure_ascii=False))

if __name__ == '__main__':
    main()
