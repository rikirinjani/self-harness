const fs = require('fs');
const path = require('path');

async function main() {
  const img = fs.readFileSync(process.env.TEMP + '\\slide-001.png');
  const b64 = img.toString('base64');
  const dataUri = 'data:image/png;base64,' + b64;

  const r = await fetch('https://api.replicate.com/v1/models/abiruyt/text-extract-ocr/predictions', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer r8_KqkajGX39KVAFfMtxc0YX5Kt1YnT3r81pmTa3',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      input: { image: dataUri },
    }),
  });

  const d = await r.json();
  console.log('Status:', r.status);
  console.log('ID:', d.id);

  if (d.urls?.get) {
    // Poll for result
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 2000));
      const r2 = await fetch(d.urls.get, {
        headers: { 'Authorization': 'Bearer r8_KqkajGX39KVAFfMtxc0YX5Kt1YnT3r81pmTa3' }
      });
      const d2 = await r2.json();
      console.log('Status:', d2.status);
      if (d2.status === 'succeeded') {
        console.log('Output:', JSON.stringify(d2.output).slice(0, 500));
        break;
      }
      if (d2.status === 'failed') {
        console.log('Error:', d2.error);
        break;
      }
    }
  }
}

main().catch(e => console.error('FAIL:', e.message));
