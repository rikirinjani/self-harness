import http from 'http';
import { config } from './dist/config/index.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

// Load KB with timeout - send health pings
const loadPromise = knowledgeBase.load();
const timeout = setTimeout(() => {
  console.log('[WARN] load took > 30s, health check works?');
  // The event loop should still process http requests
}, 30000);

await loadPromise;
clearTimeout(timeout);
console.log('[KB] loaded:', knowledgeBase.chunks?.length, 'chunks');
