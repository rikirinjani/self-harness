import { config } from '../config/index.js';
import type { ChatMessage } from './types.js';

interface LLMProvider {
  baseUrl: string;
  model: string;
  apiKey: string;
}

const providers: Record<string, LLMProvider> = {
  deepseek: {
    baseUrl: 'https://api.deepseek.com',
    model: config.LLM_VARIANT === 'pro' ? 'deepseek-v4-pro' : 'deepseek-v4-flash',
    apiKey: config.DEEPSEEK_API_KEY ?? '',
  },
  openai: {
    baseUrl: config.OPENAI_BASE_URL || 'https://api.openai.com',
    model: config.LLM_MODEL || 'gpt-4o-mini',
    apiKey: config.OPENAI_API_KEY ?? '',
  },
};

export class LLMClient {
  private provider: LLMProvider;

  constructor() {
    const key = config.LLM_PROVIDER;
    const p = providers[key];
    if (!p || !p.apiKey) {
      throw new Error(
        `LLM provider "${key}" not configured. Set ${key.toUpperCase()}_API_KEY in .env`,
      );
    }
    this.provider = p;
  }

  async chat(messages: ChatMessage[]): Promise<string> {
    const msgs: any[] = [];

    if (config.SYSTEM_PROMPT) {
      msgs.push({ role: 'system', content: config.SYSTEM_PROMPT });
    }

    for (const m of messages) {
      if (m.content && typeof m.content === 'string') {
        msgs.push({ role: m.role, content: m.content });
      } else if (Array.isArray(m.content)) {
        // Vision message: convert to OpenAI format
        const content = m.content.map((block: any) => {
          if (block.type === 'image_url') {
            return { type: 'image_url', image_url: { url: block.image_url.url } };
          }
          return { type: 'text', text: block.text };
        });
        msgs.push({ role: m.role, content });
        console.log(`[LLM] Vision message detected: ${content.length} blocks (${content.filter((b:any)=>b.type==='image_url').length} images)`);
      } else {
        msgs.push({ role: m.role, content: String(m.content) });
      }
    }

    console.log(`[LLM] Calling ${this.provider.model} with ${msgs.length} messages`);

    console.log(`[LLM] Calling ${this.provider.model} with ${msgs.length} messages`);

    const body = JSON.stringify({
      model: this.provider.model,
      messages: msgs,
      stream: false,
    });
    console.log(`[LLM] Request body: ${body.substring(0, 500)}...`);

    const res = await fetch(`${this.provider.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.provider.apiKey}`,
      },
      body,
    });

    console.log(`[LLM] Response status: ${res.status}`);
    console.log(`[LLM] Response headers: ${JSON.stringify(Object.fromEntries(res.headers.entries()))}`);
    const respText = await res.text();
    console.log(`[LLM] Response body: ${respText.substring(0, 1000)}`);
    if (!res.ok) {
      throw new Error(`${config.LLM_PROVIDER} API error ${res.status}: ${respText}`);
    }
    const data = JSON.parse(respText);
    const answer = data.choices?.[0]?.message?.content ?? '';
    console.log(`[LLM] Answer length: ${answer.length} chars`);
    return answer;
  }

  // Fetch account balance from the provider (DeepSeek supported).
  async balance(): Promise<string> {
    if (config.LLM_PROVIDER !== 'deepseek') {
      return `Cek saldo hanya tersedia untuk DeepSeek (provider aktif: ${config.LLM_PROVIDER}).`;
    }
    try {
      const res = await fetch(`${this.provider.baseUrl}/user/balance`, {
        headers: { Authorization: `Bearer ${this.provider.apiKey}` },
      });
      if (!res.ok) return `Gagal cek saldo (HTTP ${res.status}).`;
      const data = await res.json();
      const info = data.balance_infos?.[0];
      if (!info) return 'Saldo tidak tersedia.';
      const avail = data.is_available ? '✅ aktif' : '⚠️ TIDAK aktif';
      let out = `💳 SALDO DEEPSEEK\nStatus: ${avail}\nTotal: ${info.total_balance} ${info.currency}\n(top-up: ${info.topped_up_balance} • bonus: ${info.granted_balance})`;
      if (parseFloat(info.total_balance) < 2) out += `\n\n⚠️ Saldo menipis — segera top-up agar bot tetap menjawab.`;
      return out;
    } catch (err) {
      return `Gagal cek saldo: ${err}`;
    }
  }
}

export const llmClient = new LLMClient();
