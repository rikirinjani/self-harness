import natural from 'natural';
const { TfIdf } = natural;
import { PDFParse } from 'pdf-parse';
import { readFileSync, readdirSync, statSync } from 'fs';
import { join, relative } from 'path';
import { config } from '../config/index.js';
import { llmClient } from './llm-client.js';
import type { ChatMessage } from './types.js';

interface Chunk {
  source: string;
  text: string;
}

const KNOWLEDGE_DIR = join(import.meta.dirname, '..', '..', 'knowledge');
const ASSET_DIR = join(import.meta.dirname, '..', '..', '..', 'asset');

function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

function splitIntoChunks(text: string, chunkSize: number, overlap: number): string[] {
  const result: string[] = [];
  for (let i = 0; i < text.length; i += chunkSize - overlap) {
    result.push(text.slice(i, i + chunkSize).trim());
  }
  return result.filter((c) => c.length > 0);
}

function splitSections(text: string, chunkSize: number, overlap: number): string[] {
  const headingRegex = /^## /m;
  const match = text.search(headingRegex);

  if (match === -1) {
    return text.length <= chunkSize ? [text] : splitIntoChunks(text, chunkSize, overlap);
  }

  const sections: string[] = [];
  sections.push(text.slice(0, match).trim());
  let cursor = match;
  let nextMatch: number;

  while ((nextMatch = text.slice(cursor + 1).search(headingRegex)) !== -1) {
    sections.push(text.slice(cursor, cursor + 1 + nextMatch).trim());
    cursor = cursor + 1 + nextMatch;
  }
  sections.push(text.slice(cursor).trim());

  const results: string[] = [];
  for (const section of sections) {
    if (section.length <= chunkSize) {
      if (section) results.push(section);
    } else {
      results.push(...splitIntoChunks(section, chunkSize, overlap));
    }
  }
  return results;
}

async function extractPDFText(filePath: string): Promise<string> {
  const buf = new Uint8Array(readFileSync(filePath));
  const parser = new PDFParse(buf);
  const result = await parser.getText();
  return result.text || '';
}

function shouldOCR(text: string): boolean {
  const words = text.split(/\s+/).filter(Boolean).length;
  const pageMarkers = (text.match(/--\s*\d+\s+of\s+\d+\s*--/g) || []).length;
  return words > 0 && (words < 100 || pageMarkers > words * 0.3);
}

function scanDir(dir: string, baseDir: string): { path: string; ext: string }[] {
  if (!statSync(dir, { throwIfNoEntry: false })?.isDirectory()) return [];

  const entries: { path: string; ext: string }[] = [];
  const items = readdirSync(dir, { withFileTypes: true });

  for (const item of items) {
    const full = join(dir, item.name);
    if (item.isDirectory()) {
      entries.push(...scanDir(full, baseDir));
    } else {
      const ext = item.name.split('.').pop()?.toLowerCase() || '';
      if (ext === 'md' || ext === 'pdf') {
        entries.push({ path: full, ext });
      }
    }
  }
  return entries;
}

export class KnowledgeBase {
  private tfidf = new TfIdf();
  private chunks: Chunk[] = [];
  private loaded = false;

  private async addChunks(label: string, text: string) {
    const rawChunks = splitSections(text, config.RAG_CHUNK_SIZE, config.RAG_CHUNK_OVERLAP);
    for (let i = 0; i < rawChunks.length; i++) {
      const raw = rawChunks[i];
      if (raw.length < 20) continue;
      this.chunks.push({ source: label, text: raw });
      this.tfidf.addDocument(raw, label);
      if (i % 10 === 9) await new Promise(r => setTimeout(r, 0));
    }
  }

  async load() {
    if (this.loaded) return;
    this.loaded = true;
    await this.index();
  }

  // Rebuild the index from disk — used after /resolve appends a new FAQ entry.
  async reload() {
    this.tfidf = new TfIdf();
    this.chunks = [];
    this.loaded = true;
    await this.index();
  }

  private async index() {
    const files: { path: string; ext: string; label: string }[] = [];

    for (const e of scanDir(KNOWLEDGE_DIR, KNOWLEDGE_DIR)) {
      files.push({ ...e, label: relative(KNOWLEDGE_DIR, e.path) });
    }
    for (const e of scanDir(ASSET_DIR, ASSET_DIR)) {
      files.push({ ...e, label: `[asset] ${relative(ASSET_DIR, e.path)}` });
    }

    if (files.length === 0) {
      console.log('[Knowledge] No files found');
      return;
    }

    for (const file of files) {
      try {
        let text: string;
        if (file.ext === 'pdf') {
          text = await extractPDFText(file.path);
          if (shouldOCR(text)) {
            console.log(`[Knowledge] ${file.label} is image-based — add .md to knowledge/ or run preindex`);
            continue;
          }
        } else {
          text = readFileSync(file.path, 'utf-8');
        }
        await this.addChunks(file.label, text);
      } catch (err) {
        console.error(`[Knowledge] Failed to process ${file.label}:`, err);
      }
    }

    console.log(`[Knowledge] Indexed ${this.chunks.length} chunks from ${files.length} file(s)`);
  }

  async search(query: string, topK = config.RAG_TOP_K): Promise<{ context: string; expanded: boolean }> {
    if (this.chunks.length === 0) return { context: '', expanded: false };

    let queries = [query];

    if (config.RAG_QUERY_EXPANSION) {
      queries = await this.expandQuery(query);
    }

    const scored = new Map<number, number>();

    for (const q of queries) {
      this.tfidf.tfidfs(q, (i: number, measure: number) => {
        scored.set(i, (scored.get(i) || 0) + measure);
      });
    }

    if (scored.size === 0) return { context: '', expanded: queries.length > 1 };

    const sorted = [...scored.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, topK);

    let context = '';
    let tokenBudget = config.RAG_MAX_CONTEXT_TOKENS;

    for (const [index] of sorted) {
      const chunk = this.chunks[index];
      const chunkTokens = estimateTokens(chunk.text);

      if (chunkTokens > tokenBudget) break;

      context += `\n[${chunk.source}]\n${chunk.text}\n`;
      tokenBudget -= chunkTokens;
    }

    return { context: context.trim(), expanded: queries.length > 1 };
  }

  async searchContacts(query: string): Promise<string> {
    const contactTerms = ['kontak', 'hubungi', 'telepon', 'email', 'nomor', 'alamat', 'hp', 'whatsapp'];
    const lower = query.toLowerCase();
    if (!contactTerms.some(t => lower.includes(t))) return '';

    const hasEmail = (s: string) => /[\w.-]+@[\w.-]+\.\w+/.test(s);
    const hasPhone = (s: string) => /\d{3,4}\s?\d{3,4}\s?\d{3,4}/.test(s);
    const isContact = (s: string) => hasEmail(s) || hasPhone(s);

    const matches: string[] = [];
    for (const chunk of this.chunks) {
      if (isContact(chunk.text) && chunk.text.toLowerCase().includes('kolegium')) {
        matches.push(`[${chunk.source}]\n${chunk.text}`);
      }
    }
    if (matches.length === 0) {
      for (const chunk of this.chunks) {
        if (isContact(chunk.text)) {
          matches.push(`[${chunk.source}]\n${chunk.text}`);
        }
      }
    }
    return matches.slice(0, 3).join('\n');
  }

  private async expandQuery(query: string): Promise<string[]> {
    try {
      const prompt: ChatMessage[] = [
        {
          role: 'system',
          content: 'Generate 3 short alternative search terms for the given query. Return ONLY a comma-separated list, no numbering, no explanation.',
        },
        { role: 'user', content: query },
      ];

      const result = await llmClient.chat(prompt);
      const terms = result.split(',').map((t) => t.trim()).filter(Boolean);

      return [query, ...terms.slice(0, 3)];
    } catch {
      return [query];
    }
  }
}

export const knowledgeBase = new KnowledgeBase();
