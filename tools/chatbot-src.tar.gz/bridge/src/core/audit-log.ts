import { appendFileSync, existsSync, readFileSync, mkdirSync } from 'fs';
import { join } from 'path';

const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
mkdirSync(DATA_DIR, { recursive: true });

export interface AuditEntry {
  t: number;       // timestamp ms
  u: string;       // userId
  uname?: string;  // userName
  c: string;       // channel
  q: string;       // question
  a: string;       // answer or outcome text
  src: 'curated' | 'llm' | 'llm-retry' | 'review' | 'unanswered' | 'vague' | 'edit' | 'acc';
  admin?: string;  // admin handle/name for edit/acc actions
  rid?: string;    // review ID if applicable
}

function auditFile(date?: Date): string {
  const d = date || new Date();
  const iso = d.toISOString().slice(0, 10); // YYYY-MM-DD
  return join(DATA_DIR, `audit-${iso}.jsonl`);
}

export function logAudit(entry: AuditEntry): void {
  try {
    appendFileSync(auditFile(), JSON.stringify(entry) + '\n', 'utf-8');
  } catch (err) {
    console.error('[AuditLog] write error:', err);
  }
}

export function readAuditLog(dateStr?: string): AuditEntry[] {
  const file = dateStr
    ? join(DATA_DIR, `audit-${dateStr}.jsonl`)
    : auditFile();
  if (!existsSync(file)) return [];
  return readFileSync(file, 'utf-8')
    .split('\n')
    .filter(Boolean)
    .map(l => { try { return JSON.parse(l); } catch { return null; } })
    .filter(Boolean) as AuditEntry[];
}

/** Read all audit files (all dates). Used for user-specific lookups. */
export function readAllAuditLogs(): AuditEntry[] {
  const { readdirSync } = require('fs');
  const files = readdirSync(DATA_DIR)
    .filter((f: string) => f.startsWith('audit-') && f.endsWith('.jsonl'))
    .sort();
  const entries: AuditEntry[] = [];
  for (const f of files) {
    const lines = readFileSync(join(DATA_DIR, f), 'utf-8').split('\n').filter(Boolean);
    for (const l of lines) {
      try { entries.push(JSON.parse(l)); } catch { /* skip */ }
    }
  }
  return entries;
}

export function formatAuditEntries(entries: AuditEntry[], label: string): string {
  if (entries.length === 0) return `📋 Audit log kosong${label ? ' untuk ' + label : ''}.`;
  let out = `📋 AUDIT LOG${label ? ' — ' + label : ''} (${entries.length} entries)\n\n`;
  for (const e of entries.slice(-20)) {
    const dt = new Date(e.t).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });
    const who = e.uname ? `${e.uname} (${e.u})` : e.u;
    const rid = e.rid ? ` [${e.rid}]` : '';
    out += `${dt} [${e.src}]${rid} ${who}\nQ: ${e.q.replace(/\n/g, ' ').slice(0, 80)}\nA: ${e.a.replace(/\n/g, ' ').slice(0, 80)}\n\n`;
  }
  return out.trim();
}
