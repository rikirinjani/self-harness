export type ChannelType = 'telegram' | 'whatsapp' | 'instagram' | 'facebook';

export interface IncomingMessage {
  id: string;
  channel: ChannelType;
  userId: string;
  userName?: string;
  /** Platform handle (e.g. Telegram @username) of the sender, when available. */
  userHandle?: string;
  text: string;
  timestamp: Date;
  raw: unknown;
  /** Image URL (Telegram file_url or base64) when message contains photo. */
  image?: string;
}

export interface OutgoingMessage {
  channel: ChannelType;
  userId: string;
  text: string;
  replyTo?: string;
  /** Image URL or base64 data URI to send back to the user. */
  image?: string;
  /** Optional caption for the image. */
  imageCaption?: string;
}

export type MessageHandler = (msg: IncomingMessage) => Promise<void>;

export interface ChannelAdapter {
  readonly channel: ChannelType;
  send(msg: OutgoingMessage): Promise<void>;
  start(handler: MessageHandler): Promise<void>;
  stop(): Promise<void>;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string | Array<{ type: 'text'; text: string } | { type: 'image_url'; image_url: { url: string } }>;
}
