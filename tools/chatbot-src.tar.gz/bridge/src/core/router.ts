import type { ChannelAdapter, ChannelType, ChatMessage, IncomingMessage } from './types.js';
import { llmClient } from './llm-client.js';
import { knowledgeBase } from './knowledge-base.js';
import { config } from '../config/index.js';
import { logQuestion, isUnanswered, saveUnanswered, generateReport, buildDailyRecap, buildFullRecap, buildUnansweredList, resolveUnanswered, resolveUnansweredByQuestion } from './reporter.js';
import { buildKBAuditReport, showGroup, mergeGroup } from './kb-audit.js';
import { findCurated, saveCurated, listCurated } from './curated.js';
import { logAudit, readAuditLog, readAllAuditLogs, formatAuditEntries } from './audit-log.js';
import { getHistory, appendHistory } from './conversation-store.js';
import { appendTranscript } from './user-transcript.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const MAX_HISTORY = 10;
const FORM_TIMEOUT = 10 * 60 * 1000; // 10 minutes
const REVIEWS_FILE = join(import.meta.dirname, '..', '..', 'data', 'reviews.json');
const BUFFERED_IMG_FILE = join(import.meta.dirname, '..', '..', 'data', 'buffered-images.json');

interface FormState {
  step: number;
  data: Record<string, string>;
  expiresAt: number;
  adapter: ChannelAdapter;
  userId: string;
}

const fields = [
  { key: 'nama', label: 'Nama Lengkap' },
  { key: 'nik', label: 'NIK' },
  { key: 'profesi', label: 'Profesi (Apoteker / TVF)' },
  { key: 'no_str', label: 'Nomor STR' },
  { key: 'email', label: 'Email terdaftar di SatuSehat' },
  { key: 'kendala', label: 'Kendala yang dialami' },
];

const FORWARD_ID = config.FORWARD_CHAT_ID;

// Explicit admin initials, keyed by Telegram username or first name (lowercase).
// Keeps footers stable regardless of how a handle is spelled.
const ADMIN_INITIALS: Record<string, string> = {
  'riki rinjani': 'rr',
  'riki': 'rr',
  'rikirinjani': 'rr',
  'riki_rinjani': 'rr',
  'primadi avianto': 'pa',
  'primadi': 'pa',
  'primadiavianto': 'pa',
  'primadi_avianto': 'pa',
  'kolegium farmasi': 'kf',
  'kolegium': 'kf',
  'kolegiumfarmasi': 'kf',
  'kolegium_farmasi': 'kf',
  'kolfar': 'kf',
};

// Build the per-admin answer footer: "answered by admin_rr". Uses the explicit
// map first, then falls back to initials derived from handle/name.
function adminFooter(handle?: string, firstName?: string): string {
  const candidates = [handle, firstName].filter(Boolean).map(s => String(s).trim());
  for (const c of candidates) {
    const hit = ADMIN_INITIALS[c.toLowerCase()];
    if (hit) return `answered by admin_${hit}`;
  }
  const src = candidates[0] || '';
  if (!src) return config.WHATSAPP_ANSWER_FOOTER?.trim() || '';
  const parts = src
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean);
  const initials = parts.length >= 2
    ? parts.slice(0, 2).map(p => p[0]).join('')
    : parts[0].slice(0, 2);
  return `answered by admin_${initials.toLowerCase()}`;
}

// Jurisdiction preambles: STR/SIPA are NOT Kolegium Farmasi's authority.
// When a question is about STR (any variant) or SIPA (any variant), prepend
// the hardcoded jurisdiction line BEFORE the KB-based answer.
const STR_PREAMBLE = 'STR merupakan kewenangan Konsil Kesehatan Indonesia (KKI), bukan Kolegium Farmasi.';
const SIPA_PREAMBLE = 'SIPA merupakan kewenangan Dinas Kesehatan / PTSP / Pemerintah Daerah, bukan Kolegium Farmasi.';

function jurisdictionPreamble(text: string): string {
  const t = text.toLowerCase();
  // STR variants: str, str a/stra, str seumur hidup, str kadaluarsa, etc.
  // Match "str" as a word (not inside other words like "registrasi").
  const strMatch = new RegExp(`\\bstr\\b|\\bstra\\b|str seumur hidup|str kadaluarsa|str kadaluwarsa|str habis|str expired|str lama|str baru`, 'i').test(t);
  // SIPA variants: sipa, sip-a, sip apoteker, and bare "sip" as a whole word
  // (in this bot's domain "perpanjangan sip" from a user means SIPA; word
  // boundary prevents matching inside "registrasi" etc.).
  const sipaMatch = /\bsipa\b|\bsip-a\b|\bsip\b|sip apoteker|sip apoteker penanggung jawab/.test(t);
  if (sipaMatch) return SIPA_PREAMBLE;
  if (strMatch) return STR_PREAMBLE;
  return '';
}

export class MessageRouter {
  private adapters: Map<string, ChannelAdapter> = new Map();
  private forms: Map<string, FormState> = new Map();
  private pendingReviews = new Map<string, { channel: ChannelType; target: string; question: string; draft: string; ts: number }>();
  private rejectedReviews = new Map<string, { channel: ChannelType; target: string; question: string; draft: string; ts: number }>();
  private reviewSeq = 0;

  /** Buffered images: userId → { channel, image, ts }. A bare photo with no
   *  caption is held here for 90s in case the user follows up with text.
   *  Persisted to disk so it survives a bot restart mid-buffer. */
  private bufferedImages = new Map<string, { channel: ChannelType; image: string; ts: number }>();
  private readonly BUFFER_TTL_MS = 90_000;

  private loadBufferedImages() {
    try {
      if (!existsSync(BUFFERED_IMG_FILE)) return;
      const data = JSON.parse(readFileSync(BUFFERED_IMG_FILE, 'utf-8')) as Record<string, { channel: string; image: string; ts: number }>;
      for (const [uid, entry] of Object.entries(data)) {
        // Drop entries that are already expired
        if (Date.now() - entry.ts > this.BUFFER_TTL_MS) continue;
        this.bufferedImages.set(uid, entry as any);
      }
      if (this.bufferedImages.size > 0) {
        console.log(`[Router] Loaded ${this.bufferedImages.size} buffered image(s)`);
      }
    } catch (err) {
      console.error('[Router] Failed to load buffered images:', err);
    }
  }

  private saveBufferedImages() {
    try {
      mkdirSync(join(import.meta.dirname, '..', '..', 'data'), { recursive: true });
      const obj: Record<string, { channel: string; image: string; ts: number }> = Object.fromEntries(this.bufferedImages);
      writeFileSync(BUFFERED_IMG_FILE, JSON.stringify(obj, null, 2), 'utf-8');
    } catch (err) {
      console.error('[Router] Failed to save buffered images:', err);
    }
  }

  private loadReviews() {
    try {
      if (!existsSync(REVIEWS_FILE)) return;
      const data = JSON.parse(readFileSync(REVIEWS_FILE, 'utf-8'));
      this.reviewSeq = data.reviewSeq || 0;
      for (const [id, r] of Object.entries(data.pending || {})) {
        this.pendingReviews.set(id, r as any);
      }
      for (const [id, r] of Object.entries(data.rejected || {})) {
        this.rejectedReviews.set(id, r as any);
      }
      console.log(`[Router] Loaded reviews: ${this.pendingReviews.size} pending, ${this.rejectedReviews.size} rejected, seq=${this.reviewSeq}`);
    } catch (err) {
      console.error('[Router] Failed to load reviews:', err);
    }
  }

  private saveReviews() {    try {
      const dir = join(import.meta.dirname, '..', '..', 'data');
      mkdirSync(dir, { recursive: true });
      const data = {
        reviewSeq: this.reviewSeq,
        pending: Object.fromEntries(this.pendingReviews),
        rejected: Object.fromEntries(this.rejectedReviews),
      };
      writeFileSync(REVIEWS_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[Router] Failed to save reviews:', err);
    }
  }

  register(adapter: ChannelAdapter) {
    this.adapters.set(adapter.channel, adapter);
  }

  getAdapter(channel: ChannelType): ChannelAdapter | undefined {
    return this.adapters.get(channel);
  }

  private async send(adapter: ChannelAdapter, userId: string, text: string) {
    try {
      await adapter.send({ channel: adapter.channel, userId, text });
    } catch (err) {
      console.error('[Router] send error:', err);
    }
  }

  private async handleForm(incoming: IncomingMessage, adapter: ChannelAdapter): Promise<boolean> {
    const key = `${incoming.channel}:${incoming.userId}`;
    const form = this.forms.get(key);

    // Check for form cancel
    if (form && ['/batal', '/cancel', 'batalkan'].includes(incoming.text.toLowerCase().trim())) {
      this.forms.delete(key);
      await this.send(adapter, incoming.userId, 'Laporan dibatalkan.');
      return true;
    }

    // Start form
    if (!form && incoming.text.toLowerCase().includes('/laporan')) {
      const state: FormState = {
        step: 0,
        data: {},
        expiresAt: Date.now() + FORM_TIMEOUT,
        adapter,
        userId: incoming.userId,
      };
      this.forms.set(key, state);
      await this.send(adapter, incoming.userId, `Silakan isi laporan berikut. Ketik /batal untuk membatalkan.\n\nPertanyaan 1/${fields.length}: ${fields[0].label}?`);
      return true;
    }

    if (!form) return false;

    // Check timeout
    if (Date.now() > form.expiresAt) {
      this.forms.delete(key);
      await this.send(adapter, incoming.userId, 'Waktu habis. Ketik /laporan untuk memulai ulang.');
      return true;
    }

    // Save answer
    const field = fields[form.step];
    
    // Validate
    if (field.key === 'nik') {
      const clean = incoming.text.replace(/\D/g, '');
      if (clean.length !== 16) {
        await this.send(adapter, incoming.userId, 'Apakah format NIK anda sudah tepat? (16 digit angka)');
        return true;
      }
    }
    if (field.key === 'email') {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(incoming.text.trim())) {
        await this.send(adapter, incoming.userId, 'Apakah format email anda sudah tepat?');
        return true;
      }
    }

    form.data[field.key] = incoming.text;
    form.step++;

    // Next question or done
    if (form.step < fields.length) {
      await this.send(adapter, incoming.userId, `Pertanyaan ${form.step + 1}/${fields.length}: ${fields[form.step].label}?`);
    } else {
      this.forms.delete(key);

      // Build report
      let report = '📋 *LAPORAN BARU*\n\n';
      for (const f of fields) {
        report += `*${f.label}:* ${form.data[f.key] || '-'}\n`;
      }
      report += `\nDikirim dari: ${incoming.channel} / ${incoming.userName || incoming.userId}`;

      // Send to forward target
      if (FORWARD_ID) {
        try {
          const tg = this.adapters.get('telegram');
          if (tg) {
            await tg.send({ channel: 'telegram', userId: FORWARD_ID, text: report });
          }
        } catch (err) {
          console.error('[Router] forward error:', err);
        }
      }

      // Forward to WhatsApp number as alternative channel (e.g. Kolegium number)
      if (config.WHATSAPP_FORWARD_TO) {
        const wa = this.adapters.get('whatsapp');
        if (wa) {
          try {
            await wa.send({ channel: 'whatsapp', userId: config.WHATSAPP_FORWARD_TO, text: report });
          } catch (err) {
            console.error('[Router] WA forward error:', err);
          }
        }
      }

      // Confirm to user
      await this.send(adapter, incoming.userId, '✅ Laporan telah diteruskan ke admin. Terima kasih!');
    }
    return true;
  }

  private async handleMessage(incoming: IncomingMessage) {
    const key = `${incoming.channel}:${incoming.userId}`;
    const adapter = this.adapters.get(incoming.channel);
    if (!adapter) return;

    // Merge a text-only message with a previously-buffered bare photo from the
    // same user. This prevents the "two separate answers" problem: user sends a
    // photo, then sends the question as a separate text message. We treat them
    // as one query (image + text) and process it a single time.
    if (!incoming.image) {
      const buffered = this.bufferedImages.get(incoming.userId);
      if (buffered && Date.now() - buffered.ts <= this.BUFFER_TTL_MS) {
        incoming.image = buffered.image;
        this.bufferedImages.delete(incoming.userId);
        this.saveBufferedImages();
        console.log(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} merging buffered image with text: "${incoming.text.slice(0, 40)}"`);
      }
    }

    // Log all questions
    logQuestion(incoming.text, incoming.channel, incoming.userId);

    const lower = incoming.text.trim().toLowerCase();
    const cmdEarly = lower.replace(/^(\/\w+)@\S+/, '$1');

    // In the review group, ONLY admin commands are processed; ignore all
    // other chatter (greetings, discussion) so admins can talk without triggering the bot.
    const isReviewGroup = config.TELEGRAM_REVIEW_GROUP_ID && incoming.userId === config.TELEGRAM_REVIEW_GROUP_ID;
    const groupAllowed = cmdEarly.startsWith('/acc ') || cmdEarly.startsWith('/reject ') || cmdEarly.startsWith('/resolve ') || cmdEarly.startsWith('/edit ') || cmdEarly.startsWith('/kb_show ') || cmdEarly.startsWith('/kb_merge ') || cmdEarly.startsWith('/reopen ') || cmdEarly === '/recap' || cmdEarly === '/fullrecap' || cmdEarly === '/followup' || cmdEarly === '/balance' || cmdEarly === '/reject_list' || cmdEarly === '/list' || cmdEarly === '/kb_audit' || cmdEarly === '/curated' || cmdEarly.startsWith('/audit') || cmdEarly === '/commands' || cmdEarly === '/help';
    if (isReviewGroup && !groupAllowed) {
      return;
    }

    // Silent ignore for short acknowledgments
    if ((lower.startsWith('baik') || lower.startsWith('terima kasih') || lower.startsWith('makasih') || lower.startsWith('ok') || lower.startsWith('siap') || lower === 'noted' || lower === 'iya' || lower === 'ya') && lower.length < 30) {
      return;
    }

    // Vague/fragment guard: menu echoes and bare topic words are not real
    // questions. Ask for specifics instead of burning an unanswered ID.
    // Only 1–2 word fragments are blocked; a 3+ word topical phrase like
    // "sertifikasi pemenuhan kompetensi" is a legitimate query.
    // SKIP this guard if message has an image (vision capability).
    const vagueExact = [
      'layanan lainnya', 'layanan lain', 'lainnya', 'serkom', 'str', 'sip', 'skp',
      'ukom', 'ukomnas', 'sertifikasi', 'kompetensi', 'registrasi', 'informasi',
      'info', 'tanya', 'bertanya', 'mau tanya', 'izin bertanya', 'ijin bertanya',
      'permisi', 'menu', 'bantuan', 'help',
    ];
    const wordCount = lower.split(/\s+/).filter(Boolean).length;
    const hasQuestionCue = /\?|bagaimana|gimana|kenapa|mengapa|apakah|apa |berapa|kapan|dimana|di mana|siapa|bisakah|boleh|cara |syarat|kendala|gagal|ditolak|error/.test(lower);
    if (!cmdEarly.startsWith('/') && !incoming.image && (vagueExact.includes(lower) || (wordCount <= 2 && !hasQuestionCue))) {
      const vagueReply = 'Boleh diperjelas pertanyaannya, Sejawat? Contoh: "Bagaimana cara mengurus SERKOM Apoteker?" atau "Syarat perpanjangan SIP apa saja?"';
      logAudit({ t: Date.now(), u: incoming.userId, uname: incoming.userName, c: incoming.channel, q: incoming.text, a: vagueReply, src: 'vague' });
      await this.send(adapter, incoming.userId, vagueReply);
      return;
    }

    // /start (and /help): send a welcome directly — never treat as a question/review.
    if (cmdEarly === '/start' || cmdEarly === '/help') {
      await this.send(adapter, incoming.userId, 'Halo, sejawat! 🙏 Saya asisten Kolegium Farmasi. Silakan ketik pertanyaan Anda seputar SERKOM, STR, SIP, atau layanan lainnya.');
      return;
    }

    // Greeting handler — only if the message is a pure greeting (1–3 words, no
    // question content).  A message like "Halo saya mau tanya STR" must fall
    // through to the normal query handler so the actual question is processed.
    const greetings = ['halo', 'hallo', 'hai', 'hi', 'test', 'tes', 'assalamualaikum', 'pagi', 'siang', 'sore', 'malam'];
    const greetings2 = ['selamat pagi', 'selamat siang', 'selamat sore', 'selamat malam', 'selamat datang'];
    const words = lower.split(/\s+/).filter(Boolean);
    const firstWord = words[0] || '';
    const isPureGreeting = greetings.includes(firstWord) && words.length <= 3;
    const isPureGreeting2 = greetings2.includes(lower);
    if (isPureGreeting || isPureGreeting2) {
      const reply = lower.startsWith('selamat') ? lower.charAt(0).toUpperCase() + lower.slice(1) : 'Waalaikumsalam';
      await this.send(adapter, incoming.userId, reply + ', sejawat! Ada yang bisa dibantu?');
      return;
    }

    // Commands (normalize away @botname suffix used in groups, e.g. /acc@KolfarBot)
    const cmd = cmdEarly;

    // /commands or /help: show available commands
    if (cmd === '/commands' || cmd === '/help') {
      const isGroup = config.TELEGRAM_REVIEW_GROUP_ID && incoming.userId === config.TELEGRAM_REVIEW_GROUP_ID;
      let help = '';
      if (isGroup) {
        help = 'DAFTAR PERINTAH (Review Group)\n\n';
        help += 'REVIEW FLOW:\n';
        help += '/acc <ID> = Setujui & kirim jawaban ke user\n';
        help += '/edit <ID> <jawaban> = Edit jawaban, kirim ke user\n';
        help += '/reject <ID> = Tolak draft, masuk queue reject\n\n';
        help += 'QUEUE:\n';
        help += '/list atau /reject_list = Lihat semua pending & rejected\n';
        help += '/resolve <ID> <jawaban> = Jawab dari rejected queue\n';
        help += '/reopen <ID> = Buka ulang review yang sudah diproses (draft asli)\n\n';
        help += 'REPORTS:\n';
        help += '/recap = Ringkasan harian\n';
        help += '/fullrecap = Ringkasan lengkap\n';
        help += '/followup = Daftar belum terjawab\n';
        help += '/balance = Cek saldo DeepSeek\n\n';
        help += 'KB MANAGEMENT:\n';
        help += '/curated = Lihat semua jawaban baku\n';
        help += '/kb_audit = Audit duplikat di knowledge base\n';
        help += '/kb_show <ID> = Lihat detail duplikat\n';
        help += '/kb_merge <ID> <jawaban> = Merge duplikat jadi satu\n\n';
        help += 'AUDIT:\n';
        help += '/audit = Log hari ini\n';
        help += '/audit <userId> = Filter per user\n';
        help += '/audit <userId> <YYYY-MM-DD> = Filter per user + tanggal';
      } else {
        help = 'Halo, sejawat! 🙏\nSaya asisten Kolegium Farmasi.\nSilakan ketik pertanyaan Anda seputar SERKOM, STR, SIP, atau layanan lainnya.';
      }
      await this.send(adapter, incoming.userId, help);
      return;
    }

    if (cmd === '/pair' || cmd === '/qr') {
      const wa = this.adapters.get('whatsapp');
      if (wa && 'pairQR' in wa) {
        const msg = await (wa as any).pairQR(adapter, incoming.userId);
        await this.send(adapter, incoming.userId, msg);
      } else {
        await this.send(adapter, incoming.userId, 'WhatsApp sidecar not available.');
      }
      return;
    }
    if (cmd === '/daily' || cmd === '/report') {
      const report = generateReport();
      await this.send(adapter, incoming.userId, report);
      return;
    }

    // Manual triggers for the nightly jobs + resolve pipe + balance + reject_list (admin DM or review group only).
    if (incoming.channel === 'telegram' && (cmd === '/recap' || cmd === '/fullrecap' || cmd === '/followup' || cmd === '/balance' || cmd === '/reject_list' || cmd === '/list' || cmd === '/kb_audit' || cmd === '/curated' || cmd.startsWith('/audit') || cmd.startsWith('/resolve'))) {
      const adminDM = config.WHATSAPP_ADMIN_CHAT_ID;
      const reviewGroup = config.TELEGRAM_REVIEW_GROUP_ID;
      const isAdmin = (adminDM && incoming.userId === adminDM) || (reviewGroup && incoming.userId === reviewGroup);
      if (!isAdmin) {
        await this.send(adapter, incoming.userId, 'Perintah ini hanya untuk admin.');
        return;
      }
      const since = Date.now() - 86400000;
      const label = new Date().toLocaleDateString('id-ID');
      if (cmd === '/recap') {
        await this.send(adapter, incoming.userId, buildDailyRecap(since, label));
      } else if (cmd === '/fullrecap') {
        await this.send(adapter, incoming.userId, buildFullRecap(since, label));
      } else if (cmd === '/followup') {
        await this.send(adapter, incoming.userId, buildUnansweredList(since, label));
      } else if (cmd === '/balance') {
        await this.send(adapter, incoming.userId, await llmClient.balance());
      } else if (cmd === '/kb_audit') {
        await this.send(adapter, incoming.userId, buildKBAuditReport());
      } else if (cmd === '/curated') {
        const list = listCurated();
        if (list.length === 0) {
          await this.send(adapter, incoming.userId, 'Belum ada jawaban baku. Gunakan /edit, /resolve, atau /kb_merge untuk membuatnya.');
        } else {
          let out = `📌 JAWABAN BAKU (${list.length})\nDikirim apa adanya, tanpa diparafrase LLM.\n\n`;
          for (const e of list.slice(0, 20)) {
            out += `• [${e.origin}] ${e.question.replace(/\n/g, ' ').slice(0, 65)}\n`;
          }
          if (list.length > 20) out += `\n…dan ${list.length - 20} lainnya.`;
          await this.send(adapter, incoming.userId, out);
        }
      } else if (cmd.startsWith('/audit')) {
        // /audit — today's recent entries
        // /audit <userId> — filter by user ID
        // /audit <userId> <date> — filter by user ID and date (YYYY-MM-DD)
        const rest = incoming.text.trim().replace(/^\/audit(@\S+)?\s*/i, '').trim();
        const parts = rest.split(/\s+/);
        const userId = (parts[0] || '').replace(/[<>]/g, '');
        const dateStr = (parts[1] || '').replace(/[<>]/g, '');
        // If userId provided without date, search ALL audit files (all dates)
        const entries = (userId && !dateStr) ? readAllAuditLogs() : readAuditLog(dateStr || undefined);
        const filtered = userId ? entries.filter(e => e.u === userId) : entries;
        const label = userId ? `user ${userId}` : (dateStr || 'hari ini');
        await this.send(adapter, incoming.userId, formatAuditEntries(filtered, label));
      } else if (cmd === '/reject_list' || cmd === '/list') {
        if (this.rejectedReviews.size === 0 && this.pendingReviews.size === 0) {
          await this.send(adapter, incoming.userId, 'Tidak ada review pending atau ditolak.');
        } else {
          let out = '';
          if (this.pendingReviews.size > 0) {
            out += `📋 PENDING (${this.pendingReviews.size}):\n`;
            for (const [id, r] of this.pendingReviews) {
              out += `#${id} — ${r.question.slice(0, 60)}${r.question.length > 60 ? '…' : ''}\n`;
            }
          }
          if (this.rejectedReviews.size > 0) {
            out += `\n❌ DITOLAK (${this.rejectedReviews.size}):\n`;
            for (const [id, r] of this.rejectedReviews) {
              out += `#${id} — ${r.question.slice(0, 60)}${r.question.length > 60 ? '…' : ''}\n`;
            }
            out += `\nBalas: /resolve <ID> <jawaban>`;
          }
          await this.send(adapter, incoming.userId, out);
        }
      } else {
        // /resolve <ID> <answer text> — works for both U-IDs (unanswered) and R-IDs (rejected)
        const rest = incoming.text.trim().replace(/^\/resolve(@\S+)?\s*/i, '');
        const sp = rest.indexOf(' ');
        if (sp === -1) {
          await this.send(adapter, incoming.userId, 'Format: /resolve <ID> <jawaban>\nContoh: /resolve U1 Estimasi koreksi 3-5 hari kerja.');
          return;
        }
        const rid = rest.slice(0, sp).trim().toUpperCase();
        const ans = rest.slice(sp + 1).trim();
        if (!ans) {
          await this.send(adapter, incoming.userId, 'Jawaban kosong. Format: /resolve <ID> <jawaban>');
          return;
        }

        // Check rejected reviews first (R-IDs)
        const rejected = this.rejectedReviews.get(rid);
        if (rejected) {
          // Add to KB
          const q = rejected.question.replace(/\n/g, ' ').slice(0, 200);
          const slug = q.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 40);
          const entry = `\n\nQ: ${q}\nA: ${ans}\n`;
          try {
            const { appendFileSync, mkdirSync } = await import('fs');
            const { join } = await import('path');
            const kbDir = join(import.meta.dirname, '..', '..', 'knowledge', '[faq]');
            mkdirSync(kbDir, { recursive: true });
            appendFileSync(join(kbDir, '_resolved.md'), entry, 'utf-8');
          } catch (err) {
            console.error('[Router] Failed to write resolved to KB:', err);
          }
          this.rejectedReviews.delete(rid);
          this.saveReviews();
          saveCurated(rejected.question, ans, 'resolve');
          await knowledgeBase.reload();
          await this.send(adapter, incoming.userId, `✅ ${rid} terjawab & ditambahkan ke knowledge base.\nQ: ${rejected.question.slice(0, 80)}\nBot sekarang bisa menjawab pertanyaan ini.`);
        } else {
          // Fallback to unanswered queue (U-IDs)
          const res = resolveUnanswered(rid, ans);
          if (!res.ok) {
            await this.send(adapter, incoming.userId, `❌ ${res.error}`);
          } else {
            if (res.question) saveCurated(res.question, ans, 'resolve');
            await knowledgeBase.reload();
            await this.send(adapter, incoming.userId, `✅ ${rid} terjawab & ditambahkan ke knowledge base.\nQ: ${res.question}\nBot sekarang bisa menjawab pertanyaan ini.`);
          }
        }
      }
      return;
    }

    // KB hygiene: /kb_show <ID> inspects a duplicate group, /kb_merge <ID> <answer>
    // collapses it into one canonical entry.
    if (incoming.channel === 'telegram' && (cmd.startsWith('/kb_show') || cmd.startsWith('/kb_merge'))) {
      const adminDM = config.WHATSAPP_ADMIN_CHAT_ID;
      const reviewGroup = config.TELEGRAM_REVIEW_GROUP_ID;
      const isAdmin = (adminDM && incoming.userId === adminDM) || (reviewGroup && incoming.userId === reviewGroup);
      if (!isAdmin) {
        await this.send(adapter, incoming.userId, 'Perintah ini hanya untuk admin.');
        return;
      }
      if (cmd.startsWith('/kb_show')) {
        const gid = incoming.text.trim().replace(/^\/kb_show(@\S+)?\s*/i, '').trim();
        if (!gid) {
          await this.send(adapter, incoming.userId, 'Format: /kb_show <ID>\nContoh: /kb_show G1');
          return;
        }
        await this.send(adapter, incoming.userId, showGroup(gid));
        return;
      }
      const rest = incoming.text.trim().replace(/^\/kb_merge(@\S+)?\s*/i, '');
      const sp = rest.search(/\s/);
      if (sp === -1) {
        await this.send(adapter, incoming.userId, 'Format:\n/kb_merge <ID> keep <N>\n/kb_merge <ID> keep <N> <jawaban baru>\n/kb_merge <ID> <jawaban final>');
        return;
      }
      const gid = rest.slice(0, sp).trim();
      let payload = rest.slice(sp + 1).trim();

      // "keep <N>" selects the surviving entry; any text after it replaces that
      // entry's answer. Without "keep", the whole group collapses into a new entry.
      let keepIndex: number | undefined;
      const keepMatch = payload.match(/^keep\s+(\d+)\s*([\s\S]*)$/i);
      if (keepMatch) {
        keepIndex = parseInt(keepMatch[1], 10);
        payload = keepMatch[2].trim();
      } else if (!payload) {
        await this.send(adapter, incoming.userId, 'Jawaban kosong. Format: /kb_merge <ID> keep <N>  atau  /kb_merge <ID> <jawaban final>');
        return;
      }

      const res = mergeGroup(gid, payload, keepIndex);
      if (!res.ok) {
        await this.send(adapter, incoming.userId, `❌ ${res.error}`);
        return;
      }
      await knowledgeBase.reload();
      let msg = `✅ ${gid.toUpperCase()} dirapikan.\n${res.removed} entri duplikat dihapus.\n`;
      if (res.kept) {
        msg += res.inPlace
          ? `Entri dipertahankan apa adanya:\n${res.question}\n`
          : `Entri dipertahankan dengan jawaban baru:\n${res.question}\n`;
      } else {
        msg += `Q kanonik: ${res.question}\n`;
      }
      msg += `KB sudah dimuat ulang.`;
      await this.send(adapter, incoming.userId, msg);
      return;
    }

    // Admin edit-and-send (Telegram): /edit <id> <corrected answer>
    // Replaces the draft, delivers it to the user, and files the Q&A into the KB.
    if (incoming.channel === 'telegram' && cmd.startsWith('/edit ')) {
      const adminDM = config.WHATSAPP_ADMIN_CHAT_ID;
      const reviewGroup = config.TELEGRAM_REVIEW_GROUP_ID;
      const isAdmin = (adminDM && incoming.userId === adminDM) || (reviewGroup && incoming.userId === reviewGroup);
      if (!isAdmin) {
        await this.send(adapter, incoming.userId, 'Perintah ini hanya untuk admin.');
        return;
      }
      const rest = incoming.text.trim().replace(/^\/edit(@\S+)?\s*/i, '');
      const sp = rest.search(/\s/);
      if (sp === -1) {
        await this.send(adapter, incoming.userId, 'Format: /edit <ID> <jawaban revisi>\nContoh: /edit R8 Silakan kirim dokumen ke kolegium-farmasi@kki.go.id');
        return;
      }
      const editId = rest.slice(0, sp).trim().toUpperCase();
      const newDraft = rest.slice(sp + 1).trim();
      if (!newDraft) {
        await this.send(adapter, incoming.userId, 'Jawaban kosong. Format: /edit <ID> <jawaban revisi>');
        return;
      }
      const review = this.pendingReviews.get(editId) || this.rejectedReviews.get(editId);
      if (!review) {
        await this.send(adapter, incoming.userId, `Review #${editId} tidak ditemukan atau sudah diproses.`);
        return;
      }
      const targetAdapter = this.adapters.get(review.channel);
      const footer = adminFooter(incoming.userHandle, incoming.userName);
      const finalText = footer ? `${newDraft}\n\n${footer}` : newDraft;
      try {
        await targetAdapter?.send({ channel: review.channel, userId: review.target, text: finalText });
      } catch (err) {
        console.error('[Router] /edit send error:', err);
        await this.send(adapter, incoming.userId, `Gagal mengirim ke ${review.channel}: ${err}`);
        return;
      }
      logAudit({ t: Date.now(), u: review.target, c: review.channel, q: review.question, a: newDraft, src: 'edit', rid: editId, admin: incoming.userName || incoming.userId });
      // Mark matching unanswered entry as resolved so /followup excludes it.
      resolveUnansweredByQuestion(review.question, newDraft);
      // File the corrected Q&A into the knowledge base so the bot learns it.
      try {
        const q = review.question.replace(/\n/g, ' ').slice(0, 200);
        const kbDir = join(import.meta.dirname, '..', '..', 'knowledge', '[faq]');
        mkdirSync(kbDir, { recursive: true });
        const { appendFileSync } = await import('fs');
        appendFileSync(join(kbDir, '_resolved.md'), `\n\nQ: ${q}\nA: ${newDraft}\n`, 'utf-8');
      } catch (err) {
        console.error('[Router] /edit KB write error:', err);
      }
      // Admin-authored answers are canonical: serve verbatim, no paraphrasing.
      saveCurated(review.question, newDraft, 'edit');
      // Document in user transcript
      appendTranscript(review.target, '', {
        timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
        question: review.question,
        answer: newDraft,
        source: 'edit',
        reviewId: editId,
        admin: incoming.userName || incoming.userId,
      });
      this.pendingReviews.delete(editId);
      this.rejectedReviews.delete(editId);
      this.saveReviews();
      await knowledgeBase.reload();
      await this.send(adapter, incoming.userId, `✅ ${editId} direvisi & terkirim ke ${review.channel}.\nJawaban revisi juga ditambahkan ke knowledge base.`);
      return;
    }

    // Admin review approval (Telegram): /acc <id> approves + delivers, /reject <id> declines.
    // Accepted from the admin DM or the review group.
    if (incoming.channel === 'telegram' && (cmd.startsWith('/acc ') || cmd.startsWith('/reject '))) {
      const adminDM = config.WHATSAPP_ADMIN_CHAT_ID;
      const reviewGroup = config.TELEGRAM_REVIEW_GROUP_ID;
      const isAdmin = (adminDM && incoming.userId === adminDM) || (reviewGroup && incoming.userId === reviewGroup);
      if (!isAdmin) {
        await this.send(adapter, incoming.userId, 'Perintah ini hanya untuk admin.');
        return;
      }
      const reviewId = (incoming.text.trim().split(/\s+/)[1] ?? '').toUpperCase();
      const review = this.pendingReviews.get(reviewId);
      if (!review) {
        await this.send(adapter, incoming.userId, `Review #${reviewId} tidak ditemukan atau sudah diproses.`);
        return;
      }
      const targetAdapter = this.adapters.get(review.channel);
      if (cmd.startsWith('/acc ')) {
        const footer = adminFooter(incoming.userHandle, incoming.userName);
        const finalText = footer ? `${review.draft}\n\n${footer}` : review.draft;
        try {
          await targetAdapter?.send({ channel: review.channel, userId: review.target, text: finalText });
          logAudit({ t: Date.now(), u: review.target, c: review.channel, q: review.question, a: review.draft, src: 'acc', rid: reviewId, admin: incoming.userName || incoming.userId });
          // Mark matching unanswered entry as resolved so /followup excludes it.
          resolveUnansweredByQuestion(review.question, review.draft);
          // Document in user transcript
          appendTranscript(review.target, '', {
            timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
            question: review.question,
            answer: review.draft,
            source: 'acc',
            reviewId,
            admin: incoming.userName || incoming.userId,
          });
          this.pendingReviews.delete(reviewId);
          this.saveReviews();
          await this.send(adapter, incoming.userId, `✅ Review #${reviewId} disetujui & terkirim ke ${review.channel}.`);
        } catch (err) {
          console.error('[Router] /acc send error:', err);
          await this.send(adapter, incoming.userId, `Gagal mengirim ke ${review.channel}: ${err}`);
        }
      } else {
        this.rejectedReviews.set(reviewId, review);
        this.pendingReviews.delete(reviewId);
        this.saveReviews();
        try {
          await targetAdapter?.send({ channel: review.channel, userId: review.target, text: 'Mohon maaf, pertanyaan Anda sedang diproses admin. Mohon tunggu sebentar.' });
        } catch { /* best effort */ }
        await this.send(adapter, incoming.userId, `❌ Review #${reviewId} ditolak & masuk daftar reject.\nKetik /reject_list untuk melihat semua yang ditolak.\nKetik /resolve ${reviewId} <jawaban> untuk menjawab.`);
      }
      return;
    }

    // Admin reopen (Telegram): /reopen <id> — restore a consumed review (e.g.
    // after a wrong /edit) from its original audit-log draft so it can be
    // /edit-ed or /acc-ed again.
    if (incoming.channel === 'telegram' && cmd.startsWith('/reopen ')) {
      const adminDM = config.WHATSAPP_ADMIN_CHAT_ID;
      const reviewGroup = config.TELEGRAM_REVIEW_GROUP_ID;
      const isAdmin = (adminDM && incoming.userId === adminDM) || (reviewGroup && incoming.userId === reviewGroup);
      if (!isAdmin) {
        await this.send(adapter, incoming.userId, 'Perintah ini hanya untuk admin.');
        return;
      }
      const reviewId = (incoming.text.trim().split(/\s+/)[1] ?? '').toUpperCase();
      if (!reviewId) {
        await this.send(adapter, incoming.userId, 'Format: /reopen <R-ID>\nContoh: /reopen R292');
        return;
      }
      if (this.pendingReviews.has(reviewId)) {
        await this.send(adapter, incoming.userId, `Review #${reviewId} masih ada di pending — tidak perlu di-reopen.`);
        return;
      }
      // Find the ORIGINAL draft: the earliest audit entry for this R-ID
      // (src 'review' or 'curated' — the draft before any /edit or /acc).
      const all = readAllAuditLogs();
      const orig = all
        .filter(e => (e.rid || '').toUpperCase() === reviewId && (e.src === 'review' || e.src === 'curated'))
        .sort((a, b) => a.t - b.t)[0];
      if (!orig) {
        await this.send(adapter, incoming.userId, `Draft asli untuk #${reviewId} tidak ditemukan di audit log.`);
        return;
      }
      this.pendingReviews.set(reviewId, {
        channel: orig.c as ChannelType,
        target: orig.u,
        question: orig.q,
        draft: orig.a,
        ts: Date.now(),
      });
      this.saveReviews();
      await this.send(adapter, incoming.userId, `♻️ Review #${reviewId} dibuka kembali (draft asli dari audit log).\nTarget: ${orig.c}:${orig.u}\nPertanyaan: ${orig.q.slice(0, 80)}\n\nBalas: /edit ${reviewId} <jawaban> = perbaiki & kirim | /acc ${reviewId} = kirim draft asli`);
      return;
    }

    // Try form handler first
    if (await this.handleForm(incoming, adapter)) return;

    // Curated answers: pre-approved by admin. In auto-answer mode (review mode
    // disabled) we deliver the draft directly to the user instead of sending it
    // to the review group for /acc.
    // Image-bearing messages always go through the vision/LLM + admin-review
    // path, never through the curated short-circuit — a photo query needs a
    // human to see the image before a canned text answer is safe.
    const curated = incoming.image ? null : findCurated(incoming.text);
    if (curated) {
      console.log(`[Router][${new Date().toISOString()}] [telegram] user=${incoming.userId} name=${incoming.userName} curated hit (${curated.origin}): ${incoming.text.slice(0, 60)}`);
      const reviewId = `R${++this.reviewSeq}`;
      // Auto-answer mode: send directly to the user.
      const src: 'curated' = 'curated';
      logAudit({ t: Date.now(), u: incoming.userId, uname: incoming.userName, c: incoming.channel, q: incoming.text, a: curated.answer, src, rid: reviewId });
      await adapter.send({ channel: incoming.channel, userId: incoming.userId, text: curated.answer });
      // Store in conversation history for follow-up context
      appendHistory(key, incoming.text, curated.answer);
      // Document in user transcript
      appendTranscript(incoming.userId, incoming.userName || '', {
        timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
        question: incoming.text,
        answer: curated.answer,
        source: 'curated',
        reviewId,
      });
      return;
    }

    // Normal RAG flow. For image queries, skip the placeholder text
    // "(gambar dilampirkan)" so the KB search doesn't match on it; only
    // search when there's a real caption.
    const hasImage = !!incoming.image;
    const searchableText = (hasImage && incoming.text === '(gambar dilampirkan)')
      ? '' // placeholder — no meaningful RAG query
      : incoming.text;

    const [ragResult, contactChunks] = await Promise.all([
      knowledgeBase.search(searchableText),
      knowledgeBase.searchContacts(searchableText),
    ]);

    let combined = ragResult.context;
    if (contactChunks) combined += '\n\n' + contactChunks;

    let userContent = incoming.text;
    if (!hasImage && combined.trim()) {
      userContent = `Answer using the reference material below. If the material doesn't contain the answer, say so.\n\n${combined}\n\nQuestion: ${incoming.text}`;
    }

    const messages = getHistory(key);

    // Build user message content — include image if present.
    // When a photo is attached, use a vision-focused prompt so the LLM
    // describes/analyzes the image instead of treating the placeholder
    // text "(gambar dilampirkan)" as a RAG query.
    if (incoming.image) {
      const caption = incoming.text && incoming.text !== '(gambar dilampirkan)'
        ? incoming.text
        : '';
      const visionPrompt = caption
        ? `Sejawat mengirim gambar beserta teks berikut: "${caption}". Periksa gambar itu secara teliti, lalu jawab berdasarkan apa yang terlihat di gambar. Jika gambar sesuai pertanyaan, jelaskan apa yang Sejawat lihat dan apa yang harus dilakukan. Jika gambar tidak jelas atau tidak relevan dengan konteks pertanyaan di atas, sebutkan hal itu secara eksplisit.`
        : `Sejawat mengirim gambar tanpa teks. Periksa gambar itu secara teliti dan jelaskan apa yang Sejawat lihat. Jika gambar berkaitan dengan pertanyaan di atas (sekitar STR/SIP/UKOM/SKP/Kolegium Farmasi), jawab berdasarkan apa yang terlihat. Jika gambar tidak jelas atau tidak relevan, sebutkan hal itu secara eksplisit agar tim terkait dapat menindaklanjuti.`;
      messages.push({
        role: 'user',
        content: [
          { type: 'image_url', image_url: { url: incoming.image } },
          { type: 'text', text: visionPrompt },
        ],
      });
    } else {
      messages.push({ role: 'user', content: userContent });
    }

    try {
      const answer = await llmClient.chat(messages);
      console.log(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} name=${incoming.userName} LLM answered (${answer?.length ?? 0} chars), hasImage=${!!incoming.image}`);

      // Guard: if LLM returned empty/blank answer, treat as can't-answer
      if (!answer || answer.trim().length < 10) {
        console.warn(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} LLM returned empty/short answer for: ${incoming.text.slice(0, 50)}...`);
        // Fall through to can't-answer handling below
      } else {
        let src: 'llm' | 'llm-retry' = 'llm';

        // Strip preambles, disclaimers, and markdown
        let cleaned = answer
          .replace(/\*\*(.*?)\*\*/g, '$1')         // **bold** → plain
          .replace(/\*(.*?)\*/g, '$1')             // *italic* → plain
          .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // [text](url) → text
          .replace(/^Berdasarkan\s+(materi|dokumen|informasi)[^,]*[,.]\s*/i, '')
          .replace(/\n{1,2}(Catatan|Note|Disclaimer):.*$/is, '')
          .replace(/(?:^|\n)\s*(Materi tidak menjelaskan.*$|Tidak ada informasi.*$|Untuk.*(tidak tercakup|tidak diatur|tidak disebutkan).*$|Jika memerlukan informasi lebih lanjut.*$)/gim, '')
          .replace(/SIPA/gi, 'SIP')                // SIPA = SIP for Apoteker, not Izin Apotek
          .replace(/\bAnda\b/g, 'Sejawat')          // formal: Anda → Sejawat
          .replace(/Materyalde.*?yok\.?\s*/gi, '')  // strip Turkish LLM hallucinations
          .replace(/\n{3,}/g, '\n\n')              // collapse triple+ newlines
          .trim();

        // Guard: if cleaning produced garbage (single char, only punctuation), retry with explicit instruction
        if (cleaned.length < 10 || /^[.\-—_,\s]+$/.test(cleaned)) {
          console.warn(`[Router] Garbage response (len=${cleaned.length}): "${cleaned}" — retrying with explicit prompt`);
          let retryAnswer: string;
          try {
            retryAnswer = await llmClient.chat([
              { role: 'user', content: `Jawab pertanyaan berikut dengan lengkap dan jelas dalam Bahasa Indonesia. Jangan katakan "materi tidak menjelaskan" — berikan jawaban berdasarkan pengetahuan umum tentang regulasi farmasi Indonesia jika tidak ada di materi.\n\nPertanyaan: ${incoming.text}` }
            ]);
          } catch (retryErr) {
            console.error('[Router] LLM retry error:', retryErr);
            retryAnswer = cleaned; // keep the garbage, will be handled by unanswered check below
          }
          cleaned = retryAnswer
            .replace(/\*\*(.*?)\*\*/g, '$1')
            .replace(/\*(.*?)\*/g, '$1')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/^Berdasarkan\s+(materi|dokumen|informasi)[^,]*[,.]\s*/i, '')
            .replace(/SIPA/gi, 'SIP')
            .replace(/\bAnda\b/g, 'Sejawat')          // formal: Anda → Sejawat
            .replace(/Materyalde.*?yok\.?\s*/gi, '')  // strip Turkish LLM hallucinations
            .trim();
          src = 'llm-retry';
        }

        // Jurisdiction preamble: STR/SIPA questions get the hardcoded authority
        // line FIRST, then the KB-based answer. Avoid duplicating if the LLM
        // already opened with the same statement.
        const preamble = jurisdictionPreamble(incoming.text);
        if (preamble && !cleaned.toLowerCase().includes(preamble.slice(0, 30).toLowerCase())) {
          cleaned = `${preamble}\n\n${cleaned}`;
        }

        // Image queries: ALWAYS forward to admin group for human review.
        // The admin sees the image + LLM draft; admin can /acc to deliver the
        // draft as-is or /edit to revise before delivering. This covers:
        //   • bare photo (no caption) — admin needs to see the actual image
        //   • photo + caption — admin can sanity-check before it reaches user
        //   • any "unclear reading" case — no longer a separate branch
        // The user is told we're forwarding; they wait for the admin's /acc or /edit.
        if (incoming.image) {
          const isBarePhoto = !incoming.text || incoming.text === '(gambar dilampirkan)';
          const captionLine = isBarePhoto
            ? ''
            : `CAPTION USER (as-is):\n${incoming.text}\n\n`;

          if (isBarePhoto) {
            // Bare photo: buffer the image for 90 seconds. The user may follow
            // up with the actual question. Reply that we've received it and
            // are waiting for the text.
            console.log(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} bare photo → buffering 90s for follow-up text`);
            this.bufferedImages.set(incoming.userId, {
              channel: incoming.channel,
              image: incoming.image,
              ts: Date.now(),
            });
            this.saveBufferedImages();

            // When the 90s window elapses, check if the image is still
            // buffered (i.e. no follow-up text arrived). If so, forward the
            // bare image to the admin group for manual handling.
            const bareImage = incoming.image;
            const bareChannel = incoming.channel;
            const bareUserId = incoming.userId;
            const bareUserName = incoming.userName;
            const bufferKey = `${bareChannel}:${bareUserId}`;
            setTimeout(() => {
              const stillBuffered = this.bufferedImages.get(bareUserId);
              if (!stillBuffered) return; // merged with follow-up text already
              this.bufferedImages.delete(bareUserId);
              this.saveBufferedImages();
              const tg = this.adapters.get('telegram');
              const reviewDest = config.TELEGRAM_REVIEW_GROUP_ID || config.WHATSAPP_ADMIN_CHAT_ID;
              if (tg && reviewDest) {
                const who = bareUserName ? `${bareUserName} (${bareUserId})` : bareUserId;
                const reviewId = `R${++this.reviewSeq}`;
                this.pendingReviews.set(reviewId, {
                  channel: bareChannel,
                  target: bareUserId,
                  question: '(gambar dilampirkan, tanpa caption)',
                  draft: '(belum ada jawaban — ketik /edit ' + reviewId + ' <jawaban>)',
                  ts: Date.now(),
                });
                this.saveReviews();
                logAudit({ t: Date.now(), u: bareUserId, uname: bareUserName, c: bareChannel, q: '(gambar dilampirkan, tanpa caption)', a: '(tidak ada caption — hanya gambar)', src: 'review', rid: reviewId });
                tg.send({
                  channel: 'telegram',
                  userId: reviewDest,
                  text: `🖼️ GAMBAR TANPA CAPTION — ${bareChannel.toUpperCase()}\nDari: ${who}\n\nUser mengirim gambar tanpa teks. ID: ${reviewId}\nBalas: /edit ${reviewId} <jawaban> untuk menjawab.`,
                  image: bareImage,
                }).catch((e) => console.error('[Router] bare-photo admin-forward error:', e));
              }
            }, 90_000);

            await adapter.send({
              channel: incoming.channel,
              userId: incoming.userId,
              text: 'Terima kasih atas gambarnya, Sejawat. Saya simpan dulu. Silakan ketik pertanyaan / penjelasannya setelah ini — saya akan menggabungkannya dengan gambar tersebut untuk menjawab.',
            });
            return;
          }

          // Photo WITH caption: forward to admin with image + verbatim caption + LLM draft
          console.log(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} name=${incoming.userName} image+caption query → forward to admin group`);
          const reviewId = `R${++this.reviewSeq}`;
          this.pendingReviews.set(reviewId, {
            channel: incoming.channel,
            target: incoming.userId,
            question: incoming.text,
            draft: cleaned,
            ts: Date.now(),
          });
          this.saveReviews();
          logAudit({ t: Date.now(), u: incoming.userId, uname: incoming.userName, c: incoming.channel, q: incoming.text, a: cleaned, src: 'review', rid: reviewId });
          // Tell the user it's being reviewed
          await adapter.send({
            channel: incoming.channel,
            userId: incoming.userId,
            text: 'Terima kasih, Sejawat. Pertanyaan dan gambar Sejawat kami teruskan kepada tim terkait untuk ditinjau. Jawaban akan kami sampaikan segera setelah ditinjau. Mohon menunggu.',
          });
          appendHistory(key, incoming.text, 'teruskan ke tim terkait');
          appendTranscript(incoming.userId, incoming.userName || '', {
            timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
            question: incoming.text,
            answer: 'teruskan ke tim terkait',
            source: 'review',
            reviewId,
          });
          const tg = this.adapters.get('telegram');
          const reviewDest = config.TELEGRAM_REVIEW_GROUP_ID || config.WHATSAPP_ADMIN_CHAT_ID;
          if (tg && reviewDest) {
            const who = incoming.userName ? `${incoming.userName} (${incoming.userId})` : incoming.userId;
            await tg.send({
              channel: 'telegram',
              userId: reviewDest,
              text: `🖼️ REVIEW GAMBAR — ${incoming.channel.toUpperCase()}\nDari: ${who}\n\n${captionLine}DRAF LLM:\n${cleaned}\n\nID: ${reviewId}\nBalas: /acc ${reviewId} = kirim draft ke user | /edit ${reviewId} <jawaban> = perbaiki & kirim | /reject ${reviewId} = tolak`,
              image: incoming.image,
            });
          }
          return;
        }

        // Post-process: if the answer isn't in the knowledge base, escalate to the
        // human team and record it for the nightly curation batch.
        // For image queries, the LLM already analyzed the image — do not
        // escalate to "unanswered" just because the KB has no matching text;
        // only escalate when the LLM explicitly flags the image as unclear.
        const cantAnswer = /maaf.*(informasi|jawaban).*tidak|tidak.*(mengandung|dapat|bisa|menemukan).*(informasi|jawaban)|mohon maaf.*tidak\b|materi tidak (menyebut|menjelas|memuat|mengandung)|tidak (disebut|dijelas|diatur|tercantum|tersedia)/i;
        if ((cantAnswer.test(cleaned) || isUnanswered(answer)) && !incoming.image) {
          const uid = saveUnanswered(incoming.text, answer, incoming.channel, incoming.userId);
          const escalation = 'Pertanyaan Sejawat akan kami teruskan kepada tim terkait, mohon menunggu.';
          logAudit({ t: Date.now(), u: incoming.userId, uname: incoming.userName, c: incoming.channel, q: incoming.text, a: escalation, src: 'unanswered', rid: uid });
          await adapter.send({ channel: incoming.channel, userId: incoming.userId, text: escalation });
          // Store in conversation history for follow-up context
          appendHistory(key, incoming.text, escalation);
          // Document in user transcript
          appendTranscript(incoming.userId, incoming.userName || '', {
            timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
            question: incoming.text,
            answer: escalation,
            source: 'unanswered',
            reviewId: uid,
          });
          // Send to review group as R-ID so admin can /edit with the answer
          const tg = this.adapters.get('telegram');
          const reviewDest = config.TELEGRAM_REVIEW_GROUP_ID || config.WHATSAPP_ADMIN_CHAT_ID;
          if (tg && reviewDest) {
            const reviewId = `R${++this.reviewSeq}`;
            this.pendingReviews.set(reviewId, {
              channel: incoming.channel,
              target: incoming.userId,
              question: incoming.text,
              draft: '(belum ada jawaban — ketik /edit ' + reviewId + ' <jawaban>)',
              ts: Date.now(),
            });
            this.saveReviews();
            const who = incoming.userName ? `${incoming.userName} (${incoming.userId})` : incoming.userId;
            await tg.send({
              channel: 'telegram',
              userId: reviewDest,
              text: `❓ TIDAK TERJAWAB — ${incoming.channel.toUpperCase()}\nDari: ${who}\n\nPERTANYAAN:\n${incoming.text}\n\nID: ${uid} | R-ID: ${reviewId}\nBalas: /edit ${reviewId} <jawaban> untuk menjawab.`,
            });
          }
          return;
        }

        messages.push({ role: 'assistant', content: cleaned });
        if (messages.length > MAX_HISTORY * 2) {
          messages.splice(0, 2);
        }
        // Persist conversation history to per-user file (race-safe)
        {
          const { writeHistory } = await import('./conversation-store.js');
          writeHistory(key, messages);
        }
        // Document in user transcript
        appendTranscript(incoming.userId, incoming.userName || '', {
          timestamp: new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
          question: incoming.text,
          answer: cleaned,
          source: src,
        });

        // Auto-answer mode (training/review mode disabled): deliver the answer
        // directly to the user instead of holding it for admin /acc. Review
        // commands (/acc, /edit, /reject, /reopen) still work from the review
        // group for the records kept in audit-log.jsonl.
        const reviewId = `R${++this.reviewSeq}`;
        logAudit({ t: Date.now(), u: incoming.userId, uname: incoming.userName, c: incoming.channel, q: incoming.text, a: cleaned, src, rid: reviewId });
        console.log(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} name=${incoming.userName} src=${src} rid=${reviewId} answer=${cleaned.slice(0, 80)}`);
        await this.send(adapter, incoming.userId, cleaned);
      }
    } catch (err) {
      console.error(`[Router][${new Date().toISOString()}] [${incoming.channel}] user=${incoming.userId} error:`, err);

      await adapter.send({
        channel: incoming.channel,
        userId: incoming.userId,
        text: 'Sorry, something went wrong. Please try again.',
      });
    }
  }

  async startAll() {
    this.loadReviews();
    this.loadBufferedImages();
    await knowledgeBase.load();

    const self = this;
    for (const adapter of this.adapters.values()) {
      await adapter.start(async (msg: IncomingMessage) => {
        await self.handleMessage(msg);
      });
    }

    console.log(`[Router] Started ${this.adapters.size} channel(s)`);
  }

  async dryRun(query: string) {
    const [ragResult, contactChunks] = await Promise.all([
      knowledgeBase.search(query),
      knowledgeBase.searchContacts(query),
    ]);
    let combined = ragResult.context;
    if (contactChunks) combined += '\n\n' + contactChunks;
    let userContent = query;
    if (combined.trim()) {
      userContent = `Answer using the reference material below. If the material doesn't contain the answer, say so.\n\n${combined}\n\nQuestion: ${query}`;
    }
    const messages: ChatMessage[] = [{ role: 'user', content: userContent }];
    const answer = await llmClient.chat(messages);
    return { contextFound: !!combined.trim(), expanded: ragResult.expanded, answer };
  }

  async stopAll() {
    for (const adapter of this.adapters.values()) {
      await adapter.stop();
    }
  }
}
