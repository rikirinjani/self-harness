import { appendFileSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import type { AuditEntry } from './audit-log.js';

const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
const USERS_DIR = join(DATA_DIR, '..', 'docs', 'users');
const AUDIT_GLOB = 'audit-';

mkdirSync(USERS_DIR, { recursive: true });

interface TranscriptEntry {
  timestamp: string;
  question: string;
  answer: string;
  source: string;
  reviewId?: string;
  admin?: string;
}

/** Append one Q&A entry to a user's transcript file. */
export function appendTranscript(userId: string, userName: string, entry: TranscriptEntry) {
  const file = join(USERS_DIR, `${userId}.md`);

  // Create header if new file
  if (!existsSync(file)) {
    const header = `# Transkrip Percakapan — ${userName || userId}\n\n` +
      `**User ID:** ${userId}\n` +
      `**Nama:** ${userName || '(tidak diketahui)'}\n` +
      `**Dibuat:** ${new Date().toISOString()}\n\n---\n\n`;
    writeFileSync(file, header, 'utf-8');
  }

  const srcLabel: Record<string, string> = {
    curated: '📌 Jawaban Baku',
    llm: '🤖 AI (LLM)',
    'llm-retry': '🤖 AI (retry)',
    review: '👁 Review',
    unanswered: '❓ Belum Terjawab',
    vague: '💬 Vague',
    edit: '✏️ Admin Edit',
    acc: '✅ Admin Approve',
  };

  const adminNote = entry.admin ? ` (oleh: ${entry.admin})` : '';
  const ridNote = entry.reviewId ? ` [${entry.reviewId}]` : '';

  const block =
    `### ${entry.timestamp}${ridNote}\n\n` +
    `**Pertanyaan:**\n${entry.question}\n\n` +
    `**Jawaban (${srcLabel[entry.source] || entry.source})${adminNote}:**\n${entry.answer}\n\n---\n\n`;

  appendFileSync(file, block, 'utf-8');
}

/** Rebuild all user transcripts from audit log files. Call once on startup or manually. */
export function rebuildAllTranscripts(): { users: number; entries: number } {
  // Read all audit files
  const files = existsSync(DATA_DIR)
    ? require('fs').readdirSync(DATA_DIR).filter((f: string) => f.startsWith(AUDIT_GLOB) && f.endsWith('.jsonl'))
    : [];

  const byUser = new Map<string, { name: string; entries: TranscriptEntry[] }>();

  for (const file of files.sort()) {
    const lines = readFileSync(join(DATA_DIR, file), 'utf-8').split('\n').filter(Boolean);
    for (const line of lines) {
      try {
        const e: AuditEntry = JSON.parse(line);
        if (!byUser.has(e.u)) {
          byUser.set(e.u, { name: e.uname || '', entries: [] });
        }
        const user = byUser.get(e.u)!;
        if (e.uname) user.name = e.uname;

        user.entries.push({
          timestamp: new Date(e.t).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }),
          question: e.q,
          answer: e.a,
          source: e.src,
          reviewId: e.rid,
          admin: e.admin,
        });
      } catch { /* skip malformed */ }
    }
  }

  // Write each user's transcript
  let totalEntries = 0;
  for (const [userId, data] of byUser) {
    const file = join(USERS_DIR, `${userId}.md`);
    const header = `# Transkrip Percakapan — ${data.name || userId}\n\n` +
      `**User ID:** ${userId}\n` +
      `**Nama:** ${data.name || '(tidak diketahui)'}\n` +
      `**Total Percakapan:** ${data.entries.length}\n` +
      `**Dibuat:** ${new Date().toISOString()} (rebuild dari audit log)\n\n---\n\n`;

    const srcLabel: Record<string, string> = {
      curated: '📌 Jawaban Baku',
      llm: '🤖 AI (LLM)',
      'llm-retry': '🤖 AI (retry)',
      review: '👁 Review',
      unanswered: '❓ Belum Terjawab',
      vague: '💬 Vague',
      edit: '✏️ Admin Edit',
      acc: '✅ Admin Approve',
    };

    let body = '';
    for (const e of data.entries) {
      const adminNote = e.admin ? ` (oleh: ${e.admin})` : '';
      const ridNote = e.reviewId ? ` [${e.reviewId}]` : '';
      body +=
        `### ${e.timestamp}${ridNote}\n\n` +
        `**Pertanyaan:**\n${e.question}\n\n` +
        `**Jawaban (${srcLabel[e.source] || e.source})${adminNote}:**\n${e.answer}\n\n---\n\n`;
    }

    writeFileSync(file, header + body, 'utf-8');
    totalEntries += data.entries.length;
  }

  return { users: byUser.size, entries: totalEntries };
}

/** Get transcript file path for a user. */
export function getTranscriptPath(userId: string): string {
  return join(USERS_DIR, `${userId}.md`);
}
