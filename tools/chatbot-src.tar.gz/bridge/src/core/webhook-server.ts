import http from 'http';

type WebhookHandler = (body: unknown) => Promise<void>;
type VerifyHandler = (mode: string, token: string, challenge: string) => boolean;

interface WebhookRoute {
  path: string;
  verifyToken: string;
  onVerify?: VerifyHandler;
  onMessage: WebhookHandler;
}

export class WebhookServer {
  private server?: http.Server;
  private routes: WebhookRoute[] = [];

  register(route: WebhookRoute) {
    this.routes.push(route);
  }

  private handleRequest(req: http.IncomingMessage, res: http.ServerResponse) {
    const url = req.url || '';
    const match = url.match(/^\/webhook\/(\w+)/);
    if (!match) return this.notFound(res);

    const channel = match[1];
    const route = this.routes.find((r) => r.path === channel);
    if (!route) return this.notFound(res);

    if (req.method === 'GET') {
      const u = new URL(url, 'http://localhost');
      const mode = u.searchParams.get('hub.mode') || '';
      const token = u.searchParams.get('hub.verify_token') || '';
      const challenge = u.searchParams.get('hub.challenge') || '';

      if (mode === 'subscribe' && token === route.verifyToken) {
        console.log(`[Webhook] ${route.path} verified`);
        res.writeHead(200);
        res.end(challenge);
      } else {
        res.writeHead(403);
        res.end();
      }
      return;
    }

    if (req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => (body += chunk));
      req.on('end', () => {
        res.writeHead(200);
        res.end();
        try {
          const parsed = JSON.parse(body);
          route.onMessage(parsed).catch((err) => {
            console.error(`[Webhook] ${route.path} error:`, err);
          });
        } catch {
          // invalid JSON, ignore
        }
      });
      return;
    }

    this.notFound(res);
  }

  private notFound(res: http.ServerResponse) {
    res.writeHead(404);
    res.end();
  }

  async start(port: number) {
    return new Promise<void>((resolve) => {
      this.server = http.createServer((req, res) => this.handleRequest(req, res));
      this.server.listen(port, () => {
        console.log(`[Webhook] Server listening on port ${port}`);
        resolve();
      });
    });
  }

  async stop() {
    return new Promise<void>((resolve) => {
      if (this.server) this.server.close(() => resolve());
      else resolve();
    });
  }
}
