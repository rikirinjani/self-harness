import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
const CURATED_FILE = join(DATA_DIR, 'curated.json');

export interface CuratedEntry {
  question: string;
  answer: string;
  /** Which admin command produced this entry: edit | resolve | kb_merge | manual */
  origin: string;
  ts: number;
  /** Topic tags for filtering: ukom-resertifikasi, skp, str, sip, serkom, dll */
  tags?: string[];
}

/** Indonesian + English stopwords that carry no topical signal. */
const STOPWORDS = new Set([
  'yang', 'untuk', 'dari', 'dengan', 'pada', 'adalah', 'atau', 'dan', 'ini', 'itu',
   'ke', 'di', 'dalam', 'akan', 'sudah', 'belum', 'tidak', 'dapat', 'ada',
  'apa', 'apakah', 'bagaimana', 'gimana', 'kenapa', 'mengapa', 'kapan', 'dimana',
  'saya', 'kami', 'kita', 'anda', 'mohon', 'silakan', 'terima', 'kasih', 'izin',
  'ijin', 'bertanya', 'tanya', 'jika', 'kalau', 'sebagai', 'oleh', 'juga', 'agar',
  'kasus', 'the', 'and', 'for', 'with', 'that', 'this', 'are', 'was', 'has', 'not',
]);

function tokens(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOPWORDS.has(w));
}

/** Levenshtein distance, capped for short strings — tolerates admin/user typos. */
function editDistance(a: string, b: string): number {
  if (a === b) return 0;
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(
        prev[j] + 1,
        cur[j - 1] + 1,
        prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    prev = cur;
  }
  return prev[n];
}

/** Two tokens count as the same word if they are equal or one short edit apart. */
function tokenMatches(a: string, b: string): boolean {
  if (a === b) return true;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen < 5) return false;
  return editDistance(a, b) <= (maxLen >= 8 ? 2 : 1);
}

/**
 * Fuzzy overlap score between a user query and a curated question.
 * Returns coverage of the curated question's tokens by the query (0..1),
 * which makes a longer, chattier user message still match a short FAQ question.
 */
function coverage(queryTokens: string[], entryTokens: string[]): number {
  if (entryTokens.length === 0) return 0;
  let hit = 0;
  for (const et of entryTokens) {
    if (queryTokens.some(qt => tokenMatches(qt, et))) hit++;
  }
  return hit / entryTokens.length;
}

function load(): CuratedEntry[] {
  try {
    if (!existsSync(CURATED_FILE)) return [];
    const parsed = JSON.parse(readFileSync(CURATED_FILE, 'utf-8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('[Curated] load failed:', err);
    return [];
  }
}

function persist(entries: CuratedEntry[]) {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(CURATED_FILE, JSON.stringify(entries, null, 2), 'utf-8');
  } catch (err) {
    console.error('[Curated] save failed:', err);
  }
}

/**
 * Record an admin-authored answer as canonical. Future matching questions are
 * answered with this exact text, with no LLM paraphrasing.
 */
export function saveCurated(question: string, answer: string, origin: string): void {
  const q = question.replace(/^Kasus\s*\d+:\s*/i, '').replace(/\s+/g, ' ').trim();
  const a = answer.trim();
  if (!q || !a) return;

  const entries = load();
  const qt = tokens(q);
  // Replace an existing near-identical question instead of stacking duplicates.
  const idx = entries.findIndex(e => {
    const et = tokens(e.question);
    return coverage(qt, et) >= 0.85 && coverage(et, qt) >= 0.85;
  });
  const rec: CuratedEntry = { question: q, answer: a, origin, ts: Date.now() };
  if (idx >= 0) entries[idx] = rec;
  else entries.push(rec);
  persist(entries);
  console.log(`[Curated] stored (${origin}): ${q.slice(0, 70)}`);
}

/**
 * Look for a curated answer matching the query. Requires strong coverage of the
 * curated question's keywords so unrelated questions never hijack an answer.
 */
export function findCurated(query: string, threshold = 0.8): CuratedEntry | null {
  const entries = load();
  if (entries.length === 0) return null;

  const qt = tokens(query);
  if (qt.length === 0) return null;

  let best: CuratedEntry | null = null;
  let bestScore = 0;
  for (const e of entries) {
    const et = tokens(e.question);
    if (et.length === 0) continue;
    const score = coverage(qt, et);
    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  }
  return bestScore >= threshold ? best : null;
}

export function listCurated(): CuratedEntry[] {
  return load().sort((a, b) => b.ts - a.ts);
}

export function removeCurated(question: string): boolean {
  const entries = load();
  const qt = tokens(question);
  const next = entries.filter(e => coverage(qt, tokens(e.question)) < 0.85);
  if (next.length === entries.length) return false;
  persist(next);
  return true;
}
