import { appendFileSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
const LOG_FILE = join(DATA_DIR, 'questions.jsonl');
const UNANSWERED_FILE = join(DATA_DIR, 'unanswered.md');
const UNANSWERED_JSONL = join(DATA_DIR, 'unanswered.jsonl');
const KNOWLEDGE_DIR = join(import.meta.dirname, '..', '..', 'knowledge');
const RESOLVED_KB_FILE = join(KNOWLEDGE_DIR, '[faq]', '_resolved.md');

mkdirSync(DATA_DIR, { recursive: true });

const cantAnswerPatterns = [
  'tidak dapat menjawab', 'tidak bisa menjawab', 'tidak menemukan informasi',
  'tidak terdapat informasi', 'tidak ada informasi', 'maaf, saya tidak',
  'say so', `doesn't contain the answer`, 'tidak memiliki informasi',
  'mohon maaf', 'tidak ditemukan',
];

export function logQuestion(text: string, channel: string, userId: string) {
  const entry = JSON.stringify({ t: Date.now(), q: text, c: channel, u: userId });
  appendFileSync(LOG_FILE, entry + '\n', 'utf-8');
}

export function isUnanswered(response: string): boolean {
  const lower = response.toLowerCase();
  return cantAnswerPatterns.some(p => lower.includes(p));
}

interface UnansweredRecord {
  id: string;
  t: number;
  q: string;
  c: string;
  u: string;
  resolved: boolean;
  answer?: string;
  resolvedAt?: number;
}

function readUnanswered(): UnansweredRecord[] {
  if (!existsSync(UNANSWERED_JSONL)) return [];
  return readFileSync(UNANSWERED_JSONL, 'utf-8').trim().split('\n').filter(Boolean)
    .map(l => { try { return JSON.parse(l) as UnansweredRecord; } catch { return null; } })
    .filter((r): r is UnansweredRecord => r !== null);
}

function writeUnanswered(records: UnansweredRecord[]) {
  writeFileSync(UNANSWERED_JSONL, records.map(r => JSON.stringify(r)).join('\n') + (records.length ? '\n' : ''), 'utf-8');
}

export function saveUnanswered(question: string, answer: string, channel = '', userId = ''): string {
  const records = readUnanswered();
  // Dedup: if the same question is already pending (unresolved), don't add again.
  const norm = question.trim().toLowerCase();
  const existing = records.find(r => !r.resolved && r.q.trim().toLowerCase() === norm);
  if (existing) return existing.id;

  const maxId = records.reduce((m, r) => {
    const n = parseInt(String(r.id).replace(/\D/g, ''), 10);
    return Number.isFinite(n) && n > m ? n : m;
  }, 0);
  const id = `U${maxId + 1}`;

  records.push({ id, t: Date.now(), q: question, c: channel, u: userId, resolved: false });
  writeUnanswered(records);

  const entry = `\n## ${new Date().toISOString().slice(0, 10)} [${id}]\n**Q:** ${question}\n**Bot:** ${answer.slice(0, 500)}\n`;
  appendFileSync(UNANSWERED_FILE, entry, 'utf-8');
  return id;
}

// Resolve an unanswered question by id: mark it resolved and append the Q&A to
// the knowledge base so future queries are answered automatically.
export function resolveUnanswered(id: string, answer: string): { ok: boolean; question?: string; error?: string } {
  const records = readUnanswered();
  const rec = records.find(r => r.id.toLowerCase() === id.toLowerCase());
  if (!rec) return { ok: false, error: `ID ${id} tidak ditemukan.` };
  if (rec.resolved) return { ok: false, error: `${id} sudah terselesaikan sebelumnya.` };

  rec.resolved = true;
  rec.answer = answer;
  rec.resolvedAt = Date.now();
  writeUnanswered(records);

  // Append to the knowledge base as a FAQ entry (## heading => its own chunk).
  mkdirSync(join(KNOWLEDGE_DIR, '[faq]'), { recursive: true });
  const kbEntry = `\n## ${rec.q.trim()}\n${answer.trim()}\n`;
  appendFileSync(RESOLVED_KB_FILE, kbEntry, 'utf-8');

  return { ok: true, question: rec.q };
}

/** Mark the first unresolved record matching `question` as resolved. Used by /acc and /edit. */
export function resolveUnansweredByQuestion(question: string, answer: string): boolean {
  const records = readUnanswered();
  const norm = question.trim().toLowerCase();
  const rec = records.find(r => !r.resolved && r.q.trim().toLowerCase() === norm);
  if (!rec) return false;
  rec.resolved = true;
  rec.answer = answer;
  rec.resolvedAt = Date.now();
  writeUnanswered(records);
  return true;
}

export function listUnresolved(): UnansweredRecord[] {
  return readUnanswered().filter(r => !r.resolved).sort((a, b) => a.t - b.t);
}

// Returns { total, channels, questions[], unanswered[] } for questions logged since `sinceTs`.
export function getDaySummary(sinceTs: number) {
  const skipCommands = ['/daily', '/report', '/laporan', '/batal', '/cancel', '/id', '/start', '/help', '/pair', '/qr', '/recap', '/fullrecap', '/followup', '/resolve'];
  let questions: any[] = [];
  if (existsSync(LOG_FILE)) {
    questions = readFileSync(LOG_FILE, 'utf-8').trim().split('\n').filter(Boolean)
      .map(l => { try { return JSON.parse(l); } catch { return null; } })
      .filter(q => q && q.t >= sinceTs && !skipCommands.includes(String(q.q).trim().toLowerCase()));
  }
  const tg = questions.filter(q => q.c === 'telegram').length;
  const wa = questions.filter(q => q.c === 'whatsapp').length;
  return { total: questions.length, tg, wa, questions };
}

// Daily recap for the review group — TOTALS only.
export function buildDailyRecap(sinceTs: number, dateLabel: string): string {
  const s = getDaySummary(sinceTs);
  const pending = listUnresolved().length;
  let out = `📊 REKAP HARIAN — ${dateLabel}\n\n`;
  out += `Total pertanyaan: ${s.total}  (📱 Telegram: ${s.tg} • 💬 WhatsApp: ${s.wa})\n`;
  out += `Belum terjawab (akumulasi, perlu tindak lanjut): ${pending}\n`;
  out += `\nKetik /fullrecap untuk daftar pertanyaan lengkap.`;
  return out;
}

// Full recap — every question verbatim (only when explicitly asked).
export function buildFullRecap(sinceTs: number, dateLabel: string): string {
  const s = getDaySummary(sinceTs);
  let out = `🧾 REKAP LENGKAP — ${dateLabel}\n\nTotal: ${s.total}  (📱 ${s.tg} • 💬 ${s.wa})\n`;
  if (s.total === 0) { out += `\nBelum ada pertanyaan.`; return out; }
  out += `\n— DAFTAR PERTANYAAN —\n`;
  s.questions.forEach((q: any, i: number) => {
    const ch = q.c === 'telegram' ? '📱' : q.c === 'whatsapp' ? '💬' : '•';
    const time = new Date(q.t).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    out += `${i + 1}. ${ch} [${time}] ${q.q}\n`;
  });
  return out;
}

// The accumulated list of unresolved questions to be answered by a human admin.
export function buildUnansweredList(_sinceTs: number, dateLabel: string): string {
  const pending = listUnresolved();
  if (pending.length === 0) {
    return `✅ DAFTAR TINDAK LANJUT — ${dateLabel}\n\nSemua pertanyaan sudah terjawab. 🎉`;
  }
  let out = `📝 DAFTAR TINDAK LANJUT — ${dateLabel}\nPertanyaan yang belum ada di knowledge base (${pending.length}, akumulasi):\n\n`;
  pending.forEach((q) => {
    const ch = q.c === 'telegram' ? '📱' : q.c === 'whatsapp' ? '💬' : '•';
    const day = new Date(q.t).toLocaleDateString('id-ID');
    out += `${q.id}. ${ch} [${day}] ${q.q}\n`;
  });
  out += `\nUntuk menjawab: /resolve <ID> <jawaban>\nContoh: /resolve ${pending[0].id} Estimasi koreksi 3-5 hari kerja.`;
  return out;
}

export function generateReport(): string {
  if (!existsSync(LOG_FILE)) return 'Belum ada pertanyaan hari ini.';

  const lines = readFileSync(LOG_FILE, 'utf-8').trim().split('\n').filter(Boolean);
  const allQuestions = lines.map(l => JSON.parse(l));

  const skipCommands = ['/daily', '/report', '/laporan', '/batal', '/cancel', '/id'];
  const today = allQuestions.filter(q => q.t > Date.now() - 86400000 && !skipCommands.includes(q.q.trim().toLowerCase()));
  if (today.length === 0) return 'Belum ada pertanyaan hari ini.';

  // Build report
  let report = `📊 *LAPORAN HARIAN*\n${new Date().toISOString().slice(0, 10)}\n\n`;
  report += `*Total pertanyaan:* ${today.length}\n\n`;

  for (let i = 0; i < today.length; i++) {
    const q = today[i];
    const time = new Date(q.t).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const label = q.c === 'telegram' ? '📱' : '💬';
    report += `${label} [${time}] ${q.q}\n`;
  }

  // Unanswered at the end
  const unanswered = allQuestions.filter(q => q.unanswered);
  if (unanswered.length > 0) {
    report += `\n⚠️ *Pertanyaan tidak terjawab:* ${unanswered.length}\n`;
    for (const q of unanswered.slice(-5)) {
      report += `  • ${q.q}\n`;
    }
  }

  return report;
}

export function getDailyStats(): string {
  if (!existsSync(LOG_FILE)) return '[]';
  const lines = readFileSync(LOG_FILE, 'utf-8').trim().split('\n').filter(Boolean);
  return lines.slice(-50).map(l => { const d = JSON.parse(l); return `[${new Date(d.t).toISOString().slice(0, 16)}] ${d.q}`; }).join('\n');
}
