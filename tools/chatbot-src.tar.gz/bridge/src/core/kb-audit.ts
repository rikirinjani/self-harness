import { readFileSync, writeFileSync, existsSync, readdirSync, statSync, appendFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { saveCurated } from './curated.js';

const KNOWLEDGE_DIR = join(import.meta.dirname, '..', '..', 'knowledge');
const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
const AUDIT_STATE = join(DATA_DIR, 'kb-audit.json');
const RESOLVED_KB_FILE = join(KNOWLEDGE_DIR, '[faq]', '_resolved.md');

export interface KBEntry {
  question: string;
  answer: string;
  source: string;
  path: string;
  /** Exact text block as it appears in the file, used for precise removal. */
  raw: string;
}

/** Indonesian + English stopwords that carry no topical signal. */
const STOPWORDS = new Set([
  'yang', 'untuk', 'dari', 'dengan', 'pada', 'adalah', 'atau', 'dan', 'ini', 'itu',
  'ke', 'di', 'dalam', 'akan', 'sudah', 'belum', 'tidak', 'bisa', 'dapat', 'ada',
  'apa', 'apakah', 'bagaimana', 'gimana', 'kenapa', 'mengapa', 'kapan', 'dimana',
  'saya', 'kami', 'kita', 'anda', 'mohon', 'silakan', 'terima', 'kasih', 'izin',
  'ijin', 'bertanya', 'tanya', 'jika', 'kalau', 'sebagai', 'oleh', 'juga', 'agar',
  'kasus', 'the', 'and', 'for', 'with', 'that', 'this', 'are', 'was', 'has', 'not',
]);

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2 && !STOPWORDS.has(w)),
  );
}

/** Jaccard similarity over token sets: |A∩B| / |A∪B|. */
function similarity(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter++;
  return inter / (a.size + b.size - inter);
}

/**
 * Parse Q&A pairs out of the knowledge base. Handles both formats we write:
 *   "Q: ...\nA: ..."      (from /edit and legacy /resolve)
 *   "## question\nanswer" (from resolveUnanswered and imported helpdesk docs)
 */
export function parseKBEntries(): KBEntry[] {
  const entries: KBEntry[] = [];
  if (!existsSync(KNOWLEDGE_DIR)) return entries;

  const walk = (dir: string) => {
    for (const name of readdirSync(dir)) {
      const p = join(dir, name);
      let st;
      try { st = statSync(p); } catch { continue; }
      if (st.isDirectory()) {
        walk(p);
        continue;
      }
      if (!name.endsWith('.md')) continue;

      let text: string;
      try { text = readFileSync(p, 'utf-8'); } catch { continue; }

      const qaRe = /^Q:\s*(.+?)\s*$\n+^A:\s*([\s\S]*?)(?=\n{2,}^(?:Q:|##)|\n*$)/gm;
      let m: RegExpExecArray | null;
      while ((m = qaRe.exec(text)) !== null) {
        const q = m[1].trim();
        const a = m[2].trim();
        if (q && a) entries.push({ question: q, answer: a, source: name, path: p, raw: m[0] });
      }

      const hRe = /^##\s+(.+?)\s*$\n([\s\S]*?)(?=\n^##\s|\n^Q:\s|$)/gm;
      while ((m = hRe.exec(text)) !== null) {
        const q = m[1].trim();
        const a = m[2].trim();
        if (q && a && !/^(faq|sumber|daftar)/i.test(q)) {
          entries.push({ question: q, answer: a, source: name, path: p, raw: m[0] });
        }
      }
    }
  };
  walk(KNOWLEDGE_DIR);
  return entries;
}

export interface DuplicateGroup {
  id: string;
  entries: KBEntry[];
  score: number;
}

/**
 * Group KB entries whose questions are near-duplicates. Uses single-link
 * clustering: an entry joins a group if it is similar to any member.
 */
export function findDuplicateGroups(threshold = 0.55): DuplicateGroup[] {
  const entries = parseKBEntries();
  const tokens = entries.map(e => tokenize(e.question));
  const assigned = new Array(entries.length).fill(-1);
  const groups: { idx: number[]; scores: number[] }[] = [];

  for (let i = 0; i < entries.length; i++) {
    for (let j = i + 1; j < entries.length; j++) {
      const s = similarity(tokens[i], tokens[j]);
      if (s < threshold) continue;

      const gi = assigned[i];
      const gj = assigned[j];
      if (gi === -1 && gj === -1) {
        groups.push({ idx: [i, j], scores: [s] });
        assigned[i] = assigned[j] = groups.length - 1;
      } else if (gi !== -1 && gj === -1) {
        groups[gi].idx.push(j);
        groups[gi].scores.push(s);
        assigned[j] = gi;
      } else if (gi === -1 && gj !== -1) {
        groups[gj].idx.push(i);
        groups[gj].scores.push(s);
        assigned[i] = gj;
      } else if (gi !== gj) {
        const from = groups[gj];
        for (const k of from.idx) {
          if (!groups[gi].idx.includes(k)) groups[gi].idx.push(k);
          assigned[k] = gi;
        }
        groups[gi].scores.push(...from.scores, s);
        from.idx = [];
      }
    }
  }

  return groups
    .filter(g => g.idx.length > 1)
    .map(g => ({
      entries: g.idx.map(i => entries[i]),
      score: g.scores.reduce((a, b) => a + b, 0) / g.scores.length,
    }))
    .sort((a, b) => b.entries.length - a.entries.length || b.score - a.score)
    .map((g, i) => ({ id: `G${i + 1}`, ...g }));
}

function saveAuditState(groups: DuplicateGroup[]) {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(AUDIT_STATE, JSON.stringify({ ts: Date.now(), groups }, null, 2), 'utf-8');
  } catch (err) {
    console.error('[KBAudit] failed to save state:', err);
  }
}

function loadAuditState(): { ts: number; groups: DuplicateGroup[] } | null {
  try {
    if (!existsSync(AUDIT_STATE)) return null;
    return JSON.parse(readFileSync(AUDIT_STATE, 'utf-8'));
  } catch {
    return null;
  }
}

/** Build the twice-weekly KB hygiene report and persist group IDs for merging. */
export function buildKBAuditReport(): string {
  const all = parseKBEntries();
  const groups = findDuplicateGroups();
  saveAuditState(groups);

  let out = `🧹 AUDIT KNOWLEDGE BASE\n${new Date().toLocaleDateString('id-ID')}\n\n`;
  out += `Total entri Q&A: ${all.length}\n`;

  if (groups.length === 0) {
    out += `Duplikat: tidak ada. KB bersih. ✅`;
    return out;
  }

  const dupCount = groups.reduce((n, g) => n + g.entries.length, 0);
  out += `Grup mirip: ${groups.length} (${dupCount} entri)\n\n`;

  const shown = groups.slice(0, 8);
  for (const g of shown) {
    out += `${g.id} — ${g.entries.length} entri mirip (${Math.round(g.score * 100)}%)\n`;
    for (const e of g.entries.slice(0, 5)) {
      const q = e.question.replace(/\n/g, ' ').slice(0, 62);
      out += `   • [${e.source}] ${q}${e.question.length > 62 ? '…' : ''}\n`;
    }
    if (g.entries.length > 5) out += `   • …+${g.entries.length - 5} lagi\n`;
    out += '\n';
  }
  if (groups.length > shown.length) {
    out += `…dan ${groups.length - shown.length} grup lainnya.\n\n`;
  }
  out += `Cara rapikan:\n`;
  out += `/kb_show <ID> — lihat semua isi grup\n`;
  out += `/kb_merge <ID> keep <N> — pertahankan entri N, hapus sisanya\n`;
  out += `/kb_merge <ID> <jawaban final> — gabung jadi satu jawaban baru\n`;
  out += `Contoh: /kb_merge ${shown[0].id} keep 1`;
  return out;
}

/** Full detail of one group, so an admin can decide the canonical answer. */
export function showGroup(id: string): string {
  const state = loadAuditState();
  if (!state) return 'Belum ada hasil audit. Jalankan /kb_audit dulu.';
  const g = state.groups.find(x => x.id.toUpperCase() === id.toUpperCase());
  if (!g) return `Grup ${id} tidak ditemukan. Jalankan /kb_audit untuk daftar terbaru.`;

  let out = `🔍 ${g.id} — ${g.entries.length} entri (${Math.round(g.score * 100)}% mirip)\n\n`;
  for (let i = 0; i < g.entries.length; i++) {
    const e = g.entries[i];
    out += `${i + 1}. [${e.source}]\nQ: ${e.question.replace(/\n/g, ' ').slice(0, 120)}\nA: ${e.answer.replace(/\n/g, ' ').slice(0, 220)}${e.answer.length > 220 ? '…' : ''}\n\n`;
  }
  out += `Gabung: /kb_merge ${g.id} keep <N>  (pertahankan satu entri, hapus sisanya)\n`;
  out += `        /kb_merge ${g.id} keep <N> <jawaban baru>  (pertahankan pertanyaan, ganti jawaban)\n`;
  out += `        /kb_merge ${g.id} <jawaban final>  (buat entri gabungan baru)`;
  return out;
}

/**
 * Merge a duplicate group into one entry.
 *
 * Modes:
 *   mergeGroup(id, answer)            → delete all members, write canonical Q + answer
 *   mergeGroup(id, answer, keepIndex) → keep member #keepIndex (1-based), delete the
 *                                       rest. If answer is empty the kept entry is
 *                                       left untouched in place; otherwise its answer
 *                                       is replaced while keeping its question.
 */
export function mergeGroup(
  id: string,
  canonicalAnswer: string,
  keepIndex?: number,
): { ok: boolean; error?: string; removed?: number; question?: string; kept?: boolean; inPlace?: boolean } {
  const state = loadAuditState();
  if (!state) return { ok: false, error: 'Belum ada hasil audit. Jalankan /kb_audit dulu.' };
  const g = state.groups.find(x => x.id.toUpperCase() === id.toUpperCase());
  if (!g) return { ok: false, error: `Grup ${id} tidak ditemukan. Jalankan /kb_audit untuk daftar terbaru.` };

  let keeper: KBEntry | undefined;
  if (keepIndex !== undefined) {
    if (!Number.isInteger(keepIndex) || keepIndex < 1 || keepIndex > g.entries.length) {
      return { ok: false, error: `Nomor entri harus 1–${g.entries.length}. Lihat /kb_show ${g.id}.` };
    }
    keeper = g.entries[keepIndex - 1];
  }

  // Everything except the keeper gets stripped from its source file.
  const toRemove = g.entries.filter(e => e !== keeper);
  const byFile = new Map<string, KBEntry[]>();
  for (const e of toRemove) {
    if (!byFile.has(e.path)) byFile.set(e.path, []);
    byFile.get(e.path)!.push(e);
  }

  let removed = 0;
  for (const [path, list] of byFile) {
    if (!existsSync(path)) continue;
    let text: string;
    try { text = readFileSync(path, 'utf-8'); } catch { continue; }
    for (const e of list) {
      if (e.raw && text.includes(e.raw)) {
        text = text.replace(e.raw, '');
        removed++;
      }
    }
    text = text.replace(/\n{3,}/g, '\n\n');
    try { writeFileSync(path, text, 'utf-8'); } catch (err) {
      console.error(`[KBAudit] failed to rewrite ${path}:`, err);
    }
  }

  const answer = canonicalAnswer.trim();

  // keep N with no new answer: the kept entry already lives in its file, so
  // there is nothing more to write.
  if (keeper && !answer) {
    state.groups = state.groups.filter(x => x.id !== g.id);
    saveAuditState(state.groups);
    return { ok: true, removed, question: keeper.question, kept: true, inPlace: true };
  }

  // keep N with a new answer: rewrite that entry in place, preserving its question.
  if (keeper && answer) {
    try {
      let text = readFileSync(keeper.path, 'utf-8');
      if (keeper.raw && text.includes(keeper.raw)) {
        const isQA = /^Q:/m.test(keeper.raw);
        const block = isQA
          ? `Q: ${keeper.question}\nA: ${answer}\n`
          : `## ${keeper.question}\n${answer}\n`;
        text = text.replace(keeper.raw, block).replace(/\n{3,}/g, '\n\n');
        writeFileSync(keeper.path, text, 'utf-8');
      }
    } catch (err) {
      return { ok: false, error: `Gagal memperbarui entri yang dipertahankan: ${err}` };
    }
    // Admin-authored answers are canonical: serve them verbatim, no paraphrasing.
    saveCurated(keeper.question, answer, 'kb_merge');
    state.groups = state.groups.filter(x => x.id !== g.id);
    saveAuditState(state.groups);
    return { ok: true, removed, question: keeper.question, kept: true, inPlace: false };
  }

  // No keeper: collapse into a single new entry in the resolved FAQ file.
  const canonicalQ = [...g.entries]
    .map(e => e.question.replace(/^Kasus\s*\d+:\s*/i, '').trim())
    .sort((a, b) => a.length - b.length)[0];

  try {
    mkdirSync(join(KNOWLEDGE_DIR, '[faq]'), { recursive: true });
    appendFileSync(RESOLVED_KB_FILE, `\n## ${canonicalQ}\n${answer}\n`, 'utf-8');
  } catch (err) {
    return { ok: false, error: `Gagal menulis jawaban gabungan: ${err}` };
  }

  saveCurated(canonicalQ, answer, 'kb_merge');
  state.groups = state.groups.filter(x => x.id !== g.id);
  saveAuditState(state.groups);

  return { ok: true, removed, question: canonicalQ };
}
