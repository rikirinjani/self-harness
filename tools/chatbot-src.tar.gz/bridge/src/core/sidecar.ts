import { spawn, ChildProcess } from 'child_process';
import { config } from '../config/index.js';

const SIDECAR_PORT = 4100;
const BASE = `http://127.0.0.1:${SIDECAR_PORT}`;

export class SidecarManager {
  private proc: ChildProcess | null = null;
  private stopped = false;
  private onQR?: (png: Uint8Array) => void;

  setQRHandler(h: (png: Uint8Array) => void) {
    this.onQR = h;
  }

  async start() {
    this.stopped = false;
    this.spawn();
    await this.waitReady(30_000);
  }

  private spawn() {
    if (this.proc) this.kill();

    const bin = config.WHATSAPP_SIDECAR_PATH || 'whatsapp-sidecar.exe';
    log(`starting ${bin}`);
    this.proc = spawn(bin, [], {
      env: { ...process.env, PORT: String(SIDECAR_PORT), BRIDGE_URL: `http://127.0.0.1:${config.PORT}` } as any,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    this.proc.stdout?.on('data', (chunk: Buffer) => {
      process.stdout.write(`[sidecar] ${chunk}`);
    });

    this.proc.stderr?.on('data', (chunk: Buffer) => {
      process.stderr.write(`[sidecar:err] ${chunk}`);
    });

    this.proc.on('exit', (code) => {
      log(`exited with code ${code}`);
      this.proc = null;
      if (!this.stopped) this.scheduleRestart();
    });
  }

  private scheduleRestart() {
    setTimeout(() => {
      if (!this.stopped) {
        log('restarting...');
        this.spawn();
        this.waitReady(30_000).catch(() => this.scheduleRestart());
      }
    }, 3000);
  }

  private async waitReady(timeout: number) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      try {
        const r = await fetch(`${BASE}/health`, { signal: AbortSignal.timeout(2000) });
        if (r.ok) {
          log('ready');
          this.checkQR();
          return;
        }
      } catch { /* not ready */ }
      await new Promise(r => setTimeout(r, 1000));
    }
    log('startup timeout');
  }

  private async checkQR() {
    try {
      const r = await fetch(`${BASE}/status`, { signal: AbortSignal.timeout(2000) });
      const s = await r.json() as any;
      if (!s.connected && this.onQR) {
        const qrResp = await fetch(`${BASE}/qr`, { signal: AbortSignal.timeout(2000) });
        if (qrResp.headers.get('content-type')?.includes('image/png')) {
          const buf = new Uint8Array(await qrResp.arrayBuffer());
          this.onQR(buf);
        }
      }
    } catch {}
  }

  async send(to: string, text: string) {
    if (!this.proc) throw new Error('sidecar not running');
    const r = await fetch(`${BASE}/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to, text }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!r.ok) {
      const err = await r.text();
      throw new Error(`send failed (${r.status}): ${err}`);
    }
  }

  async stop() {
    this.stopped = true;
    this.kill();
  }

  private kill() {
    if (this.proc) {
      this.proc.kill('SIGTERM');
      setTimeout(() => this.proc?.kill('SIGKILL'), 3000);
      this.proc = null;
    }
  }
}

function log(msg: string) {
  console.log(`[Sidecar] ${msg}`);
}
