import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, unlinkSync } from 'fs';
import { join } from 'path';
import type { ChatMessage } from './types.js';

const DATA_DIR = join(import.meta.dirname, '..', '..', 'data');
const HIST_DIR = join(DATA_DIR, 'history');
const LEGACY_FILE = join(DATA_DIR, 'conversation-history.json');
const MAX_HISTORY = 10; // per-user message pairs
const EXPIRY_MS = 24 * 60 * 60 * 1000;

mkdirSync(HIST_DIR, { recursive: true });

interface ConversationEntry {
  messages: ChatMessage[];
  lastActive: number;
}

/** Per-user file path — eliminates cross-user read-modify-write races. */
function histFile(key: string): string {
  // key is "channel:userId" — sanitize for filesystem
  const safe = key.replace(/[^a-zA-Z0-9_-]/g, '_');
  return join(HIST_DIR, `${safe}.json`);
}

function readEntry(key: string): ConversationEntry | null {
  const file = histFile(key);
  if (!existsSync(file)) return null;
  try {
    const entry = JSON.parse(readFileSync(file, 'utf-8')) as ConversationEntry;
    // Expire after 24 hours
    if (Date.now() - entry.lastActive > EXPIRY_MS) {
      try { unlinkSync(file); } catch { /* ignore */ }
      return null;
    }
    return entry;
  } catch {
    return null;
  }
}

function writeEntry(key: string, entry: ConversationEntry) {
  try {
    writeFileSync(histFile(key), JSON.stringify(entry), 'utf-8');
  } catch (err) {
    console.error('[ConvStore] write error:', err);
  }
}

/** Get conversation history for a user key (e.g. "telegram:123456"). */
export function getHistory(key: string): ChatMessage[] {
  const entry = readEntry(key);
  return entry ? entry.messages : [];
}

/** Append a user message and assistant response to history. */
export function appendHistory(key: string, userMsg: string, assistantMsg: string) {
  const entry = readEntry(key) ?? { messages: [], lastActive: Date.now() };
  entry.messages.push({ role: 'user', content: userMsg });
  entry.messages.push({ role: 'assistant', content: assistantMsg });
  entry.lastActive = Date.now();
  // Trim to MAX_HISTORY pairs (2 messages each)
  if (entry.messages.length > MAX_HISTORY * 2) {
    entry.messages.splice(0, entry.messages.length - MAX_HISTORY * 2);
  }
  writeEntry(key, entry);
}

/** Overwrite the full history for a user (used by the LLM flow which manages
 *  its own messages array). Trims to MAX_HISTORY pairs. */
export function writeHistory(key: string, messages: ChatMessage[]) {
  const trimmed = messages.length > MAX_HISTORY * 2
    ? messages.slice(messages.length - MAX_HISTORY * 2)
    : messages;
  writeEntry(key, { messages: trimmed, lastActive: Date.now() });
}

/** Clear history for a user. */
export function clearHistory(key: string) {
  const file = histFile(key);
  if (existsSync(file)) {
    try { unlinkSync(file); } catch { /* ignore */ }
  }
}

/** One-time migration: split legacy conversation-history.json into per-user files. */
export function migrateLegacyHistory(): number {
  if (!existsSync(LEGACY_FILE)) return 0;
  try {
    const store = JSON.parse(readFileSync(LEGACY_FILE, 'utf-8')) as Record<string, ConversationEntry>;
    let migrated = 0;
    for (const [key, entry] of Object.entries(store)) {
      // Skip expired entries
      if (Date.now() - entry.lastActive > EXPIRY_MS) continue;
      // Don't overwrite newer per-user files
      if (existsSync(histFile(key))) continue;
      writeEntry(key, entry);
      migrated++;
    }
    if (migrated > 0) {
      // Keep legacy file as backup but rename so we don't re-migrate
      try { writeFileSync(LEGACY_FILE + '.migrated', readFileSync(LEGACY_FILE)); unlinkSync(LEGACY_FILE); } catch { /* ignore */ }
    }
    console.log(`[ConvStore] Migrated ${migrated} user histories from legacy file`);
    return migrated;
  } catch (err) {
    console.error('[ConvStore] migration error:', err);
    return 0;
  }
}

// Migrate on startup
migrateLegacyHistory();