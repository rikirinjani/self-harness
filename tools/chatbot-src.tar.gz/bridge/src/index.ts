import http from 'http';
import { MessageRouter } from './core/router.js';
import { WebhookServer } from './core/webhook-server.js';
import { TelegramAdapter } from './channels/telegram.js';
import { WhatsAppAdapter } from './channels/whatsapp.js';
import { InstagramAdapter } from './channels/instagram.js';
import { FacebookAdapter } from './channels/facebook.js';
import { config } from './config/index.js';
import { buildDailyRecap, buildUnansweredList } from './core/reporter.js';
import { buildKBAuditReport } from './core/kb-audit.js';

const webhook = new WebhookServer();
const router = new MessageRouter();

router.register(new TelegramAdapter());
router.register(new WhatsAppAdapter(webhook));
router.register(new InstagramAdapter(webhook));
router.register(new FacebookAdapter(webhook));

let healthServer: http.Server;

// Post a message to the Telegram review group (or admin DM fallback).
async function postToReviewGroup(text: string) {
  const dest = config.TELEGRAM_REVIEW_GROUP_ID || config.WHATSAPP_ADMIN_CHAT_ID;
  if (!dest) return;
  const tg = router.getAdapter('telegram');
  if (!tg) return;
  try {
    await tg.send({ channel: 'telegram', userId: dest, text });
  } catch (err) {
    console.error('[Scheduler] post to group failed:', err);
  }
}

// Schedule a callback to run daily at the given local hour:minute.
function scheduleDaily(hour: number, minute: number, label: string, fn: () => Promise<void>) {
  const run = async () => {
    try {
      console.log(`[Scheduler] running ${label}`);
      await fn();
    } catch (err) {
      console.error(`[Scheduler] ${label} error:`, err);
    }
    schedule(); // reschedule for the next day
  };
  const schedule = () => {
    const now = new Date();
    const next = new Date(now);
    next.setHours(hour, minute, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    const ms = next.getTime() - now.getTime();
    console.log(`[Scheduler] ${label} next run in ${(ms / 3600000).toFixed(2)}h (${next.toLocaleString('id-ID')})`);
    setTimeout(run, ms);
  };
  schedule();
}

// Schedule a callback to run on specific weekdays (0=Sun..6=Sat) at hour:minute.
function scheduleWeekly(days: number[], hour: number, minute: number, label: string, fn: () => Promise<void>) {
  const run = async () => {
    try {
      console.log(`[Scheduler] running ${label}`);
      await fn();
    } catch (err) {
      console.error(`[Scheduler] ${label} error:`, err);
    }
    schedule();
  };
  const schedule = () => {
    const now = new Date();
    const next = new Date(now);
    next.setHours(hour, minute, 0, 0);
    // Advance to the next allowed weekday (today counts only if still in future).
    while (next <= now || !days.includes(next.getDay())) {
      next.setDate(next.getDate() + 1);
      next.setHours(hour, minute, 0, 0);
    }
    const ms = next.getTime() - now.getTime();
    console.log(`[Scheduler] ${label} next run in ${(ms / 3600000).toFixed(2)}h (${next.toLocaleString('id-ID')})`);
    setTimeout(run, ms);
  };
  schedule();
}

function startSchedulers() {
  if (!config.TELEGRAM_REVIEW_GROUP_ID && !config.WHATSAPP_ADMIN_CHAT_ID) {
    console.log('[Scheduler] no review destination configured; skipping daily jobs');
    return;
  }
  // Midnight (00:00): daily recap of the day that just ended.
  scheduleDaily(0, 0, 'daily-recap', async () => {
    const since = Date.now() - 86400000;
    const label = new Date().toLocaleDateString('id-ID');
    await postToReviewGroup(buildDailyRecap(since, label));
  });
  // 05:00: the follow-up list of unanswered questions from the previous day.
  scheduleDaily(5, 0, 'followup-list', async () => {
    const since = Date.now() - 86400000 - 5 * 3600000; // cover the prior full day
    const label = new Date(Date.now() - 86400000).toLocaleDateString('id-ID');
    await postToReviewGroup(buildUnansweredList(since, label));
  });
  // Monday & Thursday 08:00: knowledge-base hygiene report (similar/duplicate answers).
  scheduleWeekly([1, 4], 8, 0, 'kb-audit', async () => {
    await postToReviewGroup(buildKBAuditReport());
  });
}

async function main() {
  healthServer = http.createServer((_req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
  });
  healthServer.listen(config.HEALTH_PORT, () => {
    console.log('[Health] Listening on :4001');
  });

  await webhook.start(config.PORT);
  await router.startAll();
  startSchedulers();

  process.on('SIGINT', async () => {
    console.log('\n[Bridge] Shutting down...');
    await router.stopAll();
    await webhook.stop();
    process.exit(0);
  });

  process.on('SIGTERM', async () => {
    await router.stopAll();
    await webhook.stop();
    process.exit(0);
  });
}

main().catch((err) => {
  console.error('[Bridge] Fatal:', err);
  process.exit(1);
});
