import { config } from '../config/index.js';
import type { ChannelAdapter, IncomingMessage, MessageHandler, OutgoingMessage } from '../core/types.js';
import type { WebhookServer } from '../core/webhook-server.js';
import { SidecarManager } from '../core/sidecar.js';

export class WhatsAppAdapter implements ChannelAdapter {
  readonly channel = 'whatsapp' as const;
  private onMessage?: MessageHandler;
  private sidecar?: SidecarManager;

  constructor(private webhook?: WebhookServer) {}

  async start(handler: MessageHandler) {
    this.onMessage = handler;

    if (config.WHATSAPP_MODE === 'sidecar') {
      this.sidecar = new SidecarManager();

      this.webhook?.register({
        path: 'whatsapp',
        verifyToken: config.WHATSAPP_VERIFY_TOKEN ?? 'wa_verify',
        onMessage: (body) => this.handleWebhook(body),
      });

      await this.sidecar.start();
      console.log('[WhatsApp] Sidecar mode active');
      return;
    }

    if (!config.WHATSAPP_ACCESS_TOKEN) {
      console.log('[WhatsApp] Disabled: missing WHATSAPP_ACCESS_TOKEN');
      return;
    }

    this.webhook?.register({
      path: 'whatsapp',
      verifyToken: config.WHATSAPP_VERIFY_TOKEN ?? 'wa_verify',
      onMessage: (body) => this.handleWebhook(body),
    });
  }

  async pairQR(adapter: any, userId: string) {
    try {
      const r = await fetch('http://127.0.0.1:4100/qr');
      if (r.headers.get('content-type')?.includes('image/png')) {
        const buf = await r.arrayBuffer();
        const url = `https://api.telegram.org/bot${config.TELEGRAM_BOT_TOKEN}/sendPhoto`;
        const form = new FormData();
        form.append('chat_id', userId);
        form.append('photo', new Blob([buf], { type: 'image/png' }), 'qr.png');
        form.append('caption', 'Scan this QR to pair WhatsApp');
        await fetch(url, { method: 'POST', body: form });
        return 'QR sent!';
      }
      return 'No QR available. Sidecar not started?';
    } catch { return 'Sidecar not running.'; }
  }

  private async handleWebhook(body: any) {
    if (!this.onMessage) return;

    const entries = body?.entry ?? [];
    for (const entry of entries) {
      const changes = entry?.changes ?? [];
      for (const change of changes) {
        const messages = change?.value?.messages ?? [];
        for (const msg of messages) {
          if (msg.type !== 'text') continue;

          const incoming: IncomingMessage = {
            id: msg.id,
            channel: 'whatsapp',
            userId: msg.from,
            userName: msg.from,
            text: msg.text.body,
            timestamp: new Date((msg.timestamp || 0) * 1000),
            raw: msg,
          };

          await this.onMessage(incoming);
        }
      }
    }
  }

  async send(msg: OutgoingMessage) {
    if (this.sidecar) {
      await this.sidecar.send(msg.userId, msg.text);
      return;
    }

    const url = `https://graph.facebook.com/v21.0/${config.WHATSAPP_PHONE_NUMBER_ID}/messages`;
    await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.WHATSAPP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: msg.userId,
        text: { body: msg.text },
      }),
    });
  }

  async stop() {
    await this.sidecar?.stop();
  }
}
