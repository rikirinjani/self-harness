import { config } from '../config/index.js';
import type { ChannelAdapter, IncomingMessage, MessageHandler, OutgoingMessage } from '../core/types.js';
import type { WebhookServer } from '../core/webhook-server.js';

export class InstagramAdapter implements ChannelAdapter {
  readonly channel = 'instagram' as const;
  private onMessage?: MessageHandler;

  constructor(private webhook?: WebhookServer) {}

  async start(handler: MessageHandler) {
    this.onMessage = handler;

    if (!config.IG_ACCESS_TOKEN) {
      console.log('[Instagram] Disabled: missing IG_ACCESS_TOKEN');
      return;
    }

    this.webhook?.register({
      path: 'instagram',
      verifyToken: config.IG_VERIFY_TOKEN ?? 'ig_verify',
      onMessage: (body) => this.handleWebhook(body),
    });
  }

  private async handleWebhook(body: any) {
    if (!this.onMessage) return;

    const entries = body?.entry ?? [];
    for (const entry of entries) {
      const changes = entry?.changes ?? [];
      for (const change of changes) {
        const messages = change?.value?.messages ?? [];
        for (const msg of messages) {
          if (msg.type !== 'text') continue;

          const incoming: IncomingMessage = {
            id: msg.id,
            channel: 'instagram',
            userId: msg.from?.id ?? msg.from,
            userName: msg.from?.username,
            text: msg.text,
            timestamp: new Date(),
            raw: msg,
          };

          await this.onMessage(incoming);
        }
      }
    }
  }

  async send(msg: OutgoingMessage) {
    const url = `https://graph.facebook.com/v21.0/me/messages`;

    await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.IG_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        recipient: { id: msg.userId },
        message: { text: msg.text },
      }),
    });
  }

  async stop() {}
}
