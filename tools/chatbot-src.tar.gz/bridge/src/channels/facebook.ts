import { config } from '../config/index.js';
import type { ChannelAdapter, IncomingMessage, MessageHandler, OutgoingMessage } from '../core/types.js';
import type { WebhookServer } from '../core/webhook-server.js';

export class FacebookAdapter implements ChannelAdapter {
  readonly channel = 'facebook' as const;
  private onMessage?: MessageHandler;

  constructor(private webhook?: WebhookServer) {}

  async start(handler: MessageHandler) {
    this.onMessage = handler;

    if (!config.FB_PAGE_ACCESS_TOKEN) {
      console.log('[Facebook] Disabled: missing FB_PAGE_ACCESS_TOKEN');
      return;
    }

    this.webhook?.register({
      path: 'facebook',
      verifyToken: config.FB_VERIFY_TOKEN ?? 'fb_verify',
      onMessage: (body) => this.handleWebhook(body),
    });
  }

  private async handleWebhook(body: any) {
    if (!this.onMessage) return;

    const entries = body?.entry ?? [];
    for (const entry of entries) {
      const messaging = entry?.messaging ?? [];
      for (const event of messaging) {
        const msg = event?.message;
        if (!msg?.text) continue;

        const incoming: IncomingMessage = {
          id: msg.mid,
          channel: 'facebook',
          userId: event.sender?.id ?? '',
          userName: event.sender?.id,
          text: msg.text,
          timestamp: new Date(event.timestamp),
          raw: event,
        };

        await this.onMessage(incoming);
      }
    }
  }

  async send(msg: OutgoingMessage) {
    const url = `https://graph.facebook.com/v21.0/me/messages?access_token=${config.FB_PAGE_ACCESS_TOKEN}`;

    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        recipient: { id: msg.userId },
        message: { text: msg.text },
      }),
    });
  }

  async stop() {}
}
