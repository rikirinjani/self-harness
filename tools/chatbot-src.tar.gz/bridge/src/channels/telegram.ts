import TelegramBot from 'node-telegram-bot-api';
import { config } from '../config/index.js';
import type { ChannelAdapter, IncomingMessage, MessageHandler, OutgoingMessage } from '../core/types.js';

interface PendingSend {
  msg: OutgoingMessage;
  resolve: () => void;
  reject: (err: Error) => void;
}

export class TelegramAdapter implements ChannelAdapter {
  readonly channel = 'telegram' as const;
  private bot?: TelegramBot;
  private onMessage?: MessageHandler;

  // Rate-limit state
  private rateLimitUntil = 0;          // timestamp (ms) when429 cooldown expires
  private outbox: PendingSend[] = [];  // queued messages during429
  private processing = false;          // is the outbox being drained?
  private lastSendAt = 0;              // timestamp of last successful send

  async start(handler: MessageHandler) {
    this.onMessage = handler;
    const token = config.TELEGRAM_BOT_TOKEN;
    if (!token) {
      console.log('[Telegram] Disabled: no TELEGRAM_BOT_TOKEN');
      return;
    }

    this.bot = new TelegramBot(token, { polling: true });
    console.log('[Telegram] Bot started (polling)');

    this.bot.on('message', async (raw) => {
      if (!this.onMessage) return;

      const chatId = raw.chat?.id;
      if (!chatId) return;

      this.bot?.sendChatAction(chatId, 'typing').catch(() => {});

      // Handle photo messages (vision capability)
      if (raw.photo && raw.photo.length > 0) {
        // Get the highest resolution photo
        const photo = raw.photo[raw.photo.length - 1];

        // Download the photo via the Telegram Bot API and convert to a
        // base64 data URI. LLM providers (e.g. DeepSeek) cannot fetch the
        // file URL directly because it contains the bot token, so we must
        // send the image bytes inline instead.
        let imageDataUri: string | undefined;
        try {
          const buffer = await this.readFileStream(this.bot!.getFileStream(photo.file_id));
          const mime = (photo as any).mime_type || 'image/jpeg';
          const base64 = buffer.toString('base64');
          imageDataUri = `data:${mime};base64,${base64}`;
          console.log(`[Telegram] Photo downloaded, size=${buffer.length} bytes, mime=${mime}`);
        } catch (err) {
          console.error('[Telegram] Failed to download photo:', (err as any)?.message || err);
        }

        if (!imageDataUri) {
          console.log('[Telegram] Photo present but download failed; treating as text-only');
          const textOnly = (raw as any).caption || raw.text || '';
          if (!textOnly) return;
          const incoming: IncomingMessage = {
            id: `${raw.message_id}`,
            channel: 'telegram',
            userId: String(chatId),
            userName: raw.from?.first_name,
            userHandle: raw.from?.username,
            text: textOnly,
            timestamp: new Date(raw.date * 1000),
            raw,
          };
          await this.onMessage(incoming);
          return;
        }

        console.log(`[Telegram] Photo ready, base64 dataUri: YES`);
        // In Telegram's API, photo messages carry the user's text in
        // `raw.caption`, not `raw.text`. Handle both so a single
        // photo-with-caption message doesn't lose its text.
        const text = (raw as any).caption || raw.text || '';
        const incoming: IncomingMessage = {
          id: `${raw.message_id}`,
          channel: 'telegram',
          userId: String(chatId),
          userName: raw.from?.first_name,
          userHandle: raw.from?.username,
          text: text || '(gambar dilampirkan)',
          timestamp: new Date(raw.date * 1000),
          raw,
          image: imageDataUri,
        };
        await this.onMessage(incoming);
        return;
      }

      // Handle text messages
      if (!raw.text) return;

      const incoming: IncomingMessage = {
        id: `${raw.message_id}`,
        channel: 'telegram',
        userId: String(chatId),
        userName: raw.from?.first_name,
        userHandle: raw.from?.username,
        text: raw.text,
        timestamp: new Date(raw.date * 1000),
        raw,
      };

      await this.onMessage(incoming);
    });
  }

  async send(msg: OutgoingMessage): Promise<void> {
    if (!this.bot) return;
    return this.enqueue(msg);
  }

  /** Queue a message; retries automatically on429. */
  private enqueue(msg: OutgoingMessage): Promise<void> {
    return new Promise((resolve, reject) => {
      this.outbox.push({ msg, resolve, reject });
      this.drain();
    });
  }

  /** Process the outbox sequentially. Pauses during429 cooldown. */
  private drain() {
    if (this.processing) return;
    this.processing = true;
    this._drainLoop();
  }

  private async _drainLoop() {
    while (this.outbox.length > 0) {
      // If we're in a429 cooldown, wait
      const now = Date.now();
      if (now < this.rateLimitUntil) {
        const waitMs = this.rateLimitUntil - now + 500; // +500ms safety margin
        console.log(`[Telegram] Rate limit active, waiting ${Math.round(waitMs / 1000)}s (${this.outbox.length} queued)`);
        await sleep(waitMs);
      }

      // Minimum 50ms gap between sends to avoid burst
      const sinceLastSend = Date.now() - this.lastSendAt;
      if (sinceLastSend < 50) {
        await sleep(50 - sinceLastSend);
      }

      const item = this.outbox.shift()!;
      try {
        await this.doSend(item.msg);
        item.resolve();
      } catch (err: any) {
        // Check for429
        if (err?.response?.body?.error_code === 429) {
          const retryAfter = Number(err.response.body.parameters?.retry_after) || 421;
          this.rateLimitUntil = Date.now() + retryAfter * 1000;
          console.error(`[Telegram]429 rate limit, retry after ${retryAfter}s. Re-queuing message.`);
          // Re-queue at front so it sends first after cooldown
          this.outbox.unshift(item);
          continue; // loop will wait for cooldown
        }
        console.error('[Telegram] Send error:', err?.message || err);
        item.reject(err instanceof Error ? err : new Error(String(err)));
      }
    }
    this.processing = false;
  }

  /** Actually send one message via the bot API. */
  private async doSend(msg: OutgoingMessage): Promise<void> {
    if (!this.bot) return;
    const MAX = 4000;
    for (let i = 0; i < msg.text.length; i += MAX) {
      await this.bot.sendMessage(msg.userId, msg.text.slice(i, i + MAX));
    }
    this.lastSendAt = Date.now();

    // If the message carries an image, send it back to the user.
    if (msg.image) {
      try {
        if (msg.image.startsWith('data:')) {
          // Base64 data URI → extract MIME + payload, send as a buffer.
          const m = /^data:([^;]+);base64,(.+)$/s.exec(msg.image);
          if (m) {
            const mime = m[1];
            const buf = Buffer.from(m[2], 'base64');
            const cap = msg.imageCaption ?? '';
            await this.sendMedia(msg.userId, buf, cap, mime);
          } else {
            console.warn('[Telegram] Malformed base64 image payload, skipping');
          }
        } else if (msg.image.startsWith('http://') || msg.image.startsWith('https://')) {
          // Remote URL → Telegram fetches it server-side (no auth headers).
          const cap = msg.imageCaption ?? '';
          await this.bot.sendPhoto(msg.userId, msg.image, cap ? { caption: cap } : {});
        } else {
          // Assume local file path.
          const cap = msg.imageCaption ?? '';
          await this.sendLocalFile(msg.userId, msg.image, cap);
        }
      } catch (err) {
        console.error('[Telegram] Failed to send image:', (err as any)?.message || err);
      }
    }
  }

  /** Send a Buffer as a Telegram media (photo or document depending on MIME). */
  private async sendMedia(userId: string, buf: Buffer, caption: string, mime: string): Promise<void> {
    if (!this.bot) return;
    const isImage = /^image\/(jpeg|jpg|png|gif|webp|tiff|heic)$/i.test(mime);
    const capOpts = caption ? { caption } : {};
    if (isImage) {
      await this.bot.sendPhoto(userId, buf, capOpts as any);
    } else {
      // Non-image MIME (pdf, doc, xlsx, etc.) → send as document with the buffer
      // embedded (v0.61 sendDocument requires filename/contentType inside the attachment).
      await this.bot.sendDocument(userId, buf as any, {
        ...capOpts,
        filename: 'attachment',
        contentType: mime,
      } as any);
    }
  }

  /** Send a local file path as a document. */
  private async sendLocalFile(userId: string, path: string, caption: string): Promise<void> {
    if (!this.bot) return;
    const fs = await import('node:fs');
    if (!fs.existsSync(path)) {
      console.warn(`[Telegram] Local image path does not exist: ${path}`);
      return;
    }
    const fname = path.split(/[\\/]/).pop() || 'attachment';
    await this.bot.sendDocument(userId, fs.createReadStream(path) as any, {
      filename: fname,
      contentType: 'application/octet-stream',
      caption: caption || undefined,
    } as any);
  }

  async stop() {
    if (this.bot) {
      this.bot.stopPolling();
    }
  }

  /** Collect a PassThrough stream into a Buffer. */
  private readFileStream(stream: NodeJS.ReadableStream): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      (stream as any).on('data', (c: Buffer) => chunks.push(c));
      (stream as any).on('end', () => resolve(Buffer.concat(chunks)));
      (stream as any).on('error', reject);
    });
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
