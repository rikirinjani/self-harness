import { config as loadEnv } from 'dotenv';
import { z } from 'zod';

loadEnv();

const envSchema = z.object({
  PORT: z.coerce.number().default(3000),
  HEALTH_PORT: z.coerce.number().default(4001),
  LLM_PROVIDER: z.enum(['deepseek', 'openai']).default('deepseek'),
  LLM_VARIANT: z.enum(['flash', 'pro']).default('flash'),
  LLM_MODEL: z.string().optional(),
  SYSTEM_PROMPT: z.string().default('You are a helpful assistant. Be concise and friendly.'),
  DEEPSEEK_API_KEY: z.string().optional(),
  OPENAI_API_KEY: z.string().optional(),
  OPENAI_BASE_URL: z.string().optional(),
  TELEGRAM_BOT_TOKEN: z.string().optional(),
  WHATSAPP_MODE: z.enum(['meta', 'sidecar']).default('meta'),
  WHATSAPP_ACCESS_TOKEN: z.string().optional(),
  WHATSAPP_PHONE_NUMBER_ID: z.string().optional(),
  WHATSAPP_VERIFY_TOKEN: z.string().optional(),
  WHATSAPP_SIDECAR_PATH: z.string().optional(),
  WHATSAPP_ADMIN_CHAT_ID: z.string().optional(),
  WHATSAPP_REVIEW_MODE: z.coerce.boolean().default(false),
  WHATSAPP_ANSWER_FOOTER: z.string().optional(),
  WHATSAPP_FORWARD_TO: z.string().optional(),
  TELEGRAM_REVIEW_MODE: z.coerce.boolean().default(false),
  TELEGRAM_REVIEW_GROUP_ID: z.string().optional(),
  FORWARD_CHAT_ID: z.string().optional(),
  FB_PAGE_ACCESS_TOKEN: z.string().optional(),
  FB_VERIFY_TOKEN: z.string().optional(),
  IG_ACCESS_TOKEN: z.string().optional(),
  IG_VERIFY_TOKEN: z.string().optional(),
  RAG_ENABLED: z.coerce.boolean().default(true),
  RAG_TOP_K: z.coerce.number().default(3),
  RAG_QUERY_EXPANSION: z.coerce.boolean().default(true),
  RAG_MAX_CONTEXT_TOKENS: z.coerce.number().default(2000),
  RAG_CHUNK_SIZE: z.coerce.number().default(500),
  RAG_CHUNK_OVERLAP: z.coerce.number().default(50),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error('Invalid environment variables:', parsed.error.flatten());
  process.exit(1);
}

export const config = parsed.data;
