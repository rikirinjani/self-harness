import http from 'http';
import { config } from './dist/config/index.js';
import { MessageRouter } from './dist/core/router.js';
import { WebhookServer } from './dist/core/webhook-server.js';
import { TelegramAdapter } from './dist/channels/telegram.js';
import { WhatsAppAdapter } from './dist/channels/whatsapp.js';
import { InstagramAdapter } from './dist/channels/instagram.js';
import { FacebookAdapter } from './dist/channels/facebook.js';

const webhook = new WebhookServer();
const router = new MessageRouter();
router.register(new TelegramAdapter());
router.register(new WhatsAppAdapter(webhook));
router.register(new InstagramAdapter(webhook));
router.register(new FacebookAdapter(webhook));

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

await webhook.start(config.PORT);
console.log('[Webhook] started');

await router.startAll();
console.log('[Router] started');
