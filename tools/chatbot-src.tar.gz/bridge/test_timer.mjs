import { createServer } from 'http';
import { config } from './dist/config/index.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

createServer((_q, r) => {
  r.writeHead(200);
  r.end('ok');
}).listen(config.HEALTH_PORT, () => console.log('Health up'));

// Measure KB load time
const t0 = Date.now();
await knowledgeBase.load();
console.log('KB loaded in', Date.now() - t0, 'ms, chunks:', knowledgeBase.chunks?.length);
