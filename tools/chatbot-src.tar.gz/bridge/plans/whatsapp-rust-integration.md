# whatsmeow (Go) Sidecar Integration Plan

## Architecture

```
┌─────────────────────────────────────────────────┐
│  Bridge (Node.js :4000/:4001)                   │
│                                                  │
│  ┌──────────────┐    ┌───────────────────────┐   │
│  │ Router       │───▶│ WhatsAppAdapter        │   │
│  │ (LLM + RAG)  │    │ (rewritten: sidecar     │   │
│  └──────────────┘    │  client, not Graph API) │   │
│         │            └───────────┬───────────┘   │
│         ▼                        │               │
│  ┌──────────────┐               │               │
│  │ WebhookServer│◀── HTTP POST  │               │
│  │ :4000/webhook│   /incoming   │               │
│  └──────────────┘               │               │
│                                  │               │
│  ┌───────────────────────────────▼───────────┐   │
│  │  child_process.spawn                       │   │
│  │  → whatsapp-rust-sidecar.exe               │   │
│  └───────────────────────────────────────────┘   │
└─────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────┐
│  Rust Sidecar                                    │
│  (standalone binary, C:\Users\think\chatbot\     │
│   whatsapp-sidecar\target\release\               │
│   whatsapp-sidecar.exe)                          │
│                                                  │
│  ┌─────────────────┐  ┌──────────────────────┐   │
│  │ WhatsApp Web     │  │ HTTP API :4100       │   │
│  │ Client (QR auth) │  │                      │   │
│  │                  │  │ POST /send           │   │
│  │ → incoming msgs  │  │   {to, text}         │   │
│  │ → POST to bridge │  │                      │   │
│  │   :4000/webhook  │  │ GET /qr (returns     │   │
│  │   /whatsapp      │  │   QR as PNG)         │   │
│  └─────────────────┘  │                      │   │
│                       │ GET /status           │   │
│                       │   {connected, phone}  │   │
│                       └──────────────────────┘   │
└─────────────────────────────────────────────────┘
```

## Directories

```
C:\Users\think\chatbot\
├── bridge\
│   ├── src\
│   │   ├── channels\
│   │   │   ├── whatsapp.ts    ← rewrite adapter
│   │   │   └── ...
│   │   ├── core\
│   │   │   └── sidecar.ts     ← new: manage child process
│   │   └── index.ts
│   ├── env                    ← add WHATSAPP_MODE=sidecar
│   └── plans\                 ← this file
│
├── whatsapp-sidecar\          ← new Rust project
│   ├── Cargo.toml
│   ├── src\main.rs
│   └── target\release\
│       └── whatsapp-sidecar.exe
```

## Rust Sidecar API

### Endpoints

| Method | Path | Body | Response | Purpose |
|--------|------|------|----------|---------|
| `GET` | `/health` | — | `{ok:true}` | Heartbeat |
| `GET` | `/qr` | — | PNG image | Current QR code for pairing |
| `GET` | `/status` | — | `{connected,phone}` | Connection state |
| `POST` | `/send` | `{to,text}` | `{ok,id}` | Send WhatsApp message |

### Incoming message push

On receiving a WhatsApp message, sidecar POSTs to bridge:

```
POST http://localhost:4000/webhook/whatsapp
Content-Type: application/json

{
  "entry": [{
    "changes": [{
      "value": {
        "messages": [{
          "id": "wa-msg-id",
          "from": "628123456789",
          "type": "text",
          "text": { "body": "halo" },
          "timestamp": "1234567890"
        }]
      }
    }]
  }]
}
```

This matches the Meta webhook format exactly — bridge's `WebhookServer.handleRequest()` processes it without changes.

## Bridge Changes

### New: `src/core/sidecar.ts`

```typescript
class SidecarManager {
  private proc: ChildProcess | null = null;

  async start(cmd: string) {
    this.proc = spawn(cmd, [], { stdio: ['pipe', 'pipe', 'pipe'] });
    // Read QR from stdout → send to admin Telegram chat
    // Monitor health periodically
    // Restart on crash (with backoff)
  }

  async stop() { /* SIGTERM + kill fallback */ }
  async send(to: string, text: string) { /* POST to :4100/send */ }
  async getQR(): Promise<Buffer> { /* fetch :4100/qr */ }
}
```

### Rewritten: `src/channels/whatsapp.ts`

```typescript
// If WHATSAPP_MODE === 'sidecar':
//   - Start sidecar manager
//   - Register webhook for incoming
//   - Use sidecar.send() for outgoing
//
// If WHATSAPP_MODE === 'meta' (default):
//   - Use existing Graph API flow
```

### `.env` additions

```env
WHATSAPP_MODE=sidecar          # sidecar | meta
WHATSAPP_SIDECAR_PATH=C:\Users\think\chatbot\whatsapp-sidecar\whatsapp-sidecar.exe
WHATSAPP_ADMIN_CHAT_ID=        # Telegram user ID to receive QR code
```

## Auth Flow (critical UX)

Since bridge runs headless:

1. Bridge starts sidecar
2. Sidecar outputs QR as base64 PNG → bridge captures from stdout
3. Bridge sends QR image to admin Telegram chat (`WHATSAPP_ADMIN_CHAT_ID`)
4. Admin scans QR with WhatsApp
5. Sidecar saves session → reconnects on restart without re-pairing
6. If pairing expires, bridge re-sends QR

```
[Bridge start]
    │
    ▼
[Start sidecar → QR generated]
    │
    ▼
[Send QR image to admin Telegram]
    │
    ▼
[Admin scans QR with phone]
    │
    ▼
[Sidecar connected → WhatsApp live]
```

## Startup & Shutdown

```
Bridge start:
  1. healthApp.listen(:4001)
  2. webhook.start(:4000)
  3. router.startAll()
      ├── knowledgeBase.load()
      ├── Telegram adapter start (polling)
      ├── WhatsApp adapter start
      │    └── SidecarManager.start()
      │         └── spawn whatsapp-sidecar.exe
      │              └── wait for health :4100
      ├── IG adapter start (disabled)
      └── FB adapter start (disabled)

Bridge stop (SIGINT/SIGTERM):
  1. router.stopAll()
      └── WhatsApp adapter stop
           └── SidecarManager.stop()
                └── SIGTERM → timeout → SIGKILL
  2. webhook.stop()
  3. process.exit(0)
```

## Reconnection & Error Recovery

| Scenario | Behavior |
|----------|----------|
| Sidecar crashes | SidecarManager restarts with 5s → 30s → 60s exponential backoff |
| WhatsApp disconnected | Sidecar auto-reconnects (whatsapp-rust handles this) |
| Session expired | Sidecar generates new QR, bridge re-sends to admin Telegram |
| Bridge restarts | Sidecar killed and re-spawned by new bridge process |
| Internet loss | Both bridge and sidecar need restart when connection returns |

## Build & Deploy

```powershell
# Build Go binary
cd C:\Users\think\chatbot\whatsapp-sidecar
go build -o whatsapp-sidecar.exe .
# → whatsapp-sidecar.exe (∼25 MB)

# Set env
WHATSAPP_MODE=sidecar
WHATSAPP_SIDECAR_PATH=C:\Users\think\whatsapp-sidecar\target\release\whatsapp-sidecar.exe
WHATSAPP_ADMIN_CHAT_ID=<your_telegram_id>

# Start bridge (sidecar auto-launches)
cd C:\Users\think\chatbot\bridge
node dist\index.js
```

## Rollback

Set `WHATSAPP_MODE=meta` to revert to Graph API. No code change needed.
