const { execFileSync, execSync } = require('child_process');
const { readFileSync, readdirSync, mkdtempSync } = require('fs');
const { join } = require('path');
const tmpDir = mkdtempSync(join(require('os').tmpdir(), 'ocr-t-'));
const stem = join(tmpDir, 'p');

// Resolve pdftoppm
const pdfBin = execSync('where pdftoppm', { encoding: 'utf-8' }).trim().split('\n')[0].trim();
console.log('pdftoppm:', pdfBin);

// Resolve python
const pyBin = execSync('where python', { encoding: 'utf-8' }).trim().split('\n')[0].trim();
console.log('python:', pyBin);

// Get the PDF
const dir = 'C:\\Users\\think\\chatbot\\asset\\Satuan Kredit Profesi (SKP)';
const file = readdirSync(dir).filter(f => f.includes('APOTEKER'))[0];
const pdf = join(dir, file);
console.log('PDF:', pdf);

// Run pdftoppm
execFileSync(pdfBin, ['-png', '-r', '200', pdf, stem], { timeout: 120000 });
const pages = readdirSync(tmpDir).filter(f => f.endsWith('.png')).sort().map(f => join(tmpDir, f));
console.log('Pages:', pages.length, 'first:', pages[0]);

// Run OCR
const input = JSON.stringify(pages.slice(0, 2)); // just 2 pages for quick test
const out = execFileSync(pyBin, [join(__dirname, 'ocr_helper.py')], {
  input,
  encoding: 'utf-8',
  timeout: 120000,
  env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
});
console.log('OCR raw output:', out.slice(0, 500));

// Cleanup
require('fs').rmSync(tmpDir, { recursive: true, force: true });
console.log('DONE');
