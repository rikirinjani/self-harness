Set-Location C:\Users\think\chatbot\bridge
node dist/index.js > bridge.log 2>&1
