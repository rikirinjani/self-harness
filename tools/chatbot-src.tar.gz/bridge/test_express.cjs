const express = require('express');
const app = express();
app.get('/h', (r, s) => s.json({ ok: 1 }));
const server = app.listen(13999, () => console.log('up'));
process.on('SIGINT', () => server.close());
