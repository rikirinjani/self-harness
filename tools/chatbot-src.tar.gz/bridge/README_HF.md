# Kolegium Farmasi Chatbot — HF Space

Telegram chatbot for Indonesian healthcare regulations (STR, SIP, SKP, SERKOM).

## Environment Variables

Set these as Docker secrets on HF Space Settings:

| Variable | Value |
|----------|-------|
| `TELEGRAM_BOT_TOKEN` | `8002227393:AAF5-zsrYxS-DkqSgzFKGk8SUatJ2YR2XNk` |
| `OPENAI_API_KEY` | `sk-V1zUNkyMrsa1f865U4toV0XDySfOHIs0MO9yXSZTu8Ov0OlRIuZBzGx17cKndxIu` |
| `OPENAI_BASE_URL` | `https://opencode.ai/zen/go/v1` |
| `LLM_PROVIDER` | `openai` |
| `LLM_MODEL` | `deepseek-v4-flash` |
| `SYSTEM_PROMPT` | `Anda asisten Kolegium Farmasi. Jawab langsung tanpa kalimat pembuka. Gunakan materi. Jika benar-benar tidak ada di materi: tanya nama, NIK, email. Setelah data: akan kami teruskan.` |
| `RAG_TOP_K` | `20` |
| `RAG_QUERY_EXPANSION` | `false` |
| `RAG_MAX_CONTEXT_TOKENS` | `5000` |
| `RAG_CHUNK_SIZE` | `1200` |
| `RAG_CHUNK_OVERLAP` | `150` |

## Deploy

```bash
# Build and push
docker build -t kolegium-chatbot .
docker tag kolegium-chatbot registry.hf.space/your-username/kolegium-chatbot:latest
docker push registry.hf.space/your-username/kolegium-chatbot:latest
```

Or create a new Space at https://huggingface.co/new-space, connect to this repo.
