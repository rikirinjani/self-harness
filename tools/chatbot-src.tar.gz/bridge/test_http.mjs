import http from 'http';
http.createServer((_q, r) => { r.writeHead(200); r.end('ok'); }).listen(14002, () => console.log('up'));
