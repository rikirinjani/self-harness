import http from 'http';
import { config } from './dist/config/index.js';
import { WebhookServer } from './dist/core/webhook-server.js';
import { MessageRouter } from './dist/core/router.js';

const webhook = new WebhookServer();
const router = new MessageRouter();

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

await webhook.start(config.PORT);
console.log('[Webhook] up');

// Start router WITHOUT Telegram - just KB loading
await router.startAll();
console.log('[Router] up');
