import http from 'http';
import express from 'express';
import { config } from './dist/config/index.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

// Health server
http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

// Webhook server (minimal)
const app = express();
app.use(express.json());
app.listen(config.PORT, () => console.log('[Webhook] up'));

// Load KB
await knowledgeBase.load();
console.log('[KB] loaded:', knowledgeBase.chunks?.length, 'chunks');
