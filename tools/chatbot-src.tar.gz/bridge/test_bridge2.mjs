import http from 'http';
import { config } from './dist/config/index.js';
import { knowledgeBase } from './dist/core/knowledge-base.js';

http.createServer((_q, r) => {
  r.writeHead(200, { 'Content-Type': 'application/json' });
  r.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
}).listen(config.HEALTH_PORT, () => console.log('[Health] up'));

await knowledgeBase.load();
console.log('[KB] loaded:', knowledgeBase.chunks?.length, 'chunks');
