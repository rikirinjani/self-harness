# FAQ — SERKOM

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Nama kampus tidak tampil di portal sertifikat SERKOM periode Juli 2025
A: 
- Pastikan data institusi sudah terdaftar di sistem Kolegium Farmasi
- Siapkan data: nama institusi, daftar mahasiswa periode, bukti pendaftaran UKOMNAS
- Jika sudah dicek dan masih terkendala, sampaikan detailnya

Q: SERKOM mahasiswa masih salah (nama/data tidak sesuai)
A: 
- Siapkan data koreksi: nama lengkap, NIK, prodi, NIM, screenshot SERKOM yang salah
- Kirim ke kolegium-farmasi@kki.go.id / 0821 1121 8822 (WA)
- Subjek email: "Koreksi Data SERKOM — [NAMA] — [INSTITUSI]"

Q: Nama di daftar SERKOM salah (tertulis TAJMILAH, harusnya MILA TAJMILAH)
A: 
- Siapkan data koreksi: nama benar, NIK, prodi, institusi, screenshot error
- Kirim ke kolegium-farmasi@kki.go.id / 0821 1121 8822 (WA)
- Subjek: "Koreksi Nama SERKOM — [NAMA BENAR] — [INSTITUSI]"

Q: Cara memperbaiki nama di SERKOM setelah revisi data Dukcapil?
A: 
- Siapkan dokumen: akte terbaru, KTP baru, surat keterangan Dukcapil, fotokopi SERKOM lama
- Kirim ke kolegium-farmasi@kki.go.id dengan subjek "Koreksi Data SERKOM — [NAMA] — [No. STR]"
- Sertakan penjelasan perubahan dan dokumen pendukung. Jika sudah dicek dan masih perlu bantuan, sampaikan detailnya

Q: SERKOM nama salah — tertulis META HARLEVI, harusnya META HARLEFI?
A: Siapkan dokumen pendukung (akte, KTP, fotokopi SERKOM). Kirim ke kolegium-farmasi@kki.go.id dengan subjek "Koreksi Data SERKOM — META HARLEFI — STIKes Al-Fatah Bengkulu"

Q: Prosedur mengurus perbedaan nama antara SERKOM dan Ijazah Profesi?
A: Siapkan dokumen: akte/KTP terbaru, fotokopi SERKOM, fotokopi Ijazah. Kirim ke kolegium-farmasi@kki.go.id dengan subjek "Koreksi Data SERKOM — [NAMA]". Jika nama di Ijazah yang salah, koordinasikan juga dengan institusi pendidikan

Q: SERKOM tidak memiliki masa berlaku — cara perpanjang?
A: Perpanjangan SERKOM dilakukan dengan memenuhi 100 SKP dalam 5 tahun, tanpa ujian ulang. Jika lebih dari 5 tahun tidak berpraktik, perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang) untuk mengurus SIP. Cek info di media sosial Kolegium Farmasi

Q: Sertifikat Kompetensi / SERKOM hilang, rusak, atau ingin download ulang?
A: 
- Coba buka laptop lain, login ke akun yang sama
- Bisa juga buka dari HP: Chrome -> cari portal Kolegium Farmasi -> cek menu sertifikat
- Setelah berhasil download, simpan ke email sebagai cadangan

Q: SERKOM UKOM periode pertama 2025 belum ada?
A: "Baik, mohon ditunggu sebentar, akan kami teruskan ke bagian terkait"

Q: Cara pembuatan SERKOM Vokasi Farmasi? Saya S1 Farmasi.
A: Mohon maaf, SERKOM Tenaga Vokasi Farmasi diperuntukkan bagi lulusan D3 Farmasi. Untuk S1 Farmasi, jalur yang sesuai adalah Apoteker setelah menempuh Pendidikan Profesi Apoteker

Q: Cara daftar resertifikasi SERKOM?
A: Silakan cek di media sosial Kolegium Farmasi untuk informasi pendaftaran resertifikasi SERKOM

Q: Perbedaan KTKI dan KIFI/Kolegium Farmasi? KTKI adalah portal untuk STR di bawah KKI, bukan untuk SERKOM. KIFI (Kolegium Ilmu Farmasi Indonesia) adalah kolegium lama di bawah IAI. Saat ini Kolegium Farmasi berada di bawah KKI

Q: Kapan ada ujian perpanjangan SERKOM?
A: Silakan cek jadwal Sertifikasi Pemenuhan Kompetensi di media sosial Kolegium Farmasi

Q: Kapan pengurusan SERKOM D3 Farmasi?
A: Silakan cek informasi di media sosial Kolegium Farmasi

Q: Link SERKOM tidak bisa dibuka?
A: Coba buka dari browser berbeda atau perangkat lain. Pastikan koneksi stabil. Jika link dari email, cek masa berlaku. Jika masih terkendala, sampaikan detailnya

Q: MPP Digital tolak SIP dengan alasan "SERKOM tidak ditemukan"?
A: Notifikasi berasal dari sistem KKI yang terintegrasi dengan MPP Digital. Silakan hubungi KKI untuk memastikan data SERKOM sudah masuk di sistem mereka. Jika SERKOM belum terdaftar, koordinasikan dengan Kolegium Farmasi

Q: SERKOM D3 akan ED, cara perpanjang?
A: Perpanjangan SERKOM dilakukan dengan memenuhi 100 SKP dalam 5 tahun, tanpa ujian ulang. Jika lebih dari 5 tahun tidak berpraktik, perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang) untuk SIP. Cek info di media sosial Kolegium Farmasi

Q: Alur perpanjangan SERKOM?
A: Perpanjangan SERKOM dilakukan dengan memenuhi 100 SKP dalam 5 tahun, tanpa ujian ulang. Jika lebih dari 5 tahun tidak berpraktik, perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang) untuk SIP. Cek info di media sosial Kolegium Farmasi

Q: Ada UKOM untuk yang sudah lulus? Mau ajukan SIP tapi SERKOM terkendala?
A: SERKOM tidak memiliki masa berlaku. Jika lebih dari 5 tahun tidak berpraktik, perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang) untuk SIP. Jika masih dalam 5 tahun, cukup memenuhi 100 SKP

Q: Lupa password atau detail akun portal?
A: Mohon siapkan data berikut: nama lengkap, NIK, dan email Anda. Setelah itu akan kami teruskan ke bagian terkait.
