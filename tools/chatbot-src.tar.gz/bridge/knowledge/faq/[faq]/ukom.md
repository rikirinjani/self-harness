# FAQ — UKOM

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Form Kesediaan Lokasi UKOMNAS PDPA harus di TTD WR1 atau boleh pimpinan fakultas/prodi?
Cek di media sosial Kolegium Farmasi (Instagram @kolegiumfarmasi, YouTube @Kolegium_Farmasi) atau website kki.go.id/kolegium/farmasi.

Q: Kapan diadakan UKOM tenaga vokasi?
Cek di media sosial Kolegium Farmasi (Instagram @kolegiumfarmasi, YouTube @Kolegium_Farmasi) atau website kki.go.id/kolegium/farmasi.

Q: Bisa ikut UKOM untuk lulusan D3 2025 yang belum ikut? Ijazah masih ditahan?
A: Silakan hubungi institusi pendidikan Anda untuk pendaftaran UKOM.

Q: Jadwal ujian kompetensi tahun 2027?
A: Silakan cek informasi di media sosial Kolegium Farmasi. Jadwal biasanya diumumkan mendekati waktu pelaksanaan.
