# FAQ — INTERNAL_TEKNIS

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Apakah IT OSCE besok ikut briefing?
A: Akan kami informasikan lebih lanjut.

Q: Link upload soal tidak bisa terbuka?
A: Coba buka dengan browser berbeda, cek koneksi internet, copy paste link langsung dari chat/email. Jika link dari email, cek tanggal pengiriman (mungkin kadaluwarsa). Jika masih tidak bisa, hubungi panitia/teknisi penerbit link. Sertakan screenshot.

Q: Berapa lama verifikasi SKP?
A: Fast track untuk SIP yang akan habis (< 6 bulan). Silakan cek info di media sosial Kolegium Farmasi.

Q: UKOMNAS/UKMPPAI (PDPA) periode Agustus 2026 masih komposit atau tidak?
A: Informasi tidak tersedia di dokumen. Silakan cek di media sosial Kolegium Farmasi.

Q: OSCE lokasinya di pusat UKOM atau bisa di kampus sendiri?
A: Informasi tidak tersedia di dokumen. Silakan hubungi panitia UKOMNAS atau institusi pendidikan.


---
Total FAQ: 56 (deduplicated from 58)
