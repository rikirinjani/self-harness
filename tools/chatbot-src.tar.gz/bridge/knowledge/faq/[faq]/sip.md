# FAQ — SIP

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Bagaimana cara mengubah tanggal SIP?
A: 
- Pastikan data pekerjaan di SatuSehat SDMK sudah terisi dengan benar (termasuk tanggal)
- Validasi data SIP di SISDMK oleh pimpinan fasyankes/Dinas Kesehatan
- Tanggal mulai dan berakhir SIP maksimal rentang 5 tahun
- Jika tanggal masih tidak sesuai, kemungkinan ada ketidaksesuaian data di sistem Konsil
- Kontak: helpdesk.ditjennakes@kemkes.go.id / kolegium-farmasi@kki.go.id

Q: SIP mati sejak 2023, sekarang STR Seumur Hidup + SKP cukup, bingung alur MPP Digital untuk perpanjangan SIP pindah tempat praktik?
A: Persyaratan sudah terpenuhi. Langkah: 1) Login MPP Digital Nasional, 2) Pilih perpanjangan SIP dengan perubahan tempat praktik, 3) Siapkan dokumen pendukung. Jika bingung, hubungi DPMPTSP setempat atau helpdesk.ditjennakes@kemkes.go.id.
CATATAN: MPPD adalah kewenangan DPMPTSP, bukan Kolegium Farmasi.
