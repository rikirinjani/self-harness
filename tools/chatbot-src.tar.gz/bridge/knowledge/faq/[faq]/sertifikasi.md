# FAQ — SERTIFIKASI

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Kapan ada sertifikasi pemenuhan kompetensi?
A: Jadwal tidak disebutkan di dokumen. Cek info di kki.go.id/kolegium/farmasi, YouTube @Kolegium_Farmasi

Q: Info ujian resertifikasi?
A: Silakan cek informasi jadwal dan pendaftaran Sertifikasi Pemenuhan Kompetensi di media sosial Kolegium Farmasi.
