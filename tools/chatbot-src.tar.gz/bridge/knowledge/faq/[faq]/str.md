# FAQ — STR

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Alumni lama mau ikut UKOM untuk dapat STR?
A: 
Jika sudah memiliki SERKOM (Sertifikat Kompetensi) dari kelulusan:
- SERKOM bisa langsung digunakan untuk mengajukan STR Seumur Hidup
- Tidak perlu ikut UKOM lagi
- Proses: Lengkapi Data STR Lama di kki.go.id/registrasi
- Siapkan: ijazah, SERKOM, KTP, STR lama (jika ada)
Jika SERKOM hilang / belum memiliki SERKOM:
- Hubungi institusi pendidikan atau Kolegium untuk penerbitan ulang
- UKOM hanya diperlukan jika memang belum pernah lulus ujian kompetensi
Mengenai SIP (setelah STR terbit):
- Jika ingin praktik dan sudah >5 tahun tidak praktik, baru perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang) â€” untuk keperluan SIP, bukan STR
Kontak:
- Registrasi STR: kki.go.id/registrasi
- Helpdesk: helpdesk.ditjennakes@kemkes.go.id
- Kolegium Farmasi: kolegium-farmasi@kki.go.id

Q: Jika ganti STR ke seumur hidup, SKP yang sudah terkumpul akan hilang?
A: Tidak hilang. SKP tersimpan di SKP Platform/SatuSehat SDMK yang terhubung dengan profil (NIK/data diri), bukan nomor STR. Proses: lengkapi Data STR Lama di kki.go.id/registrasi, setelah STR Seumur Hidup terbit, lanjutkan perpanjangan SIP.

Q: Lulusan S1 Farmasi mau ngurus STR untuk kerja di apotek?
A: Lulusan S1 Farmasi tidak dapat langsung mengurus STR. Harus menempuh Pendidikan Profesi Apoteker terlebih dahulu. SERKOM Tenaga Vokasi Farmasi hanya untuk D3 Farmasi. Setelah lulus Profesi Apoteker, dapatkan SERKOM Apoteker, lalu ajukan STR Seumur Hidup di kki.go.id/registrasi (STR adalah kewenangan KKI). Siapkan ijazah, SERKOM, KTP, STR lama (jika ada). Jika sudah punya SERKOM, tidak perlu UKOM lagi. Untuk SIP: jika lebih dari 5 tahun tidak praktik, perlu Sertifikasi Pemenuhan Kompetensi (ujian ulang).
