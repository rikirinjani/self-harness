# FAQ — SKP

Sumber: Chat WhatsApp Kolegium Farmasi

Q: SKP pengabdian belum disetujui, SIPTTK habis Juli 2026
A: 
- Bukti kegiatan harus berupa sertifikat atau berita acara yang jelas
- Kegiatan wajib sesuai kompetensi dan berkaitan dengan kesehatan
- Fast track verifikasi SKP diberikan bagi sejawat yang SIP-nya sudah ED atau menjelang ED
- Pastikan bukti kegiatan pengabdian lengkap (sertifikat/berita acara, kop institusi, ttd)
- Jika sudah diupload tapi belum diverifikasi, hubungi helpdesk dengan menyertakan No. STR dan nama lengkap
- Sampaikan bahwa SIP akan habis Juli 2026 untuk prioritas verifikasi
- Kontak: helpdesk.ditjennakes@kemkes.go.id / kolegium-farmasi@kki.go.id / 0821 1121 8822 (chat only)

Q: Upload SKP pelayanan tidak bisa / gagal?
A: 
[Jika tidak bisa upload / gagal menyimpan]
- File harus .pdf (bukan jpg/png)
- Ukuran file maksimal 250 KB
- Nama file tidak boleh mengandung karakter khusus
- Koneksi internet stabil
- Coba ganti browser atau gunakan mode incognito
[Jika berhasil upload tapi belum diverifikasi]
- Data SIP belum sinkron â€” cek halaman Beranda SatuSehat SDMK. Jika notifikasi  Data SIP belum sinkron, SKP Profesionalisme tidak akan masuk
- Logbook harus lengkap: kop instansi, identitas (nama, No. STR, No. SIP, masa berlaku SIP), periode kegiatan, ditandatangani + stempel APJ/pimpinan langsung
- Tanggal kegiatan harus dalam periode berlakunya SIP
- Pas foto formal, latar merah, 4x6, max 200 KB
- Data pekerjaan (praktik) di SISDMK harus sudah tervalidasi oleh fasyankes/Dinkes
- Jenis Profesi dan Kompetensi terisi sesuai STR
- Kontak: helpdesk.ditjennakes@kemkes.go.id / kolegium-farmasi@kki.go.id

Q: Tidak bisa akses halaman verifikasi SKP?
A: 
- Login ke SatuSehat SDMK (satusehat.kemkes.go.id/sdmk)
- Pastikan profil sudah lengkap: data diri, keprofesian, pekerjaan, data pendukung
- Data SIP harus tervalidasi di SISDMK oleh fasyankes/Dinkes
- Coba browser lain (Chrome/Firefox/Edge)
- Hapus cache & cookies browser
- Pastikan koneksi internet stabil
- Kontak: helpdesk.ditjennakes@kemkes.go.id (sertakan screenshot kendala)

Q: SKP dari siPAFI bisa dikonversi ke SatuSehat?
A: Hubungi helpdesk SatuSehat SDMK di helpdesk.ditjennakes@kemkes.go.id atau Kolegium Farmasi di kolegium-farmasi@kki.go.id / 0821 1121 8822.

Q: Mau verifikasi SKP?
A: Silakan cek panduan verifikasi SKP di media sosial Kolegium Farmasi atau di dokumen Petunjuk Pemenuhan SKP. Jika sudah dicoba dan masih terkendala, sampaikan kendala spesifiknya.

Q: SKP sudah terpenuhi semua ranah tapi tidak bisa verifikasi?
A: Silakan cek: 1) Data SIP sudah sinkron? 2) Data pekerjaan sudah divalidasi di SISDMK? 3) Profil SatuSehat SDMK lengkap? 4) Jenis profesi/kompetensi sesuai STR? 5) Pas foto sesuai ketentuan?

Q: Bisa bantu verifikasi SKP atas nama [nama]?
A: Silakan ajukan verifikasi SKP melalui SKP Platform di SatuSehat SDMK. Panduan ada di dokumen Petunjuk Pemenuhan SKP atau media sosial Kolegium Farmasi. Jika sudah diajukan dan masih terkendala, sampaikan detailnya.

Q: SKP Pengabdian saya tidak muncul?
A: 
- Pastikan kegiatan sudah dilaporkan melalui SKP Platform di SatuSehat SDMK
- Jika sudah dilaporkan tapi tidak muncul, kemungkinan perlu diverifikasi oleh tim verifikator
- Hubungi helpdesk: helpdesk.ditjennakes@kemkes.go.id

Q: Akun tidak muncul di SKP Platform?
A: Akses SKP Platform melalui SatuSehat SDMK, menu Pengelolaan SKP -> SKP Platform. Coba browser lain, hapus cache & cookies. Jika masih tidak muncul, hubungi helpdesk.ditjennakes@kemkes.go.id.

Q: Pelayanan resep dan non-resep di apotek masuk ranah SKP nomor berapa?
A: Termasuk ranah Profesionalisme. Untuk TTK/Tenaga Teknis Kefarmasian, kegiatan pelayanan bisa masuk sub Asuhan atau Non Asuhan. Cek panduan detail di dokumen Petunjuk Pemenuhan SKP.

Q: Mohon dibantu verifikasi SKP pada akun satu sehat?
A: Silakan ajukan melalui SKP Platform di SatuSehat SDMK. Panduan ada di dokumen Petunjuk Pemenuhan SKP. Jika sudah diajukan dan masih terkendala, sampaikan detailnya. Followup jika belum diverifikasi dan tanya lama: lihat entry  Lama proses verifikasi SKP.

Q: Minta tolong verifikasi SKP pelayanan dan pengabdian?
A: Silakan ajukan melalui SKP Platform di SatuSehat SDMK. Panduan ada di dokumen Petunjuk Pemenuhan SKP. Jika sudah diajukan dan masih terkendala, sampaikan detailnya.

Q: SKP di PlataranSehat belum disetujui padahal sudah diperbaiki?
A: SKP Pembelajaran setelah 1 Maret 2025 wajib melalui LMS PlataranSehat. Pastikan data profil lengkap dan sesuai dengan SatuSehat SDMK. Jika masih terkendala, kemungkinan masalah sinkronisasi.

Q: SKP pelayanan belum diverifikasi, padahal SIP sudah tervalidasi?
A: Pastikan data sudah dilaporkan melalui SKP Platform. Cek notifikasi  Data SIP belum sinkron. Pastikan logbook sesuai ketentuan. Fast track jika SIP < 6 bulan. Jika sudah dicek dan masih terkendala, sampaikan detailnya.

Q: Publikasi dan penelitian saya tidak dinilai?
A: Riset & Publikasi termasuk ranah Profesionalisme. Pastikan sudah dilaporkan di SKP Platform dengan bukti pendukung. Jika sudah dan masih tidak dinilai, kemungkinan perlu verifikasi.

Q: Contoh kegiatan SKP untuk Apoteker sebagai PJT Pedagang Besar Kosmetik?
A: Ranah Profesionalisme - Industri & Distribusi: dokumentasi penerimaan/penyimpanan/penyerahan/pemusnahan, QC/QA, K3, pelaporan eksternal, SOP mutu. Bidang Industri & Distribusi tidak melakukan pelayanan langsung ke pasien.
