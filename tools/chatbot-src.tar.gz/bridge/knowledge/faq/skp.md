

Q: Cara upload / melaporkan SKP?
A: Login ke SatuSehat SDMK (satusehat.kemkes.go.id/sdmk). Klik Pengelolaan SKP lalu SKP Platform. Klik Formulir Pengisian, pilih jenis kegiatan, lalu klik Input dan isi data serta upload dokumen sesuai ketentuan. Dokumen harus PDF maksimal 250 KB. Logbook harus ditandatangani APJ/pimpinan.
