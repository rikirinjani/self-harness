﻿# Helpdesk ΓÇö sip

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Iya ya, kl pemasalah di MPPD hrsnya g bs urus SIP pertama. Sy bisa dulu urus SIP. Cuma krn sudah lebih dr 5thn g berpraktek, nah ini mau mulai praktek lg makanya ikut UKOM. Kendalanya membingungkan

**Percakapan lengkap:**

- Pengguna: selamat siang bapak/ibu
- Pengguna: Iya ya, kl pemasalah di MPPD hrsnya g bs urus SIP pertama. Sy bisa dulu urus SIP. Cuma krn sudah lebih dr 5thn g berpraktek, nah ini mau mulai praktek lg makanya ikut UKOM. Kendalanya membingungkan

---

## Kasus 2: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Di

**Percakapan lengkap:**

- Pengguna: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Digital tetapi keterangannya belum memiliki serkom terbaru atau tanggal serkom tidak ditemukan dan dari helpdeks kemkes disuru menghubungi KIFI atau APDFI nya bu, mohon arahan dan bantuannya ya bu≡ƒÖÅ≡ƒÅ╗. Terimakasih

---

## Kasus 3: Selamat Siang Bapak / Ibu dari Dinas Kesehatan Kab.Tana Toraja, mau bertanya terkait pembuatan SIP pertama kali ada TTK tamatan tahun 2020 tapi serkom sdh expayer tgl. 17 okt 2025 , selama tamat tdk p

**Percakapan lengkap:**

- Pengguna: Selamat Siang Bapak / Ibu dari Dinas Kesehatan Kab.Tana Toraja, mau bertanya terkait pembuatan SIP pertama kali ada TTK tamatan tahun 2020 tapi serkom sdh expayer tgl. 17 okt 2025 , selama tamat tdk pernah bekerja, tidak memiliki memiliki SIP

---

## Kasus 4: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Di

**Percakapan lengkap:**

- Pengguna: Dan informasi unduh kartu ujian
- Pengguna: Bapak ibu izin up lagi terkait PL
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Digital tetapi keterangannya belum memiliki serkom terbaru atau tanggal serkom tidak ditemukan dan dari helpdeks kemkes disuru menghubungi KKI nya bu, mohon arahan dan bantuannya ya bu≡ƒÖÅ≡ƒÅ╗. Terimakasih

---

## Kasus 5: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Di

**Percakapan lengkap:**

- Pengguna: Assalamu'alaikum Wr. Wb
- Pengguna: Berikut saya up lagi surat informasi terkait unduh kartu ujian
- Pengguna: AssalamuΓÇÖalaikum
- Pengguna: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Digital tetapi keterangannya belum memiliki serkom terbaru atau tanggal serkom tidak ditemukan dan dari helpdeks kemkes disuru menghubungi KIFI nya bu, mohon arahan dan bantuannya ya bu≡ƒÖÅ≡ƒÅ╗. Terimakasih

---

## Kasus 6: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Di

**Percakapan lengkap:**

- Pengguna: Baik..Terima kasih atas informasinya Bapak..Kami tambahkan Ibu Sri Yuliasmi ke wag ini nggih..≡ƒÖÅ≡ƒÅ╝
- Pengguna: Berikut link untuk upload surat pernyataan dan file excel : https://s.id/PernyataanProdiPSPA
- Pengguna: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Digital tetapi keterangannya belum memiliki serkom terbaru atau tanggal serkom tidak ditemukan dan dari helpdeks kemkes disuru menghubungi KKI nya bu, mohon arahan dan bantuannya ya bu≡ƒÖÅ≡ƒÅ╗. Terimakasih

---

## Kasus 7: Selamat malam Bapak/Ibu.. besok kami akan buka helpdesk bagi yang masih ada kendala dalam registrasi, jam 8 pagi, hari Jumat 12 Juni 2026. Mohon dapat dimanfaatkan sebaik2nya.. jika bapak ibu sudah se

**Percakapan lengkap:**

- Pengguna: trima kasih ibu
- Pengguna: Selamat malam Bapak/Ibu.. besok kami akan buka helpdesk bagi yang masih ada kendala dalam registrasi, jam 8 pagi, hari Jumat 12 Juni 2026. Mohon dapat dimanfaatkan sebaik2nya.. jika bapak ibu sudah selesai melengkapi foto, ktp maka silahkan ajukan pembayaran, dan generate VA. masa pembayaran di surat kami cantumkan sp tgl 19, jika sudah siap pembayaran sebaiknya tidak menunggu tgl 19, kami buka sp tgl 19 untuk antisipasi yang masih ada kendala di sistem.
- Pengguna: Selamat siang

---

## Kasus 8: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Di

**Percakapan lengkap:**

- Pengguna: siap terima kasih infonya bu
- Pengguna: Bapak ibu.. mohon bantuannya untuk melengkapi data penugasan PL sesuai plotting yg ditetapkan pada link gsheet (sesuai dalam surat)≡ƒÖÅ≡ƒÖÅ
- Pengguna: AssalamuΓÇÖalaikum selamat pagi bu, sebelumnya maaf mengganggu waktunya bu. Perkenalkan saya Laxmi Syahfazira alumni dari prodi D3 Stifar Riau akt 21 bu. saya ingin mengajukan pembuatan SIP bu di MPP Digital tetapi keterangannya belum memiliki serkom terbaru atau tanggal serkom tidak ditemukan dan dari helpdeks kemkes disuru menghubungi KIFI atau APDFI nya bu, mohon arahan dan bantuannya ya bu≡ƒÖÅ≡ƒÅ╗. Terimakasih

---

## Kasus 9: Untuk tanda tangan atasan langsung pada loogbook itu harus yang berSIP kalau pimpinan rumah sakit tidak mempunyai SIP dan jajaran management lainya tidak berSIP bagaimana ? ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: *update tambahan* institusi yang sudah upload surat pernyataan dan file excel data peserta : Universitas Adiwangsa Jambi
- Pengguna: Untuk tanda tangan atasan langsung pada loogbook itu harus yang berSIP kalau pimpinan rumah sakit tidak mempunyai SIP dan jajaran management lainya tidak berSIP bagaimana ? ≡ƒÖÅ

---

## Kasus 10: Benar, ini juga opsi yang bisa dicoba. Prinsipnya aplikasi edit yang "resmi" .. misal bawaan windows, bawaan WhatsApp, atau dari editor PDF/ gambar yg lain.

**Percakapan lengkap:**

- Pengguna: mohon arahan setelah proses pembayaran, apakah ada lagi yang harus dilakukan bu/pak?
- Pengguna: Benar, ini juga opsi yang bisa dicoba. Prinsipnya aplikasi edit yang "resmi" .. misal bawaan windows, bawaan WhatsApp, atau dari editor PDF/ gambar yg lain.

---

## Kasus 11: Selamat siang min maaf mau tanya untuk ukom farmasi bagi yg sudah lulus itu apa ada ya min? Ini saya mau mengajukan SIP tapi terkendala serkom mati ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: Selamat siang min maaf mau tanya untuk ukom farmasi bagi yg sudah lulus itu apa ada ya min? Ini saya mau mengajukan SIP tapi terkendala serkom mati ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 12: Ini nanti kalau tidak solved akan terbawa sampai pengurusan STR, dan SIP (kalau Praktik)

**Percakapan lengkap:**

- Pengguna: Terima kasih Prof Azis ≡ƒÖÅ
- Pengguna: Ini nanti kalau tidak solved akan terbawa sampai pengurusan STR, dan SIP (kalau Praktik)

---

## Kasus 13: Mohon dibantu bapak / ibu...dikarenakan akan segera berakhirnya SIPA..terimakasih

**Percakapan lengkap:**

- Pengguna: sudah di sesuaikan semua pak sesuai dengan panduan yang ada di surat
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Mohon dibantu bapak / ibu...dikarenakan akan segera berakhirnya SIPA..terimakasih

---

## Kasus 14: Saya sekarang terkendala di serkom untuk pembuatan SIP diaplikasi MPP digital min..

**Percakapan lengkap:**

- Pengguna: Baik pak
- Pengguna: Saya sekarang terkendala di serkom untuk pembuatan SIP diaplikasi MPP digital min..
- Pengguna: Selamat siang.

---

## Kasus 15: Banyak sekali kasus kek gini ya. SIP sy br mau diurus sm tmpt praktek, jd g tenang. Sebetulnya kesalahan ada dimana ya? Kenapa bisa ga sinkron gini?

**Percakapan lengkap:**

- Pengguna: Selamat pagi pak/ibu
- Pengguna: Sore pak/bu, saya ingin melakukan permohonan pembatalan pengajuan str, itu bagaimana ya?
- Pengguna: Banyak sekali kasus kek gini ya. SIP sy br mau diurus sm tmpt praktek, jd g tenang. Sebetulnya kesalahan ada dimana ya? Kenapa bisa ga sinkron gini?
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 16: Sepertinya iya. Tapi memang yg ada tanda . Sama ' itu sering bermasalah, bukan hanya disini , tapi nanti di SERKOM, STR bahkan SIP

**Percakapan lengkap:**

- Pengguna: Selamat siang bapak ibu,
- Pengguna: Ibu izin bertanya ≡ƒÖÅ≡ƒÅ╗ utk PL dari institusi masing2 berarti ya? setiap sesi ada PL laki2 dan perempuan, berarti utk 2 sesi perlu 4 orang PL ya betul? ≡ƒÖÅ≡ƒÅ╗ Khawatir keliru, mohon arahannya
- Pengguna: Sepertinya iya. Tapi memang yg ada tanda . Sama ' itu sering bermasalah, bukan hanya disini , tapi nanti di SERKOM, STR bahkan SIP

---

## Kasus 17: Selamat pagi, bapak/ibuu, ijin bertanya perihal serkom untuk pembuatan sip≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Selamat pagi, bapak/ibuu, ijin bertanya perihal serkom untuk pembuatan sip≡ƒÖÅ

---

## Kasus 18: assalamualikum, selamat pagi maaf mohon bantuan dan info, bagaimana cara apoteker yang SIP sudah tidak berlaku lebih dari lima tahun

**Percakapan lengkap:**

- Pengguna: Izin menjawab, kemarin kami bayar pakai BNI bisa, transfernya antar bank bukan VA, pilih bank mandiri dan dimasukkan nomor VAnya, tutorial lebih jelasnya ada dimenu pembayaraan
- Pengguna: assalamualikum, selamat pagi maaf mohon bantuan dan info, bagaimana cara apoteker yang SIP sudah tidak berlaku lebih dari lima tahun

---

## Kasus 19: Selamat malam, mau menanyakan untuk SIP yang sudah expired dari juni 2025, tetapi ranah pembelajarannya masih kurang, solusinya bagaimana ya?

**Percakapan lengkap:**

- Pengguna: mohon maaf bu untuk mahasiswa atas nama Ana Sulistia Wati pada kartu peserta masih Ana Sulistiowati. Apakah tidak masalah saat TO besok?
- Pengguna: jadi baru nilai yang on progress ya... padahal IPK nya hrsnya yg s1...
- Pengguna: Selamat malam, mau menanyakan untuk SIP yang sudah expired dari juni 2025, tetapi ranah pembelajarannya masih kurang, solusinya bagaimana ya?

---

## Kasus 20: dengan prinsip yg sama , yakni editnya menggunakan editor resmi. termasuk data dari mhs juga harus "baik"

**Percakapan lengkap:**

- Pengguna: 3. Sertifikasi Pemenuhan Kompetensi
- Pengguna: sy nofrianto ts apoteker yg bekerja di industri farmasi
- Pengguna: dengan prinsip yg sama , yakni editnya menggunakan editor resmi. termasuk data dari mhs juga harus "baik"

---

## Kasus 21: Mohon arahan terkait pemenuhan kompetensi  jika tahun lulus 2019 dan serkom sudah habis di 2024 serta selama ini belum pernah menjabat sebagai APJ. Dan saat kami akan mengajukan sipa sebagai APJ Terim

**Respon:**

*HELPDESK DITJEN SDM KESEHATAN*

**Percakapan lengkap:**

- Pengguna: Mohon arahan terkait pemenuhan kompetensi  jika tahun lulus 2019 dan serkom sudah habis di 2024 serta selama ini belum pernah menjabat sebagai APJ. Dan saat kami akan mengajukan sipa sebagai APJ Terimakasih
- Kolegium: *HELPDESK DITJEN SDM KESEHATAN*

---

## Kasus 22: Dengan berkurangnya tatap muka institusi pendidikan perlu mengantisipasi agar kualitas pendidikan tidak turun.

**Percakapan lengkap:**

- Pengguna: Dengan berkurangnya tatap muka institusi pendidikan perlu mengantisipasi agar kualitas pendidikan tidak turun.

---

## Kasus 23: Pilihan di sip belum ada

**Percakapan lengkap:**

- Pengguna: Pilihan di sip belum ada

---

## Kasus 24: Ini pilih dimana yah kak? Soalnya disaya tdk muncul belum pernah buat sip, padahal baru mau pengajuan

**Percakapan lengkap:**

- Pengguna: Sdh keluar SIP nya?
- Pengguna: Ini pilih dimana yah kak? Soalnya disaya tdk muncul belum pernah buat sip, padahal baru mau pengajuan

---

## Kasus 25: Cuman aku lagi cari nomor STR dan SIP

**Percakapan lengkap:**

- Pengguna: Cuman aku lagi cari nomor STR dan SIP

---

## Kasus 26: Bisa di Ss kan Dibagikan mana untuk ubah tgl sip nya kak??

**Respon:**

*FORMULIR ELEKTRONIK PERMOHONAN VERIFIKASI SKP*

**Percakapan lengkap:**

- Pengguna: Nanti ada kop nya
- Pengguna: Bisa di Ss kan Dibagikan mana untuk ubah tgl sip nya kak??
- Kolegium: *FORMULIR ELEKTRONIK PERMOHONAN VERIFIKASI SKP*

---

## Kasus 27: Ubah tgl sip di sisdmk

**Percakapan lengkap:**

- Pengguna: Postingan terkini
- Pengguna: Ubah tgl sip di sisdmk

---

## Kasus 28: Iya kak sama, sy jg terkendala dibagian ini, bagaimana cara ubah tgl sipnya?

**Percakapan lengkap:**

- Pengguna: Untk mengisi verifikasi tidak bisa d akses
- Pengguna: Iya kak sama, sy jg terkendala dibagian ini, bagaimana cara ubah tgl sipnya?

---

## Kasus 29: Saya sudah coba ngajuin SIPA di MPP D pekanbaru, tpi ditolak

**Percakapan lengkap:**

- Pengguna: Saya sudah coba ngajuin SIPA di MPP D pekanbaru, tpi ditolak

---

## Kasus 30: Berarti yang sip lama itu gag usah dcantumkan ya kak yang sudah expaid trus dganti sama belum pernah

**Percakapan lengkap:**

- Pengguna: Bismillah...teman2 sejawat TVF sdh ada yg berhasil pengajuan SIP nya?
- Pengguna: Berarti yang sip lama itu gag usah dcantumkan ya kak yang sudah expaid trus dganti sama belum pernah

---

