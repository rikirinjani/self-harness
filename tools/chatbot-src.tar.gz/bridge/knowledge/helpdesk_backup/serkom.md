﻿# Helpdesk ΓÇö serkom

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Mau tnya soal Serkom

**Percakapan lengkap:**

- Pengguna: Selamat siang.. Mohon bantuannya.
- Pengguna: Mau tnya soal Serkom

---

## Kasus 2: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗
- Pengguna: Salam sejawat

---

## Kasus 3: Selamat pagi, izin bertanya. Bagaimana alur perpanjangn serkom ? Terimakasih

**Percakapan lengkap:**

- Pengguna: Selamat pagi, izin bertanya. Bagaimana alur perpanjangn serkom ? Terimakasih

---

## Kasus 4: Jika ingin menanyakan perpanjangan serkom apoteker yang sudah habis masa berlakunya lebih dari 5th dan belum pernah praktek, apakah ada saran?

**Percakapan lengkap:**

- Pengguna: ga perlu bu.. sudah dijawab juga ya terkait hal yang sama ini oleh pak akbar kemarin dr pertanyaan bapak ibu lainnya disini bu
- Pengguna: Jika ingin menanyakan perpanjangan serkom apoteker yang sudah habis masa berlakunya lebih dari 5th dan belum pernah praktek, apakah ada saran?

---

## Kasus 5: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗

---

## Kasus 6: Sertifikat kompetensi hilang bagaimana pengurusanx?

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM
- Pengguna: Sertifikat kompetensi hilang bagaimana pengurusanx?

---

## Kasus 7: 3 untuk sertifikat pemenuhan kompetensi

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Siang. Saya mau tanya, kapan ada ujian kompetensi untuk apt lama yg ingin praktek lagi?
- Pengguna: 3 untuk sertifikat pemenuhan kompetensi
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 8: selamat pagi, perkenalkan saya Ana Apoteker Klinik Kejaksaan, ijin bertanya sertifikat kompetensi saya sudah expired dan saya berpraktik, apakah perlu diperpanjang? terimakasih banyak sebelumnya ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: selamat pagi, perkenalkan saya Ana Apoteker Klinik Kejaksaan, ijin bertanya sertifikat kompetensi saya sudah expired dan saya berpraktik, apakah perlu diperpanjang? terimakasih banyak sebelumnya ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 9: Sy ingin menanyakan mengenai Serkom

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Sy ingin menanyakan mengenai Serkom
- Kolegium: Semoga dapat membantu ya sejawat,
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 10: Min kapan lagi ya ada ujian utk perpnjang serkom?

**Percakapan lengkap:**

- Pengguna: Saya mau bertanya saya ditugaskan menjadi kepala instalasi farmasi dirsud kemudian saya mau membuat loogbook untuk ranah pelayanan, untuk yg bertanda tangan verifikasi itu cukup tanda tangan saya sendiri atau perlu atasan pak? Kalau atasan direktur atau jajaran manajemen tidak mempunyai SIP? Bagaimna solusi terima kasih. ≡ƒÖÅ≡ƒÖÅ
- Pengguna: Min kapan lagi ya ada ujian utk perpnjang serkom?

---

## Kasus 11: Pak mohon di bantu jika ingin mendaftarkan resertifikasi serkom daftar nya bagaimana ya?

**Percakapan lengkap:**

- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Pak mohon di bantu jika ingin mendaftarkan resertifikasi serkom daftar nya bagaimana ya?

---

## Kasus 12: izin Bu admin..apakah bisa share ulang link sertifikat ukom

**Percakapan lengkap:**

- Pengguna: ngga punya patah punya saya pa
- Pengguna: Mohon admin Unpak dan ISTN japri nggih.. ≡ƒÖÅ
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: izin Bu admin..apakah bisa share ulang link sertifikat ukom

---

## Kasus 13: Kalo untuk pembuatan serkom bagaimana ka?

**Percakapan lengkap:**

- Pengguna: 1764 Kepkonsil Standar Kompetensi Tenaga Kefarmasian_10 Juli 2026_2026-07-11.pdf
- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM
- Pengguna: Kalo untuk pembuatan serkom bagaimana ka?

---

## Kasus 14: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: bu, mohon bantuannya kalau membuat pdf tapi lewat dari batasnya excel bagaimana? terima kasih
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 15: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: Izin ibu kami sudah mengajukan perubahan data terkait foto di kartu peserta
- Pengguna: sebagai gambaran: pada saat pelaksanaan TO D3 farmasi Tim Adhoc menerima 100-200 perubahan data , yang melibatkan pergantian foto baik KTP maupun pasfoto. dan semuanya berjalan baik (asal file aslinya juga baik)
- Pengguna: Assalamualaikum, izin pak. Izin tanya pada pengajuan data osce ujian akan dilaksanakan 2 periode. Apa di ikuti keduanya atau bisa memilih salah satu periode?
- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗

---

## Kasus 16: Selamat malam, izin bertanya. Bagaimana alur perpanjangn serkom ? Terimakasih

**Percakapan lengkap:**

- Pengguna: silahkan diselesaikan dulu
- Pengguna: Selamat malam, izin bertanya. Bagaimana alur perpanjangn serkom ? Terimakasih

---

## Kasus 17: Bagaimana dengan sertifikat kompetensi kami

**Percakapan lengkap:**

- Pengguna: VA nya aktif selama 2 hari (+ sekian jam) jika VA nya kedaluwarsa, bisa di generate ulang *langsung* di halaman pembayaran.
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Bagaimana dengan sertifikat kompetensi kami

---

## Kasus 18: Ukom untuk mendapatkan serkom

**Percakapan lengkap:**

- Pengguna: Blueprint_Pengelolaan_Sumber_Daya_Manusia_Kesehatan_SDMK_Tahun_2025.pdf
- Pengguna: Ukom untuk mendapatkan serkom

---

## Kasus 19: pagi, mau menanyakan terkait serkom bisa?

**Percakapan lengkap:**

- Pengguna: pagi, mau menanyakan terkait serkom bisa?
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Tos Pak Prim

---

## Kasus 20: Assalamu alaikum bapak ibu..saya ingin bertanya..dari terbit serkom selepas ukom kemarin sampai skrg saya sudah melapor ke ptsp dan ke Dinkes serta email.helpdesk.ditjennakes yg di teruskan ke helpdes

**Percakapan lengkap:**

- Pengguna: baik pak
- Pengguna: Siap, pak terima kasih infonya ≡ƒÖÅ
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Assalamu alaikum bapak ibu..saya ingin bertanya..dari terbit serkom selepas ukom kemarin sampai skrg saya sudah melapor ke ptsp dan ke Dinkes serta email.helpdesk.ditjennakes yg di teruskan ke helpdesk.ktki

---

## Kasus 21: sampai sekarang belum ada sertifikat nya

**Percakapan lengkap:**

- Pengguna: Selamat pagi pak/bu. Izin bertanya terkait pengisian log book di satusehat sdmk.
- Pengguna: sampai sekarang belum ada sertifikat nya

---

## Kasus 22: selamat pagi, saya mahasiswa pspa angkatan ags (periode 2) 2025 kemarin, saya belum sempat mengurus Penerbitan Sertifikat Kompetensi Apoteker Periode September 2025 kemarin pak, dan skrg saya coba log

**Percakapan lengkap:**

- Pengguna: selamat pagi, saya mahasiswa pspa angkatan ags (periode 2) 2025 kemarin, saya belum sempat mengurus Penerbitan Sertifikat Kompetensi Apoteker Periode September 2025 kemarin pak, dan skrg saya coba login kenapa tidak bisa ya? terima kasih sebelumnya

---

## Kasus 23: Assalamualaikum selamat malam, izin bertanya apabila ingin memperpanjang serkom bgmn ya min? Saya lulus apoteker tahun 2020 dan blm pernah praktik sejak lulus.

**Percakapan lengkap:**

- Pengguna: Siap bu, karena kami belum
- Pengguna: Assalamualaikum selamat malam, izin bertanya apabila ingin memperpanjang serkom bgmn ya min? Saya lulus apoteker tahun 2020 dan blm pernah praktik sejak lulus.

---

## Kasus 24: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: sudah diubah ya pa ≡ƒÖÅ≡ƒÅ╗
- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 25: Selamat siang ka, saya laras mau tanya ka, serkom d3 farmasi saya mau ED, untuk cara memperpanjang nya apakah harus ujian kompetensi lagi atau ada cara lain ya?. Terimakasih≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Selamat siang ka, saya laras mau tanya ka, serkom d3 farmasi saya mau ED, untuk cara memperpanjang nya apakah harus ujian kompetensi lagi atau ada cara lain ya?. Terimakasih≡ƒÖÅ

---

## Kasus 26: Permisi, maaf mengganggu. Saya lulusan profesi apoteker 2026. Izin bertanya, bagaimana prosedur mengurus kesalahan penulisan nama pada serkom? Terima kasih

**Percakapan lengkap:**

- Pengguna: Maaf ibu, ini zoom untuk kegiatan apa ya?
- Pengguna: Permisi, maaf mengganggu. Saya lulusan profesi apoteker 2026. Izin bertanya, bagaimana prosedur mengurus kesalahan penulisan nama pada serkom? Terima kasih
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 27: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: baik pak, terimakasih infonya≡ƒÖÅ≡ƒÅ╗
- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗

---

## Kasus 28: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantu

**Percakapan lengkap:**

- Pengguna: Baik terima kasih pak
- Pengguna: AssalamuΓÇÖalaikum warahmatullahi wabarakatuh.
- Pengguna: bapak ibu izin bertanya kalau kendalanya seperti ini bagaimana njih?
- Pengguna: assalamu'alaikum warahmatullahi wabarakatuh, mohon maaf sebelumnya bapak/ibu, izin bertanya, kami mahasiswa universitas megarezky yang telah ukom periode pertama 2025 belum ada serkom-nya, mohon bantuannya bapak/ibu mengenai serkom dari kampus kami≡ƒÖÅ≡ƒÅ╗

---

## Kasus 29: Mau ikut serkom takut ketinggalan info

**Percakapan lengkap:**

- Pengguna: Mau ikut serkom takut ketinggalan info

---

## Kasus 30: kak, serkom untuk 2026 apakah sudah dbuka?

**Percakapan lengkap:**

- Pengguna: kak, serkom untuk 2026 apakah sudah dbuka?

---

