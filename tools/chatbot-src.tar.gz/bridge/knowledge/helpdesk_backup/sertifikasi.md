﻿# Helpdesk ΓÇö sertifikasi

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Alhamdulillahi Robbil ΓÇÿAalamiin standard kompetensi tenaga kefarmasian, termasuk TVF sudah di sahkan.

**Percakapan lengkap:**

- Pengguna: Alhamdulillahi Robbil ΓÇÿAalamiin standard kompetensi tenaga kefarmasian, termasuk TVF sudah di sahkan.

---

## Kasus 2: monggo silahkan bapak ibu pimpinan mencermati, dan mulai menyesuaikan agar kurikulum yang di miliki sesuai untuk pencapaian standar kompetensi tersebut.

**Percakapan lengkap:**

- Pengguna: monggo silahkan bapak ibu pimpinan mencermati, dan mulai menyesuaikan agar kurikulum yang di miliki sesuai untuk pencapaian standar kompetensi tersebut.

---

## Kasus 3: 3. sertifikasi pemenuhan kompetensi

**Percakapan lengkap:**

- Pengguna: 3. sertifikasi pemenuhan kompetensi

---

## Kasus 4: Saya mau mendaftar untuk ikut uji kompetensi..apakah sdh bisa ?

**Percakapan lengkap:**

- Pengguna: Saya mau daftar OsCe gmn ya
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Saya mau mendaftar untuk ikut uji kompetensi..apakah sdh bisa ?

---

## Kasus 5: Mau tanya soal jadwal uji kompetensi kembali untuk tahun ini diadakan kapan ya?

**Percakapan lengkap:**

- Pengguna: alhamdulillah siap pa
- Pengguna: Mau tanya soal jadwal uji kompetensi kembali untuk tahun ini diadakan kapan ya?

---

## Kasus 6: 3. Sertifikasi Pemenuhan Kompetensi

**Percakapan lengkap:**

- Pengguna: Slide 1
- Pengguna: 3. Sertifikasi Pemenuhan Kompetensi

---

## Kasus 7: https://kki.go.id/files/kepkonsil/2026/1764%20Kepkonsil%20Standar%20Kompetensi%20Tenaga%20Kefarmasian_10%20Juli%202026_2026-07-11.pdf

**Percakapan lengkap:**

- Pengguna: https://kki.go.id/files/kepkonsil/2026/1764%20Kepkonsil%20Standar%20Kompetensi%20Tenaga%20Kefarmasian_10%20Juli%202026_2026-07-11.pdf
- Pengguna: Selamat pgi

---

## Kasus 8: 3. Sertifikasi Pemenuhan Kompetensi

**Percakapan lengkap:**

- Pengguna: 3. Sertifikasi Pemenuhan Kompetensi
- Pengguna: waalaikumsalam

---

## Kasus 9: Salam Bapak/Ibu, selamat pagi dan salam sehat selalu. Terima kasih atas dukungan bapak ibu dalam membagikan informasi ini kepada para preseptor, Alhamdulillah peserta mencapai 3556 dan masih berlanjut

**Percakapan lengkap:**

- Pengguna: KCC saja bu
- Pengguna: Salam Bapak/Ibu, selamat pagi dan salam sehat selalu. Terima kasih atas dukungan bapak ibu dalam membagikan informasi ini kepada para preseptor, Alhamdulillah peserta mencapai 3556 dan masih berlanjut enrolled. semoga bermanfaat untuk penjagaan kompetensi tenaga kefarmasian di Indonesia, Nuwun
- Pengguna: Selamat siang

---

## Kasus 10: Uji Kompetensi Peserta Didik Vokasi Farmasi Metode OSCE/OSPE 2-13 Juni 2026

**Percakapan lengkap:**

- Pengguna: Admin/ pic dari universitas Indonesia boleh japri saya? Tks
- Pengguna: Uji Kompetensi Peserta Didik Vokasi Farmasi Metode OSCE/OSPE 2-13 Juni 2026
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 11: selamat pagi. saya Andineke dari PT Actavis. apakah bisa konsultasi pemenuhan kompetensi nakes? terima kasih sebelumnya

**Percakapan lengkap:**

- Pengguna: terima kasih pak≡ƒÖÅ≡ƒÅ╗
- Pengguna: dicoba lagi pak,
- Pengguna: Izin bu maza boleh dikampus sendiri≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗
- Pengguna: selamat pagi. saya Andineke dari PT Actavis. apakah bisa konsultasi pemenuhan kompetensi nakes? terima kasih sebelumnya

---

## Kasus 12: 3. Sertifikasi pemenuhan kompetensi

**Percakapan lengkap:**

- Pengguna: 3. Sertifikasi pemenuhan kompetensi

---

## Kasus 13: Yth. Bapak/Ibu pimpinan Kolegium Farmasi. Izin bertanya terkait Surat Sumpah Apoteker apakah mengikuti peraturan lama (Kepmenkes 413 tahun 2014) atau ada perubahan format baru? Terima kasih

**Percakapan lengkap:**

- Pengguna: selamat Pagi Bapak/Ibu Panitia,
- Pengguna: Maaf pak berarti kalo muncul kasus yang sama seperti ini di buat 2 bacth gpp nggih pak?
- Pengguna: langsung klik Assign jadwal
- Pengguna: Yth. Bapak/Ibu pimpinan Kolegium Farmasi. Izin bertanya terkait Surat Sumpah Apoteker apakah mengikuti peraturan lama (Kepmenkes 413 tahun 2014) atau ada perubahan format baru? Terima kasih
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 14: Selamat pagi. Saya mau tanya, kapan ada ujian kompetensi untuk apt lama yg ingin praktek lagi?

**Percakapan lengkap:**

- Pengguna: Selamat pagi. Saya mau tanya, kapan ada ujian kompetensi untuk apt lama yg ingin praktek lagi?
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 15: Siang .saya Hendra mau tanya, untuk uji kompetensi apoteker terdekat di bulan apa ya Bu

**Percakapan lengkap:**

- Pengguna: VA yang sudah expired dapat di generate ulang , namun setiap generate angka VA nya berbeda (dynamic VA)
- Pengguna: Siang .saya Hendra mau tanya, untuk uji kompetensi apoteker terdekat di bulan apa ya Bu

---

## Kasus 16: Selamat Pagi, saya Firda Tri Monisia. Saya ingin bertanya terkait jadwal resertifikasi apoteker yang sudah lebih dari 5 tahun tidka berpraktik untuk tahun 2026 apakah sudah ada ? Terima kasih ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: baik pak, maturnuwun ≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Selamat Pagi, saya Firda Tri Monisia. Saya ingin bertanya terkait jadwal resertifikasi apoteker yang sudah lebih dari 5 tahun tidka berpraktik untuk tahun 2026 apakah sudah ada ? Terima kasih ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 17: Disumpahi pakai nama2 hewan ≡ƒ½ó

**Percakapan lengkap:**

- Pengguna: Disumpahi pakai nama2 hewan ≡ƒ½ó

---

## Kasus 18: Mohon maaf mau tanya jadwal pelaksana Ujian sertifikasi waktu terdekat kapan lg ya?

**Respon:**

*SERTIFIKASI PEMENUHAN KOMPETENSI*

**Percakapan lengkap:**

- Pengguna: Mohon maaf mau tanya jadwal pelaksana Ujian sertifikasi waktu terdekat kapan lg ya?
- Kolegium: *SERTIFIKASI PEMENUHAN KOMPETENSI*
- Pengguna: saya ujilab aja

---

## Kasus 19: Mohon izin Bpk/Ibu, saya mau ikut sertifikasi pemenuhan kompetensi, kapan ya Bpk/Ibu?

**Respon:**

*INFORMASI DAN KETENTUAN LAYANAN VERIFIKASI SKP*

**Percakapan lengkap:**

- Pengguna: Mohon izin Bpk/Ibu, saya mau ikut sertifikasi pemenuhan kompetensi, kapan ya Bpk/Ibu?
- Kolegium: *INFORMASI DAN KETENTUAN LAYANAN VERIFIKASI SKP*

---

## Kasus 20: apakah 2026 ini ada pendaftaran uji kompetensi.?

**Percakapan lengkap:**

- Pengguna: apakah 2026 ini ada pendaftaran uji kompetensi.?
- Pengguna: wkwkwk

---

## Kasus 21: Daftar kompetensi apoteker

**Respon:**

*SERTIFIKASI PEMENUHAN KOMPETENSI*

**Percakapan lengkap:**

- Pengguna: Daftar kompetensi apoteker
- Kolegium: *SERTIFIKASI PEMENUHAN KOMPETENSI*

---

## Kasus 22: Selamat siang, saya wahyuni ysuuf ingin izin bertanya terkait ujian resertifikasi

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Selamat siang, saya wahyuni ysuuf ingin izin bertanya terkait ujian resertifikasi
- Pengguna: Selamat Sore
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 23: 3 untuk sertifikasi pemenuhan kompetensi

**Respon:**

*INFORMASI DAN KETENTUAN LAYANAN VERIFIKASI SKP*
*SERTIFIKASI PEMENUHAN KOMPETENSI*

**Percakapan lengkap:**

- Pengguna: 262186328953065@lid
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: 3 untuk sertifikasi pemenuhan kompetensi
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *SERTIFIKASI PEMENUHAN KOMPETENSI*

---

## Kasus 24: Mohon izin Bpk/Ibu, saya mau ikut sertifikasi pemenuhan kompetensi, kapan ya Bpk/Ibu?

**Percakapan lengkap:**

- Pengguna: Mohon izin Bpk/Ibu, saya mau ikut sertifikasi pemenuhan kompetensi, kapan ya Bpk/Ibu?

---

## Kasus 25: Mohon infonya untuk ujian kompetensi tenga vokasi Farmasi ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: Mohon infonya untuk ujian kompetensi tenga vokasi Farmasi ≡ƒÖÅ≡ƒÅ╗
- Pengguna: HAHAHAHAHAHA
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Dibalik

---

## Kasus 26: Untuk Ujian Kompetensi kapan ada lagi?

**Percakapan lengkap:**

- Pengguna: Untuk Ujian Kompetensi kapan ada lagi?

---

## Kasus 27: Selamat siang. Mohon maaf izin ingin menyanyakan perihal uji kompetensi kembali untuk apoteker, kapan akan di adakan kembali ? Apakah ada dalam waktu dekat ini? Terima kasih sebelumnya

**Percakapan lengkap:**

- Pengguna: Hallo. Selamat sore
- Pengguna: Selamat siang. Mohon maaf izin ingin menyanyakan perihal uji kompetensi kembali untuk apoteker, kapan akan di adakan kembali ? Apakah ada dalam waktu dekat ini? Terima kasih sebelumnya

---

## Kasus 28: 3 sertifikasi pemenuhan kompetensi

**Percakapan lengkap:**

- Pengguna: 3 sertifikasi pemenuhan kompetensi
- Pengguna: Sudah kak

---

## Kasus 29: 3. Sertifikasi Pemenuhan Kompetensi

**Percakapan lengkap:**

- Pengguna: mau live IG, mengundang siapa?
- Pengguna: 3. Sertifikasi Pemenuhan Kompetensi

---

## Kasus 30: Sistem Informasi Sertifikasi CDOB

**Percakapan lengkap:**

- Pengguna: Itu materi boleh dibagi di grup?
- Pengguna: Sistem Informasi Sertifikasi CDOB

---

