﻿# Helpdesk ΓÇö kontak

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: kalau di saya jawabannya spt ini,tiap saya email tpi harus menunggu kapan?

**Percakapan lengkap:**

- Pengguna: Selamat pagi
- Pengguna: kalau di saya jawabannya spt ini,tiap saya email tpi harus menunggu kapan?

---

## Kasus 2: Karna saya sudah meng-email di helpdesk, tp tidak ada kelanjutan sama sekali

**Percakapan lengkap:**

- Pengguna: Karna saya sudah meng-email di helpdesk, tp tidak ada kelanjutan sama sekali

---

## Kasus 3: 2 untuk helpdesk Ditjen SDMK

**Percakapan lengkap:**

- Pengguna: 2 untuk helpdesk Ditjen SDMK

---

## Kasus 4: 4 untuk kontak & kanal informasi kolegium farmasi

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: 4 untuk kontak & kanal informasi kolegium farmasi
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 5: Selamat pagi, apakah boleh dibantu?  atau saya harus menghubungi kemana ya?

**Percakapan lengkap:**

- Pengguna: Selamat pagi, apakah boleh dibantu?  atau saya harus menghubungi kemana ya?

---

## Kasus 6: 4 Kontak & Kanal Informasi Kolegium Farmasi

**Percakapan lengkap:**

- Pengguna: Saya sudah mengurus STR seumur hidup
- Pengguna: 4 Kontak & Kanal Informasi Kolegium Farmasi

---

## Kasus 7: Sama. Ku jg blsny bgini. Memberanikan dri cerit panjang lebar di kontak kolegium yg d grup ini. Di balas sama robot≡ƒñ¡

**Percakapan lengkap:**

- Pengguna: Mohon info kenapa verif skp pengabdian saya lama sekali ya?
- Pengguna: Sama. Ku jg blsny bgini. Memberanikan dri cerit panjang lebar di kontak kolegium yg d grup ini. Di balas sama robot≡ƒñ¡

---

## Kasus 8: 4 Kontak & Kanal Informasi Kolegium Farmasi

**Percakapan lengkap:**

- Pengguna: 4 Kontak & Kanal Informasi Kolegium Farmasi

---

## Kasus 9: Maaf kami sdh menerima hasil TO dari email admin yg didaftarkan

**Percakapan lengkap:**

- Pengguna: Maaf kami sdh menerima hasil TO dari email admin yg didaftarkan

---

## Kasus 10: boleh menghubungi bu rena bendahara ya pak..

**Percakapan lengkap:**

- Pengguna: boleh menghubungi bu rena bendahara ya pak..

---

## Kasus 11: selamat sore. saya Andineke dari PT Actavis. apakah betul ini kontak utk konsultasi pemenuhan kompetensi nakes? terima kasih sebelumnya

**Percakapan lengkap:**

- Pengguna: izin sharing, pa coba di cek dalam excel takutnya ada spasi, atau tanpa petik nya dicek
- Pengguna: selamat sore. saya Andineke dari PT Actavis. apakah betul ini kontak utk konsultasi pemenuhan kompetensi nakes? terima kasih sebelumnya

---

## Kasus 12: @280044970741919 coba cari kontaknya dan tawarin

**Percakapan lengkap:**

- Pengguna: @280044970741919 coba cari kontaknya dan tawarin

---

## Kasus 13: Sekretariat UKOMNAS telah mengirimkan surat pemberitahuan informasi jadwal TO dan ujian melalui email

**Percakapan lengkap:**

- Pengguna: Sekretariat UKOMNAS telah mengirimkan surat pemberitahuan informasi jadwal TO dan ujian melalui email

---

## Kasus 14: Sealamat pagi , izin memperkenalkan diri , saya andika dari PT.Kimia farma , izin beratanya Pak / Ibu , untuk kegiatan Kolegium Farmasi memberikan kesempatan Apoteker yang ingin mengikuti *Sertifikasi

**Percakapan lengkap:**

- Pengguna: Sealamat pagi , izin memperkenalkan diri , saya andika dari PT.Kimia farma , izin beratanya Pak / Ibu , untuk kegiatan Kolegium Farmasi memberikan kesempatan Apoteker yang ingin mengikuti *Sertifikasi Pemenuhan Kompetensi Apoteker*  apakah ada pelaksanaan tahun ini pak/bu ?

---

## Kasus 15: Pastikan emailnya sesuai ya bu

**Percakapan lengkap:**

- Pengguna: harusnya dr tgl 17 bu sesuai surat dr adhoc, mohon memperhatikan informasi dari kami.
- Pengguna: Pastikan emailnya sesuai ya bu

---

## Kasus 16: Sehubungan dengan berakhirnya masa tugas sy sbg kaprodi D3 Anafarma Universitas Sumatera Utara, sy izin undur dari grup ini. Terima kasih, mhn maaf atas segala kekurangan, salam sehat dan sukses selal

**Percakapan lengkap:**

- Pengguna: Sehubungan dengan berakhirnya masa tugas sy sbg kaprodi D3 Anafarma Universitas Sumatera Utara, sy izin undur dari grup ini. Terima kasih, mhn maaf atas segala kekurangan, salam sehat dan sukses selalu. Selanjutnya kiranya admin dapat menambahkan no kontak kaprodi baru Ibu apt. Dr. Sri Yuliasmi, S.Farm., M.Si. (085262527355).
- Pengguna: Selamat siang..

---

## Kasus 17: Betul prof, helpdesk.ditjennakes@kemkes.go.id

**Percakapan lengkap:**

- Pengguna: Betul prof, helpdesk.ditjennakes@kemkes.go.id

---

## Kasus 18: 4. Kontak & Kanal Informasi Kolegium Farmasi

**Percakapan lengkap:**

- Pengguna: 4. Kontak & Kanal Informasi Kolegium Farmasi
- Pengguna: Mohon maaf ...

---

## Kasus 19: Nah klu kendala di MPP pihak ptsp suruh hubungi helpdesk.ditjennakes dr ditjennakes suruh hubungi helpdesk kolegium...tapi masih nyangkut juga..

**Percakapan lengkap:**

- Pengguna: baik pak, saya ijin revisi kembali terkait status mahasiswanya
- Pengguna: Nah klu kendala di MPP pihak ptsp suruh hubungi helpdesk.ditjennakes dr ditjennakes suruh hubungi helpdesk kolegium...tapi masih nyangkut juga..

---

## Kasus 20: 4. kontak & kanal informasi kolegium farmasi

**Percakapan lengkap:**

- Pengguna: masing2 dibayar, karena 1 VA untuk 1 batch, kalau ada 4 batch = 4 VA
- Pengguna: 4. kontak & kanal informasi kolegium farmasi

---

## Kasus 21: mohon bu ida, kami dari Akademi Farmasi Kusuma Husada Purwokerto ijin bertanya. untuk hasil nilai TryOut UKOMNAS kemarin sudah cek di email belum ada nggih bu. buka lewat link juga meminta akses. moho

**Percakapan lengkap:**

- Pengguna: mumpung pada kumpul semua
- Pengguna: mohon bu ida, kami dari Akademi Farmasi Kusuma Husada Purwokerto ijin bertanya. untuk hasil nilai TryOut UKOMNAS kemarin sudah cek di email belum ada nggih bu. buka lewat link juga meminta akses. mohon arahan nya ibu.≡ƒÖÅ≡ƒÅ╗
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 22: iya bu, sudah ada di surat yang kami sampaikan melalui email bu, didownload dari SI Ukomednakes

**Percakapan lengkap:**

- Pengguna: iya bu, sudah ada di surat yang kami sampaikan melalui email bu, didownload dari SI Ukomednakes
- Pengguna: Selamat pagi

---

## Kasus 23: Yth. Bapak/Ibu admin prodi Ukomnas PDPA, Jika terdapat mahasiswa yang sudah didaftarkan dan akan dilakukan pembatalan dengan alasan satu dan lain hal, batas penarikan adalah hari ini pukul 16.00 WIB (

**Percakapan lengkap:**

- Pengguna: Yth. Bapak/Ibu admin prodi Ukomnas PDPA, Jika terdapat mahasiswa yang sudah didaftarkan dan akan dilakukan pembatalan dengan alasan satu dan lain hal, batas penarikan adalah hari ini pukul 16.00 WIB (sesuai pemberitahuan kami melalui email), dan juga bila ada mahasiswa yang tidak bisa ujian di kota institusi PSPA juga batas pengajuannya hari ini pukul 16.00 WIB.
- Pengguna: Selamat siang

---

## Kasus 24: Nama nim email dilengkapi dulu pak

**Percakapan lengkap:**

- Pengguna: Nama di akta lahir jangan2 beda juga ? ≡ƒÿ░
- Pengguna: Nama nim email dilengkapi dulu pak

---

## Kasus 25: Izin, sy tanya admin sy blm ada email masuk, kemudia admin sy bertanya ke grup ya infonya sdh di share di grup ini.

**Percakapan lengkap:**

- Pengguna: Izin, sy tanya admin sy blm ada email masuk, kemudia admin sy bertanya ke grup ya infonya sdh di share di grup ini.

---

## Kasus 26: Sya sdh email sdh satu bulanan juga tpi smpe skrng juga blm ada perubahan di mpp digital

**Percakapan lengkap:**

- Pengguna: Sya sdh email sdh satu bulanan juga tpi smpe skrng juga blm ada perubahan di mpp digital

---

## Kasus 27: InsyaAllah akan ada helpdesk di hari sabtu bu. Ut saat ini yg disiapkan adalah surtu adminnya. Jangan lupa gabung di grup helpdesk≡ƒÖÅ

**Respon:**

Untuk membantu kami melayani sejawat dengan lebih baik, mohon sampaikan keperluan sejawat

**Percakapan lengkap:**

- Pengguna: InsyaAllah akan ada helpdesk di hari sabtu bu. Ut saat ini yg disiapkan adalah surtu adminnya. Jangan lupa gabung di grup helpdesk≡ƒÖÅ
- Kolegium: Untuk membantu kami melayani sejawat dengan lebih baik, mohon sampaikan keperluan sejawat

---

## Kasus 28: 2 Helpdesk ditjen SDMK

**Percakapan lengkap:**

- Pengguna: 2 Helpdesk ditjen SDMK

---

## Kasus 29: Mohon infonya Bu Ida, grup helpdesk yg dimaksud itu apakah grup admin prodi atau ada grup lagi?

**Respon:**

*HELPDESK DITJEN SDM KESEHATAN*

**Percakapan lengkap:**

- Pengguna: Mohon infonya Bu Ida, grup helpdesk yg dimaksud itu apakah grup admin prodi atau ada grup lagi?
- Kolegium: *HELPDESK DITJEN SDM KESEHATAN*

---

## Kasus 30: dari UMP atas nama MarΓÇÖatuh sholikha NIM 2408020135 : Tidak bisa login karena Email tidak terdaftar.

**Percakapan lengkap:**

- Pengguna: dari UMP atas nama MarΓÇÖatuh sholikha NIM 2408020135 : Tidak bisa login karena Email tidak terdaftar.

---

