﻿# Helpdesk ΓÇö ukom

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Maaf ka..mau tanya info jadwal ukomnas kira2 kpan y?

**Percakapan lengkap:**

- Pengguna: Maaf ka..mau tanya info jadwal ukomnas kira2 kpan y?

---

## Kasus 2: selamat sore ka maaf mengganggu waktunya , izin bertanya kaa untuk UKOMNAS / UKMPPAI (PDPA) periode Agustus  2026 masih komposit atu engga ya ka ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: selamat sore ka maaf mengganggu waktunya , izin bertanya kaa untuk UKOMNAS / UKMPPAI (PDPA) periode Agustus  2026 masih komposit atu engga ya ka ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 3: min pendaftaran ukom vokasi farmasi di mana ?

**Percakapan lengkap:**

- Pengguna: min pendaftaran ukom vokasi farmasi di mana ?

---

## Kasus 4: TOPIK UKOMNAS PDPA

**Percakapan lengkap:**

- Pengguna: TOPIK UKOMNAS PDPA

---

## Kasus 5: Selamat pagi kak, izin bertanya pendaftaran ukom apakah sudah dibuka untuk tenaga vokasi farmasi?

**Percakapan lengkap:**

- Pengguna: bu @249164088758352 mohon dicek di rekening koran
- Pengguna: Kita undang peraih nilai tertinggi periode lalu
- Pengguna: Selamat pagi kak, izin bertanya pendaftaran ukom apakah sudah dibuka untuk tenaga vokasi farmasi?

---

## Kasus 6: Selamat Siang Ibu. Mohon izin bertanya, terkait dengan grup WA KCC. apakah member yang ada didalam grup tersebut sudah merupakan KCC dari setiap CBT center atau hanya perwakilan dosen/prodi?

**Percakapan lengkap:**

- Pengguna: Selamat Siang Ibu. Mohon izin bertanya, terkait dengan grup WA KCC. apakah member yang ada didalam grup tersebut sudah merupakan KCC dari setiap CBT center atau hanya perwakilan dosen/prodi?

---

## Kasus 7: ingin menanyakan untuk surat pernyataan prodi lampiran nya hanya yang akan ikut TO UKOMNAS saja atau keseluruhan karena di UMP yang mengikuti TO UKOMNAS hanya first taker saja tidak dengan retaker (re

**Percakapan lengkap:**

- Pengguna: ingin menanyakan untuk surat pernyataan prodi lampiran nya hanya yang akan ikut TO UKOMNAS saja atau keseluruhan karena di UMP yang mengikuti TO UKOMNAS hanya first taker saja tidak dengan retaker (retaker hanya ikut pada saat UKOMNAS saja). mohon infonya karena kemaren kami sudah kirim surat tapi lampirannya hanya first taker saja ≡ƒÖÅ

---

## Kasus 8: Dst sampai habis 100 persen CBT murni

**Percakapan lengkap:**

- Pengguna: absen yg sudah ngisi
- Pengguna: Dst sampai habis 100 persen CBT murni

---

## Kasus 9: 0094_2026_V3_Informasi jadwal  Ukomnas PDPA.pdf

**Percakapan lengkap:**

- Pengguna: 0094_2026_V3_Informasi jadwal  Ukomnas PDPA.pdf

---

## Kasus 10: Di surat pernyataan dilampirkan semua mahasiswa baik itu first taker dan retaker, sehingga nanti untuk UKOMNAS tidak perlu mengirimkan surat pernyataan kembali

**Percakapan lengkap:**

- Pengguna: sudah diulang Pak, saat upload aman hijau semua setelah dikonfirmasi menjai merah di nim nya...
- Pengguna: Di surat pernyataan dilampirkan semua mahasiswa baik itu first taker dan retaker, sehingga nanti untuk UKOMNAS tidak perlu mengirimkan surat pernyataan kembali

---

## Kasus 11: Kapan ada ujian ukom apoteker

**Respon:**

*LIVE DI YOUTUBE*

**Percakapan lengkap:**

- Pengguna: Bapak/ibu untuk CBT center, tidak semua tiap prodi akan digunakan ujian, karena diatur adhoc bisa jadi mhsw diikutkan di cbt center lain (bukan milik PSPAnya) namun masih dalam satu kota
- Pengguna: Selamat siang
- Kolegium: *LIVE DI YOUTUBE*
- Pengguna: Kapan ada ujian ukom apoteker

---

## Kasus 12: Ijin bertnya, untuk OSCE apakah lokasi nya seperti UKOM atau bisa di kampus sendiri nggih. Moho  arahan nya bapak/ibu.≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: Baik pak, terimakasih nggih≡ƒÖÅ
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Ijin bertnya, untuk OSCE apakah lokasi nya seperti UKOM atau bisa di kampus sendiri nggih. Moho  arahan nya bapak/ibu.≡ƒÖÅ≡ƒÅ╗

---

## Kasus 13: Mohon izin bertanya untuk ukom D3 farmasi jadwalnya kapan ya ? Apakah ada link pendaftaran nya ? Terimakasih ≡ƒÖÅ≡ƒÅ╗

**Respon:**

Perlu diperhatikan yang ada pendaftaran OSCE tapi CBT nya masih nol

**Percakapan lengkap:**

- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Mohon bantuannya ibu bapa≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗
- Pengguna: Mohon izin bertanya untuk ukom D3 farmasi jadwalnya kapan ya ? Apakah ada link pendaftaran nya ? Terimakasih ≡ƒÖÅ≡ƒÅ╗
- Kolegium: Perlu diperhatikan yang ada pendaftaran OSCE tapi CBT nya masih nol
- Pengguna: Baru masuk

---

## Kasus 14: Ijin ibu untuk TO kami akan ujian di TUK CBT kami sendiri apakah di sistemnya diajukan ibu?

**Percakapan lengkap:**

- Pengguna: Boleh bu
- Pengguna: Ijin ibu untuk TO kami akan ujian di TUK CBT kami sendiri apakah di sistemnya diajukan ibu?

---

## Kasus 15: 0094_2026_V3_Informasi jadwal  Ukomnas PDPA.pdf

**Percakapan lengkap:**

- Pengguna: 0094_2026_V3_Informasi jadwal  Ukomnas PDPA.pdf
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 16: Selamat dan sukses bagi 7829 mahasiswa peserta didik vokasi farmasi yang akan menjalankan Uji Coba/Try Out UKOMNAS-PDVF pada Sabtu-Minggu, 23-24 Mei 2026  yang tersebar di 61 CBT Center se-Indonesia.

**Percakapan lengkap:**

- Pengguna: Selamat sore
- Pengguna: Selamat dan sukses bagi 7829 mahasiswa peserta didik vokasi farmasi yang akan menjalankan Uji Coba/Try Out UKOMNAS-PDVF pada Sabtu-Minggu, 23-24 Mei 2026  yang tersebar di 61 CBT Center se-Indonesia.

---

## Kasus 17: untuk IPK sebenarnyta akan digunakan pada saat ukom ya bu, jadi pada saat TO tidak terlalu menjadi concern.

**Percakapan lengkap:**

- Pengguna: untuk IPK sebenarnyta akan digunakan pada saat ukom ya bu, jadi pada saat TO tidak terlalu menjadi concern.
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 18: Selamat siang. Saya izin bertanya. Untuk IPK yang ada di website UKOMNAS milik Universitas Ma Chung apakah bisa berubah seperti yang kami input di Feeder? Karena kami belum melakukan CBT Internal dan 

**Percakapan lengkap:**

- Pengguna: kapan otw
- Pengguna: Kolegium Dokter blm mampu menggiring opini
- Pengguna: Selamat siang. Saya izin bertanya. Untuk IPK yang ada di website UKOMNAS milik Universitas Ma Chung apakah bisa berubah seperti yang kami input di Feeder? Karena kami belum melakukan CBT Internal dan OSCE Internal, sehingga IPK yang muncul di website masih IPK sebelum melakukan CBT dan OSCE Internal.

---

## Kasus 19: Perkenalkan sy dg Bambang dari admin CBT universitas kadiri kota Kediri Jawa Timur

**Percakapan lengkap:**

- Pengguna: Perkenalkan sy dg Bambang dari admin CBT universitas kadiri kota Kediri Jawa Timur

---

## Kasus 20: Nilai CBT tertinggi atau komposit tertinggi?

**Percakapan lengkap:**

- Pengguna: okeey mas tak coba nyaa
- Pengguna: mohon izin bapak, meneruskan arahan kemarin kami sudah sempat upload untuk first taker menjadi terbagi beberapa batch dgn sesuai abjad, karena total peserta yg kami kirim 240an anak. dan dr batch tsb sudah kami lakukan upload data KTP dan PasPhoto. apakah ini tidak apa2 pak?≡ƒÖÅ≡ƒÅ╗
- Pengguna: Nilai CBT tertinggi atau komposit tertinggi?

---

## Kasus 21: Ijin ibu kalau cbt center kampus kami tidak terdaftar di surat, apa yang harus dilakukan?

**Percakapan lengkap:**

- Pengguna: Ijin ibu kalau cbt center kampus kami tidak terdaftar di surat, apa yang harus dilakukan?

---

## Kasus 22: Harusnya aktif atau menunggu UKOM

**Percakapan lengkap:**

- Pengguna: Assalamualaikum selamat malam
- Pengguna: Sertifikasi pemenuhan kompetensi
- Pengguna: Harusnya aktif atau menunggu UKOM
- Pengguna: Bagaimana yah?

---

## Kasus 23: benar, misal Universitas Padjadjaran menjadi "UNPAD First Taker UKOMNAS PDPA II 2026"

**Percakapan lengkap:**

- Pengguna: Kami juga ada kasus serupa, terkendala di STR krena ternyata data t4 dan tgl lahir di pddikti tidak sinkron dengan data dukcapil, memang data t4 dan tgl lahir tidak kelihatan ketika kita cek di pddikti, jadi kami minta ybs untuk ajukan perubahan data di pddikti, sesuai dengan data dukcapil...Alhamdulillah sudah aman, cuman memang pengajuan perubahan data pddikti membutuhkan waktu pak≡ƒÖÅ
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: benar, misal Universitas Padjadjaran menjadi "UNPAD First Taker UKOMNAS PDPA II 2026"

---

## Kasus 24: tadi tim Adhoc UKOMNAS menyampaikan LPJ dan RTL UKOMNAS

**Percakapan lengkap:**

- Pengguna: bu @249164088758352 tolong dicek.
- Pengguna: tadi tim Adhoc UKOMNAS menyampaikan LPJ dan RTL UKOMNAS

---

## Kasus 25: Halo selamat sore, saya Laura mau tanya soal info UKOM bisa?

**Percakapan lengkap:**

- Pengguna: Halo selamat sore, saya Laura mau tanya soal info UKOM bisa?
- Pengguna: Ini bukan ya?

---

## Kasus 26: Oiya..baik ibu, apakah pihak kami harus mengirimkan surat dulu ke kampus yang akan kami jadikan tempat ujian?

**Percakapan lengkap:**

- Pengguna: Oiya..baik ibu, apakah pihak kami harus mengirimkan surat dulu ke kampus yang akan kami jadikan tempat ujian?

---

## Kasus 27: 0096_2026_V0_Informasi pendaftaran TO CBT.pdf

**Percakapan lengkap:**

- Pengguna: Ini case nya solved, mungkin bisa jadi contoh kasus
- Pengguna: 0096_2026_V0_Informasi pendaftaran TO CBT.pdf

---

## Kasus 28: Mohon maaf untuk briefing uji coba dan uji coba ukomnas ada perubahan jadwal nggih?

**Percakapan lengkap:**

- Pengguna: 7776000
- Pengguna: Mohon maaf untuk briefing uji coba dan uji coba ukomnas ada perubahan jadwal nggih?
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 29: Jadi ini untuk IPK S1 sudah diinput sesuai bu, tapi yang saya tanyakan untuk IPK PSPPA nya. Jadi kami belum melakukan CBT dan OSCE sehingga IPK nya belum IPK final. jadi untuk IPK PSPPAnya apakah bisa

**Percakapan lengkap:**

- Pengguna: Berikut bu
- Pengguna: Jadi ini untuk IPK S1 sudah diinput sesuai bu, tapi yang saya tanyakan untuk IPK PSPPA nya. Jadi kami belum melakukan CBT dan OSCE sehingga IPK nya belum IPK final. jadi untuk IPK PSPPAnya apakah bisa berubah di websitenya bu?

---

## Kasus 30: Selamat sore Bapak/Ibu.. untuk kartu peserta sudah dapat diunduh dari SI UKOMEDNAKES. Diprint berwarna pada kertas HVS ukuran A5 (A4 dibagi 2)

**Percakapan lengkap:**

- Pengguna: Selamat sore Bapak/Ibu.. untuk kartu peserta sudah dapat diunduh dari SI UKOMEDNAKES. Diprint berwarna pada kertas HVS ukuran A5 (A4 dibagi 2)
- Pengguna: Tos Pak Prim

---

