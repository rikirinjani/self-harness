﻿# Helpdesk ΓÇö data-error

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Maaf bapak/ibu untuk permasalahan saya saat ini akhirnya sudah terselesaikan. Utk permohonan terkait kendala yang saya alami saya batalkan ya pak/bu. Terima kasih atas waktunya ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM
- Pengguna: Maaf bapak/ibu untuk permasalahan saya saat ini akhirnya sudah terselesaikan. Utk permohonan terkait kendala yang saya alami saya batalkan ya pak/bu. Terima kasih atas waktunya ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 2: Assalamualaikum pak/bu dan selamat malam. Saya Ade Firmansyah dari mahasiswa Universitas Muhammadiyah Prof.Dr. Hamka. Mohon maaf saya izin bertanya pak/bu saya telat mengirimkan pendaftaran UKOMNAS PP

**Percakapan lengkap:**

- Pengguna: Assalamualaikum min
- Pengguna: Assalamualaikum pak/bu dan selamat malam. Saya Ade Firmansyah dari mahasiswa Universitas Muhammadiyah Prof.Dr. Hamka. Mohon maaf saya izin bertanya pak/bu saya telat mengirimkan pendaftaran UKOMNAS PPDA dikarena email saya dari semalam bermasalah dan tidak bisa terkirim sampai tadi sore pak/bu. Boleh minta tolong bantuannya pak/bu apakah saya masih bisa terdaftar?. Terimakasih pak/bu sebelumnya≡ƒÖÅ≡ƒÅ╗

---

## Kasus 3: Berikut saya sertakan datanya :

**Percakapan lengkap:**

- Pengguna: Berikut saya sertakan datanya :

---

## Kasus 4: Data keprofesian menjadi kosong, dulu sudah lengkap

**Percakapan lengkap:**

- Pengguna: *update* Institusi yang masih berstatus menunggu pembayaran :
- Pengguna: Data keprofesian menjadi kosong, dulu sudah lengkap

---

## Kasus 5: sudah Pak, masih error. Menurut saya mungkin karena sebelumnya sudah ada foto yang kemudian saya ingin ganti dengan yang benar tapi tidak bisa ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: akan dikoordinasikan oleh PP bu, PP biasanya akan membuat grup WA dg komponen ujian di CBT center
- Pengguna: sudah Pak, masih error. Menurut saya mungkin karena sebelumnya sudah ada foto yang kemudian saya ingin ganti dengan yang benar tapi tidak bisa ≡ƒÖÅ

---

## Kasus 6: Assallammualaikum, mohon maaf baru dikirimkan surat permohonan pengisian data untuk pengisian data osce, mohon maaf atas keterlambatannya≡ƒÖÅ≡ƒÖÅ

**Percakapan lengkap:**

- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Assallammualaikum, mohon maaf baru dikirimkan surat permohonan pengisian data untuk pengisian data osce, mohon maaf atas keterlambatannya≡ƒÖÅ≡ƒÖÅ

---

## Kasus 7: Yang bermasalah sebenarnya MPPD nya

**Percakapan lengkap:**

- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Yang bermasalah sebenarnya MPPD nya
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 8: 56. Permohonan Pengisian Data OSCE.pdf

**Percakapan lengkap:**

- Pengguna: Nama: PUTU SUMARTA SIDIQ NGADISETIA
- Pengguna: itu sebenarnya untuk menarik data IPK S1 (digunakan untuk nanti menilai komposit pada saat CBT)
- Pengguna: 56. Permohonan Pengisian Data OSCE.pdf

---

## Kasus 9: Bapak ibu berikut rekap pendataan jumlah peserta TO yg diisikan melalui gform pemutakhiran data. Mohon dicek bapak ibu jika belum sesuai atau ada perubahan mohon japri ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Selamat malam..
- Pengguna: Bapak ibu berikut rekap pendataan jumlah peserta TO yg diisikan melalui gform pemutakhiran data. Mohon dicek bapak ibu jika belum sesuai atau ada perubahan mohon japri ≡ƒÖÅ
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 10: berarti file dari mhs nya pak yg bermasalah

**Percakapan lengkap:**

- Pengguna: berarti file dari mhs nya pak yg bermasalah

---

## Kasus 11: maaf salah kirim

**Percakapan lengkap:**

- Pengguna: Baik pak.. Terima kasih
- Pengguna: maaf salah kirim

---

## Kasus 12: berarti ada masalah di databse

**Percakapan lengkap:**

- Pengguna: berarti ada masalah di databse

---

## Kasus 13: Assalamualaikum pak/bu dan selamat malam. Saya Ade Firmansyah dari mahasiswa Universitas Muhammadiyah Prof.Dr. Hamka. Mohon maaf saya izin bertanya pak/bu saya telat mengirimkan pendaftaran dikarena e

**Percakapan lengkap:**

- Pengguna: Tanggal 11 juli pukul 23.59 WIB
- Pengguna: Assalamualaikum pak/bu dan selamat malam. Saya Ade Firmansyah dari mahasiswa Universitas Muhammadiyah Prof.Dr. Hamka. Mohon maaf saya izin bertanya pak/bu saya telat mengirimkan pendaftaran dikarena email saya dari semalam bermasalah dan tidak bisa terkirim sampai tadi sore pak/bu. Boleh minta tolong bantuannya pak/bu apakah saya masih bisa terdaftar?. Terimakasih pak/bu sebelumnya≡ƒÖÅ≡ƒÅ╗

---

## Kasus 14: Data Institusi belum mendapatkan PISN ukom periode Maret 2026 :

**Percakapan lengkap:**

- Pengguna: Selamat bergabung Ibu Sri Yuliasmi ≡ƒÖÅ≡ƒÅ╝≡ƒÿè
- Pengguna: mohon dilewati saja pak rizky, karena sudah otomatis ngelink dg data PD dikti
- Pengguna: yang 3 lagi coba dicari pak
- Pengguna: izin share, tadi saya juga begini setelah di cek ternyata ada yang terlewat diisikan alamatnya pak ≡ƒÖÅ≡ƒÅ╗ dicek lagi excelnya siapa tau ada ang terlewat juga..
- Pengguna: Data Institusi belum mendapatkan PISN ukom periode Maret 2026 :

---

## Kasus 15: Surat pernyataan dari Program Studi yang ditanda tangani pimpinan institusi/prodi yang menyatakan bahwa data IPK dan status mahasiswa adalah benar dengan disertai lampiran data nama mahasiswa, NIM, da

**Percakapan lengkap:**

- Pengguna: selamat pagi, saya mau tanya
- Pengguna: Sekarang?
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Surat pernyataan dari Program Studi yang ditanda tangani pimpinan institusi/prodi yang menyatakan bahwa data IPK dan status mahasiswa adalah benar dengan disertai lampiran data nama mahasiswa, NIM, dan IPK S1 (urut sesuai dengan data yang dicantumkan dalam pendaftaran) dan dikirimkan pada link berikut: https://s.id/PernyataanProdiPSPA dan Juga Admin prodi mengunggah data peserta yang telah disusun di template excel pada link tersebut (sama linknya) : https://s.id/PernyataanProdiPSPA

---

## Kasus 16: karena di panduan harusnya validasi data ke kolegium, namun di kami nlm muncul

**Percakapan lengkap:**

- Pengguna: 242725848924408@lid
- Pengguna: karena di panduan harusnya validasi data ke kolegium, namun di kami nlm muncul

---

## Kasus 17: sore, ibu/bapak izin konfirmasi, saya mengajukan perubahan data email satu mahasiswa kami dari universitas YPIB Majalengka, mhs tersebut sudah assigned batch untuk uji coba, mohon dibantu untuk dikonf

**Percakapan lengkap:**

- Pengguna: sore, ibu/bapak izin konfirmasi, saya mengajukan perubahan data email satu mahasiswa kami dari universitas YPIB Majalengka, mhs tersebut sudah assigned batch untuk uji coba, mohon dibantu untuk dikonfirmasi ≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗

---

## Kasus 18: susai petunjuk IPK yang dimasukkan di database excel tetap IPK S1 pak, ini nanti akan dibutuhkan pada saat perhitungan Nilai Komposit pada saat UKOMNAS nantinya.

**Percakapan lengkap:**

- Pengguna: sebentar ya bu tunggu arahan pak sandra @18412675821770
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: susai petunjuk IPK yang dimasukkan di database excel tetap IPK S1 pak, ini nanti akan dibutuhkan pada saat perhitungan Nilai Komposit pada saat UKOMNAS nantinya.

---

## Kasus 19: Data yang digunakan yi data dari PDPT dikti saat bapak/ibu sudah melakukan assign jadwal ujian di SI ukomednakes

**Percakapan lengkap:**

- Pengguna: Data yang digunakan yi data dari PDPT dikti saat bapak/ibu sudah melakukan assign jadwal ujian di SI ukomednakes

---

## Kasus 20: ini saya sudah coba pak, tapi yang ter upload tetapkurang 5, yang saya bingungkan, 5 mahasiswa yang gagal pertama dan 5 yang gagal du upload-an kedua ada yang berbeda sehingga saya tdk tau masalahnya 

**Percakapan lengkap:**

- Pengguna: ini saya sudah coba pak, tapi yang ter upload tetapkurang 5, yang saya bingungkan, 5 mahasiswa yang gagal pertama dan 5 yang gagal du upload-an kedua ada yang berbeda sehingga saya tdk tau masalahnya apa

---

## Kasus 21: Selamat malam Bapak/Ibu : Jika Prodi mengajukan mahasiswanya untuk ujian di luar kota institusi PSPA dimohon Prodi mengirimkan surat dengan menyertakan data peserta (nama, NIM), kota yang dituju, dan 

**Percakapan lengkap:**

- Pengguna: Selamat malam Bapak/Ibu : Jika Prodi mengajukan mahasiswanya untuk ujian di luar kota institusi PSPA dimohon Prodi mengirimkan surat dengan menyertakan data peserta (nama, NIM), kota yang dituju, dan alasannya. surat tersebut diupload melalui link form berikut :  https://bit.ly/3SlnEL9 (dengan batas akhir yi Tanggal 17 Juni 2026, pukul 16.00 WIB). Panitia akan mempertimbangkan pengajuan tersebut sesuai dengan ketersediaan tempat/kapasitas CBT center di kota yang dituju tersebut.

---

## Kasus 22: Saya blm bisa menajwab karena masalahnya blm ketemu

**Percakapan lengkap:**

- Pengguna: Saya blm bisa menajwab karena masalahnya blm ketemu
- Pengguna: Tolong dibantu

---

## Kasus 23: Ya pusing juga saya ditanya begitu.. karena masing2 orang beda-beda masalah nya

**Percakapan lengkap:**

- Pengguna: Izin bertanya bapak/ibu, pada saat upload peserta ada beberapa peserta yang datanya belum valid dengan keterangan nama tidak ditemukan dalam DIKTI tapi kami cek di DIKTI nama mahasiswa tersebut ada, mohon izin arahannya bapak/ibu≡ƒÖÅ≡ƒÅ╗
- Pengguna: Ya pusing juga saya ditanya begitu.. karena masing2 orang beda-beda masalah nya

---

## Kasus 24: pa izin, untuk data excel yang di upload apakah mengurut sesuai nama atau nim pa?

**Percakapan lengkap:**

- Pengguna: pa izin, untuk data excel yang di upload apakah mengurut sesuai nama atau nim pa?

---

## Kasus 25: ≡ƒôî  Pengisian Ajuan Data OSCE / OSPE 2026

**Percakapan lengkap:**

- Pengguna: bisa dibagikan?
- Pengguna: Baik Bu, Terima kasih ≡ƒÖÅ≡ƒÅ╗
- Pengguna: ≡ƒôî  Pengisian Ajuan Data OSCE / OSPE 2026

---

## Kasus 26: Berikut link pemutakhiran data yg perlu diisi oleh prodi, mohon bantuan bapak ibu : https://bit.ly/New_pemutakhirandataprodi

**Percakapan lengkap:**

- Pengguna: Berikut link pemutakhiran data yg perlu diisi oleh prodi, mohon bantuan bapak ibu : https://bit.ly/New_pemutakhirandataprodi

---

## Kasus 27: semua pergantian data tsb juga mengganti foto yang ada dengan foto lain.

**Percakapan lengkap:**

- Pengguna: ditunggu ya pak, sampai batas akhir pengajuan hari ini jam 18.00 WIB.
- Pengguna: semua pergantian data tsb juga mengganti foto yang ada dengan foto lain.
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 28: Kesalahannya pada saat pengisian data di excel bu?

**Percakapan lengkap:**

- Pengguna: Kesalahannya pada saat pengisian data di excel bu?
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 29: apanya yg mau divalidasi bu? sudah valid semua kan?

**Percakapan lengkap:**

- Pengguna: kita bikin konten ya?
- Pengguna: apanya yg mau divalidasi bu? sudah valid semua kan?

---

## Kasus 30: nanti saat pendaftaran ujian bu di sinkroniasi lagi

**Percakapan lengkap:**

- Pengguna: nanti saat pendaftaran ujian bu di sinkroniasi lagi

---

