﻿# Helpdesk ΓÇö prosedur

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Bagaimana untuk informasiny kak?

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Bagaimana untuk informasiny kak?

---

## Kasus 2: Impulsif itu seperti ada orang lain di dalam diri ini yang mengajak secara tiba-tiba

**Percakapan lengkap:**

- Pengguna: Impulsif itu seperti ada orang lain di dalam diri ini yang mengajak secara tiba-tiba

---

## Kasus 3: izin menambah alternatif cara pak/bu,

**Percakapan lengkap:**

- Pengguna: izin menambah alternatif cara pak/bu,

---

## Kasus 4: Status di PDDikti yang di cek adalah status Apotekernya bukan sarjana, syaratnya harus aktif atau menunggu ujian

**Percakapan lengkap:**

- Pengguna: Status di PDDikti yang di cek adalah status Apotekernya bukan sarjana, syaratnya harus aktif atau menunggu ujian

---

## Kasus 5: Bagaimana kalo nilai tertinggi di beberapa tempat Pak Prim?

**Percakapan lengkap:**

- Pengguna: Izin menjawab, ini sama dengan kasus kampus kami kemarin setelah dicek ternyata ada kesalahan penulisan pada nim contoh : nim apt. 123, seharusnya pada nim tersebut tidak ada spasi antara huruf dan angkanya≡ƒÖÅ≡ƒÅ╗
- Pengguna: Bagaimana kalo nilai tertinggi di beberapa tempat Pak Prim?
- Pengguna: Oh iya

---

## Kasus 6: Topic: Sosialisasi Tata Cara Pendaftaran Uji Coba (TO) Ukomnas PDPA

**Percakapan lengkap:**

- Pengguna: Topic: Sosialisasi Tata Cara Pendaftaran Uji Coba (TO) Ukomnas PDPA

---

## Kasus 7: Selamat pagi, saya berencana untuk ujian resertifikasi. Bagaimana prosedurnya?

**Percakapan lengkap:**

- Pengguna: Selamat pagi, saya berencana untuk ujian resertifikasi. Bagaimana prosedurnya?
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 8: izin pak, ini PDDIKTI sarjana, yg jadi syarat PDDIKTI Apoteker, harus aktif atau menunggu ujian.

**Percakapan lengkap:**

- Pengguna: izin pak, ini PDDIKTI sarjana, yg jadi syarat PDDIKTI Apoteker, harus aktif atau menunggu ujian.
- Pengguna: Loh blm tidur

---

## Kasus 9: jadi harus menunggu konfirmasi manual atau bagaimana Pak?

**Percakapan lengkap:**

- Pengguna: jadi harus menunggu konfirmasi manual atau bagaimana Pak?
- Pengguna: Ketik 1
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 10: Topic: Sosialisasi Tata Cara Pendaftaran Uji Coba (TO) Ukomnas PDPA

**Percakapan lengkap:**

- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Baik pak terima kasih
- Pengguna: Topic: Sosialisasi Tata Cara Pendaftaran Uji Coba (TO) Ukomnas PDPA

---

## Kasus 11: untuk Surat tata cara pendaftaran akan kami kirimkan juga ke Prodi segera.

**Percakapan lengkap:**

- Pengguna: Kasus yabg sama dari UMP atas nama FITROTUT DAROJA TUL ALAWIYAH tetapi di kartu ujian FITROTUTDAROJA (tidak dispasi)
- Pengguna: untuk Surat tata cara pendaftaran akan kami kirimkan juga ke Prodi segera.
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 12: Selamat siang, saya Rima mau bertanya apakah ada jadwal uji kompetensi apoteker terdekat yg diadakan secara online? Terima kasih≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Bapak/ibu pimpinan mohon pengawalannya dalam registrasi ukomnas periode 1. Utamanya dalam penamaan batch disesuaikan dengan ketentuan yang telah tercantum dalam surat≡ƒÖÅ
- Pengguna: njih bu, untuk str, langsung dengankonsil
- Pengguna: Selamat malam Bapak/Ibu
- Pengguna: Selamat siang, saya Rima mau bertanya apakah ada jadwal uji kompetensi apoteker terdekat yg diadakan secara online? Terima kasih≡ƒÖÅ

---

## Kasus 13: bagaimana kalau dicoba diulang dari upload excel?

**Percakapan lengkap:**

- Pengguna: bagaimana kalau dicoba diulang dari upload excel?

---

## Kasus 14: Kmren januari saya ikut ujian kompetensi setelah lebih dari 5 tahun tidak berpraktik dan di nyatakan lolos. Bagaimana untuk cara update kompetensi tersebut di satu sehat nggih?

**Percakapan lengkap:**

- Pengguna: Kmren januari saya ikut ujian kompetensi setelah lebih dari 5 tahun tidak berpraktik dan di nyatakan lolos. Bagaimana untuk cara update kompetensi tersebut di satu sehat nggih?

---

## Kasus 15: coba caranya begini, foto dari mhs dikirim ke WA, lalu di-edit di WA, lalu harisl editan tersebut diupload

**Percakapan lengkap:**

- Pengguna: coba caranya begini, foto dari mhs dikirim ke WA, lalu di-edit di WA, lalu harisl editan tersebut diupload

---

## Kasus 16: Hallo ka sy lagi ikut webinar tetapi tidak bisa grup wa nya, bagaimana ya?

**Percakapan lengkap:**

- Pengguna: Hallo ka sy lagi ikut webinar tetapi tidak bisa grup wa nya, bagaimana ya?
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Selamat siang

---

## Kasus 17: Secara istimewa terdapat kata "farmasi klinis" seharusnya akan berdampang positif dan bisa memaksa sejawat praktisi di rumah sakit (dan komunitas mungkin) utk mengambil kewenangan/tanggung jawabnya se

**Percakapan lengkap:**

- Pengguna: sami-sami, Bu Dekan
- Pengguna: Secara istimewa terdapat kata "farmasi klinis" seharusnya akan berdampang positif dan bisa memaksa sejawat praktisi di rumah sakit (dan komunitas mungkin) utk mengambil kewenangan/tanggung jawabnya secara proper berdasar regulasi. Bahkan dapat membamper dari upaya named dan nakes lain untuk mengambil alih kewenangan.                                                                                                                                                                                      
- Pengguna: siap pak.

---

## Kasus 18: Setelah saya cek kembali dokumen baru tidak bisa masuk dan menjadi seperti ini

**Percakapan lengkap:**

- Pengguna: Setelah saya cek kembali dokumen baru tidak bisa masuk dan menjadi seperti ini
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 19: Di Jogja rasanya kurang ada warung  Minang yang otentik apalagi yang ada rasa manis-manisnya, Pak Datuk Ketua. Nha, kalau sedang di Bandung ada warung Minang Payakumbuh otentik namanya Malah Dicubo, l

**Percakapan lengkap:**

- Pengguna: Di Jogja rasanya kurang ada warung  Minang yang otentik apalagi yang ada rasa manis-manisnya, Pak Datuk Ketua. Nha, kalau sedang di Bandung ada warung Minang Payakumbuh otentik namanya Malah Dicubo, lokasi di pintu Selatan stasiun Bandung.  Banyak vloggers yang mengulas warung itu. Tidak jauh dari situ ada perkedel Bondon tetapi bukanya jam 11 malam. Sebelah kirinya ada sate Hadori. Kalau mau pulang bisa mampir Utara Stasiun Bandung ada toko oleh-oleh Kartikasari yang karyawannya kalau berbicara

---

## Kasus 20: Maaf bapak/ibu ini maksudnya gimana ya?di tata cara pendaftaran sdh dijelaskan bhw kolom ipk adalah ipk s1. Apakah ibu atau bapak mengisikan ipk apoteker ?

**Percakapan lengkap:**

- Pengguna: udah rilis pa
- Pengguna: Maaf bapak/ibu ini maksudnya gimana ya?di tata cara pendaftaran sdh dijelaskan bhw kolom ipk adalah ipk s1. Apakah ibu atau bapak mengisikan ipk apoteker ?

---

## Kasus 21: Izin bertanya bpk/ibu, utk briefing PL bagaimana? Apakah nanti akan ada grup khusus PL?

**Percakapan lengkap:**

- Pengguna: Izin bertanya bpk/ibu, utk briefing PL bagaimana? Apakah nanti akan ada grup khusus PL?
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 22: Bapak Ibu.. Surat pemberitahuan untuk tata cara pendaftaran pada SI Ukomednakes sedang diproses, mudah2an malam ini bs dikirim ke prodi. dan untuk link zoom sosialisasi pendaftaran yi :

**Percakapan lengkap:**

- Pengguna: Baik pak
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Bapak Ibu.. Surat pemberitahuan untuk tata cara pendaftaran pada SI Ukomednakes sedang diproses, mudah2an malam ini bs dikirim ke prodi. dan untuk link zoom sosialisasi pendaftaran yi :
- Pengguna: Halllo

---

## Kasus 23: PRB kompleks di dokumen dan pengadaan pak kevin

**Percakapan lengkap:**

- Pengguna: PRB kompleks di dokumen dan pengadaan pak kevin
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 24: Bpk Ibu, tata cara download kartu peserta akan kita berikan, kalau memang kartu pesertanya sudah siap untuk di download

**Percakapan lengkap:**

- Pengguna: Dari universitas Al-Irsyad Cilacap,ok saya ajukan lagi. ≡ƒÖÅ≡ƒÅ╝
- Pengguna: Bpk Ibu, tata cara download kartu peserta akan kita berikan, kalau memang kartu pesertanya sudah siap untuk di download

---

## Kasus 25: silahkan dicoba bu @83009000751234 cara ini berhasil

**Percakapan lengkap:**

- Pengguna: silahkan dicoba bu @83009000751234 cara ini berhasil

---

## Kasus 26: Kartu peserta tidak ada fotonya bagaimana ya pak?

**Percakapan lengkap:**

- Pengguna: Kartu peserta tidak ada fotonya bagaimana ya pak?

---

## Kasus 27: Mekanisme PP dan PL bagaimana? PP diusulkan atau lgs ditentukan oleh kolegium?

**Percakapan lengkap:**

- Pengguna: Mekanisme PP dan PL bagaimana? PP diusulkan atau lgs ditentukan oleh kolegium?

---

## Kasus 28: Persatuan dan kesatuan yg perlu dijaga,kebersamaan dlm setiap langkah perlu dibina dan selaras dgn tujuan kita utk pendidikan org byk,  yang terbaik utk kita semua≡ƒÖÅ≡ƒÖÅ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Saya rasa beberapa PTN mungkin dirugikan dgn hal ini. Tolong dikemudian hari hal ini menjadi evaluasi oleh tim adhoc dan kolegium..
- Pengguna: Persatuan dan kesatuan yg perlu dijaga,kebersamaan dlm setiap langkah perlu dibina dan selaras dgn tujuan kita utk pendidikan org byk,  yang terbaik utk kita semua≡ƒÖÅ≡ƒÖÅ≡ƒÖÅ

---

## Kasus 29: Ass.ijin Pak Rosena masing" periode dialokasikan 3 hari, Kamis-Sabtu, bagaimana kalo misalnya ada yg membutuhkan waktu lebih dari 3 hari, apakah bisa periode 1 dan 2?

**Percakapan lengkap:**

- Pengguna: Ass.ijin Pak Rosena masing" periode dialokasikan 3 hari, Kamis-Sabtu, bagaimana kalo misalnya ada yg membutuhkan waktu lebih dari 3 hari, apakah bisa periode 1 dan 2?
- Pengguna: Yaah masih jauh

---

## Kasus 30: Dari list tersebut sebenarnya ada beberapa kaprodi yang awalnya menghubungi kami karena tidak bisa mendapat pisn, tapi kemudian di list ternyata bisa mendapat pisn. Barangkali hal tersebut bisa dibagi

**Percakapan lengkap:**

- Pengguna: Dari list tersebut sebenarnya ada beberapa kaprodi yang awalnya menghubungi kami karena tidak bisa mendapat pisn, tapi kemudian di list ternyata bisa mendapat pisn. Barangkali hal tersebut bisa dibagikan ke wag kaprodi, bagaimana cara pisn nya keluar tanpa menunggu list kelulusan. Ijin, mudah mudahan di wag yang lain beliau beliau berkenan share ≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗

---

