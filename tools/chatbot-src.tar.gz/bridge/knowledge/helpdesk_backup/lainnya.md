﻿# Helpdesk FAQ ΓÇö LAINNYA

Sumber: Chat WhatsApp Kolegium Farmasi

## Q1: https://www.instagram.com/drfarbachmid

*SERTIFIKASI PEMENUHAN KOMPETENSI*

## Q2: Untuk bukti pembayaran apakah dishare disini juga

Form hanya dapat diisi 1x

## Q3: Saya juga hanya bisa input 750.000 di bukti pembayaran, tapi transfer tetap nambah 3 kode di belakang

Pembekalan : zoom

## Q4: dkhawatirkan pas mengerjakan ujiannya...soalnya dsni pln kalau kilat dan guntur besar terkdng sering mati listrik sebentr..kan otomatis..internet rumah mati..terkdng sinyal hr hp juga ilang..

ujian dulu dengan baik ≡ƒÖé baru nanti dicarikan solusi jika blm lulus

## Q5: Konfirmasi diterima oleh kolegium langsung kita dapatkan setelah selesai isi data & upload bukti bayar pak & bu

ujian dulu dengan baik ≡ƒÖé baru nanti dicarikan solusi jika blm lulus

## Q6: krm aja ke wa dl nanti di save lg

jika keluar warning "No Duplicate values...", artinya NIK tsb sudah pernah diisikan sebelumnya

## Q7: coba cek apakah ada spasi di akhir?

boleh2 aja sih klo mau uji diri ≡ƒÿâ khusus TS @49229049401588 kita uji kedua bidang, nanti saya sampaikan ke Ketua Kolegium Farmasi, bgmn? ≡ƒºÉ

## Q8: apakah bisa diidentifikasi 1 nama yang tertinggal? lalu dicoba upload 1 nama tersebut.

Kolegium Farmasi*

## Q9: 8. Universitas Ma Chung sudah melakukan pembayaran ≡ƒÖÅ≡ƒÅ╗

Kolegium Farmasi*

## Q10: Haturnuhun Prof ≡ƒÖÅ≡ƒÅ╗

Kolegium Farmasi*

## Q11: Nama : Yudhitya Enno Faradilla

Beli nanti buat persiapan live IG selanjutnya

