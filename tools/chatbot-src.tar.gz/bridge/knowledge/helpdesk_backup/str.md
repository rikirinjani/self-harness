﻿# Helpdesk ΓÇö str

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: Saya mau registrasi str

**Percakapan lengkap:**

- Pengguna: Saya mau registrasi str

---

## Kasus 2: Assalamualaikum mohon info untuk petunjuk pengurusan STRA bisa lihat dimana ya? Terima kasih≡ƒÖÅ

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Assalamualaikum mohon info untuk petunjuk pengurusan STRA bisa lihat dimana ya? Terima kasih≡ƒÖÅ
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 3: Izin prof, Medistra sudah selesai  melakukan pembayaran≡ƒÖÅ

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Izin prof, Medistra sudah selesai  melakukan pembayaran≡ƒÖÅ
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 4: Selamat Siang Kakak/ Bapak/ Ibu semoga dalam dalam lindungan Tuhan yng Maha Kuasa. Mohon izin bertanya anak saya sejak Bulan Maret mengajukan Permohonan STR Apoteker sampai sekarang belum terbit, moho

**Percakapan lengkap:**

- Pengguna: Selamat Siang Kakak/ Bapak/ Ibu semoga dalam dalam lindungan Tuhan yng Maha Kuasa. Mohon izin bertanya anak saya sejak Bulan Maret mengajukan Permohonan STR Apoteker sampai sekarang belum terbit, mohon binmbingan mungkin ada kesalahan data atau bagaimana≡ƒÖÅ≡ƒÖÅ≡ƒÖÅ

---

## Kasus 5: untuk yang sudah mempunyai akun pada semester lalu, admin prodi tidak perlu registrasi lagi, cukup login menggunakan akun sebelumnya.

**Percakapan lengkap:**

- Pengguna: 6. vidio tutorial STR,SKP & SIP
- Pengguna: untuk yang sudah mempunyai akun pada semester lalu, admin prodi tidak perlu registrasi lagi, cukup login menggunakan akun sebelumnya.
- Pengguna: Siang pak

---

## Kasus 6: Bapak/Ibu helpdesk registrasi kami buka sp jam 10 WIB nggih..jika masih ada yang terkendala atau ada yang mau ditanyakan kami tunggiu di zoom ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: Bapak/Ibu helpdesk registrasi kami buka sp jam 10 WIB nggih..jika masih ada yang terkendala atau ada yang mau ditanyakan kami tunggiu di zoom ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 7: Selamat sore kak, mohon maaf ini pengajuan stra di ktki meminta serkom yang telah ditanda tangan ketuan kolegium. Padahal sebelumnya saat pengajuan saya sudah meng-upload serkom yang telah ditanda tan

**Percakapan lengkap:**

- Pengguna: Nah kan kejadian ≡ƒÿ░
- Pengguna: Selamat sore kak, mohon maaf ini pengajuan stra di ktki meminta serkom yang telah ditanda tangan ketuan kolegium. Padahal sebelumnya saat pengajuan saya sudah meng-upload serkom yang telah ditanda tangan secara online, jadi bagaimanakah kak?

---

## Kasus 8: Selamat sore, mau konsultasi kendala pengajuan str seumur hidup.

**Percakapan lengkap:**

- Pengguna: Assalamualaikum sy bu sally apoteker mau bertanya soal jadwal ukom utk th 2026 pak/bu
- Pengguna: Selamat sore, mau konsultasi kendala pengajuan str seumur hidup.
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 9: Halo kak, selamat siang perkenalkan saya Kania Pratiwi lulusan S1 Farmasi tahun 2025. Izin bertanya kak, apakah saya bisa ikut ukom mandiri dan buat STR kak? Terimakasih ≡ƒÿè≡ƒÖÅ≡ƒÅ╗

**Respon:**

12073253761139@lid

**Percakapan lengkap:**

- Pengguna: Halo kak, selamat siang perkenalkan saya Kania Pratiwi lulusan S1 Farmasi tahun 2025. Izin bertanya kak, apakah saya bisa ikut ukom mandiri dan buat STR kak? Terimakasih ≡ƒÿè≡ƒÖÅ≡ƒÅ╗
- Kolegium: 12073253761139@lid

---

## Kasus 10: Selamat Siang. Mau bertanya anak saya pengajuan STR Apoteker Sudah sejak Bulan Maret 2026, sampai sekarang belum terbit, mohon arahan dan bimbingan mungkin ada kesalahan. Trimakasih≡ƒÖÅ≡ƒÖÅ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Mohon izin Bpk/Ibu, saya mau ikut sertifikasi pemenuhan kompetensi, kapan ya Bpk/Ibu?
- Pengguna: Selamat Siang. Mau bertanya anak saya pengajuan STR Apoteker Sudah sejak Bulan Maret 2026, sampai sekarang belum terbit, mohon arahan dan bimbingan mungkin ada kesalahan. Trimakasih≡ƒÖÅ≡ƒÖÅ≡ƒÖÅ

---

## Kasus 11: Jika Prodi mengajukan penarikan peserta yang sudah diregistrasikan pada SI Ukomednakes, dimohon Prodi mengirimkan surat dengan mencantumkan data peserta (nama,NIM), dan alasan penarikan. Pengisian dat

**Percakapan lengkap:**

- Pengguna: Jika Prodi mengajukan penarikan peserta yang sudah diregistrasikan pada SI Ukomednakes, dimohon Prodi mengirimkan surat dengan mencantumkan data peserta (nama,NIM), dan alasan penarikan. Pengisian data dan upload surat tersebut pada link form berikut : https://bit.ly/3S9rHu3 (dengan batas akhir yi Tanggal 17 Juni 2026, pukul 16.00 WIB).

---

## Kasus 12: Perspektif industri & distributor farmasi terhadap kualitas obat dan peran pemerintah dalam menjamin kualitas obat yang beredar di Indonesia

**Percakapan lengkap:**

- Pengguna: Perspektif industri & distributor farmasi terhadap kualitas obat dan peran pemerintah dalam menjamin kualitas obat yang beredar di Indonesia

---

## Kasus 13: Informasi hasil TO sudah kami share di grup admin pak. Silakan berkoordinasi dgn adminnya. Alamat email yg digunakan mengassign adalah yg diregistrasikan oleh admin prodi.

**Percakapan lengkap:**

- Pengguna: Informasi hasil TO sudah kami share di grup admin pak. Silakan berkoordinasi dgn adminnya. Alamat email yg digunakan mengassign adalah yg diregistrasikan oleh admin prodi.

---

## Kasus 14: Jangan sampai sebenarnya locus masalah  sangat dekat dan di depan mata bisa diselesaikan di internal masing-masing tapi sudah terlanjur lapor  rektor hingga high profiles ke DPR, menteri, bahkan hingg

**Percakapan lengkap:**

- Pengguna: ini dilakukan kalau terpaksa sekali
- Pengguna: Jangan sampai sebenarnya locus masalah  sangat dekat dan di depan mata bisa diselesaikan di internal masing-masing tapi sudah terlanjur lapor  rektor hingga high profiles ke DPR, menteri, bahkan hingga Kolonel Teddy. Tetapi dapat dimaklumi karena Ibu/Bapak  dan kitas sudah sibuk dengan ilmu analis kimia, farmakoterapi, namun bukan administrator data dan ahli IT  sehingga banyak dari kita cukup panik dan takikardi

---

## Kasus 15: Selamat sore kak, mohon maaf ini pengajuan stra di ktki meminta serkom yang telah ditanda tangan ketuan kolegium. Padahal sebelumnya saat pengajuan saya sudah meng-upload serkom yang telah ditanda tan

**Percakapan lengkap:**

- Pengguna: selamat pagi, izin bertanya terkait pengecekan sertifikasi kompetesi nakes bisa di cek dimana ya ?
- Pengguna: Iya pak... Sudah terjadi ≡ƒÑ▓
- Pengguna: Selamat sore kak, mohon maaf ini pengajuan stra di ktki meminta serkom yang telah ditanda tangan ketuan kolegium. Padahal sebelumnya saat pengajuan saya sudah meng-upload serkom yang telah ditanda tangan secara online, jadi bagaimanakah kak?

---

## Kasus 16: 68. Surat pemberitahuan registrasi UKOMNAS Periode 1.pdf

**Percakapan lengkap:**

- Pengguna: ibu, izin tanya, barusan KCC di ITEKES Mahardika chat dan nanya, kalau fasilitas pensil disiapkan atau mahasiswa bawa masing2 ya?
- Pengguna: 68. Surat pemberitahuan registrasi UKOMNAS Periode 1.pdf
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 17: Selamat siang min, mau tanya masalah serkom, untuk lulusan Akafarma putra indonesia lampung th 2009 saya tidak punya serkom min.. waktu proses pembuatan STR seumur hidup bagian kolom serkom diarahkan 

**Percakapan lengkap:**

- Pengguna: Bapak ibu, Reminder kembali, silahkan di assign pesertanya ke jadwal ujian supaya tidak terlewati masa pendaftaran krn di sistem akan tertutup untuk assign setelah tgl 11 (pembayaran sampai tanggal 13)
- Pengguna: Selamat siang min, mau tanya masalah serkom, untuk lulusan Akafarma putra indonesia lampung th 2009 saya tidak punya serkom min.. waktu proses pembuatan STR seumur hidup bagian kolom serkom diarahkan untuk diisi data ijazah sebagai pengganti..

---

## Kasus 18: 7. Tentang pembuatan str

**Percakapan lengkap:**

- Pengguna: 7. Tentang pembuatan str
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 19: Salam Ibu, nuwun atas pertanyaannya. Untuk STR ke konsil farmasi ibu, helpdesk konsil farmasi

**Percakapan lengkap:**

- Pengguna: bisa didownload ulang bu. Jika sudah diapprove nanti akan diberitahu bu untuk hari ini mohon menunggu.
- Pengguna: Mohon ditunggu ya pak
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Salam Ibu, nuwun atas pertanyaannya. Untuk STR ke konsil farmasi ibu, helpdesk konsil farmasi
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 20: Medistra done pak≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Halo. Selamat pagi
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Baik bu ≡ƒÖÅ≡ƒÅ╗
- Pengguna: Medistra done pak≡ƒÖÅ

---

## Kasus 21: Assalamualaikum wr.wb selamat siang bapak/ibu, ijin bertanya jika terjadi kesalahan nama profesi pada STR alumni yang harusnya TVF menjadi analis farmasi itu menghubunginya ke siapa nggih? Soalnya sud

**Percakapan lengkap:**

- Pengguna: Assalamualaikum wr.wb selamat siang bapak/ibu, ijin bertanya jika terjadi kesalahan nama profesi pada STR alumni yang harusnya TVF menjadi analis farmasi itu menghubunginya ke siapa nggih? Soalnya sudah email ke help desknya tapi tidak ada respon≡ƒÖÅ mohon bantuannya, terima kasih

---

## Kasus 22: Justru yang korupsi harus di berantas

**Percakapan lengkap:**

- Pengguna: nggih, terimakasih ibu
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Justru yang korupsi harus di berantas

---

## Kasus 23: Izin bu Ida share ≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗Assallammualaikum bapak ibu izin, kami tim adhoc osce dan osce sedang menyiapkan distribusi soal untuk ujian osce pada awal juni, berkenan untuk mengisi ajuan data osce/ospe 2026

**Percakapan lengkap:**

- Pengguna: Assalamualaikum prof  @81424191365309 .
- Pengguna: Baik pak,apakah ini upload ulang kembali untk surat pernyataan nya kah,klau di surat pernyataan antara first dan re taker SDH kami sendiri2 kan
- Pengguna: Izin bu Ida share ≡ƒÖÅ≡ƒÅ╗≡ƒÖÅ≡ƒÅ╗Assallammualaikum bapak ibu izin, kami tim adhoc osce dan osce sedang menyiapkan distribusi soal untuk ujian osce pada awal juni, berkenan untuk mengisi ajuan data osce/ospe 2026. InsyaaAllah di tanggal 25 akan dilakukan briefing PP, untuk pelaksanaan kegiatan ujian osce, insyaaAllah surat menyusul

---

## Kasus 24: izin bu, Medistra belum bisa assign, kendalanya, file yang di upload tidak muncul di konfirmasi upload bu≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Yth Bapak/Ibu
- Pengguna: izin bu, Medistra belum bisa assign, kendalanya, file yang di upload tidak muncul di konfirmasi upload bu≡ƒÖÅ

---

## Kasus 25: Topic: Helpdesk registrasi

**Percakapan lengkap:**

- Pengguna: Topic: Helpdesk registrasi

---

## Kasus 26: 68. Surat pemberitahuan registrasi UKOMNAS Periode 1.pdf

**Percakapan lengkap:**

- Pengguna: 68. Surat pemberitahuan registrasi UKOMNAS Periode 1.pdf

---

## Kasus 27: 0124_2026_Surat_Informasi_Registrasi_Juli_2026_v5_1_ (1).pdf

**Percakapan lengkap:**

- Pengguna: 0124_2026_Surat_Informasi_Registrasi_Juli_2026_v5_1_ (1).pdf
- Pengguna: mohon infonya

---

## Kasus 28: Selamat siang Pak/Bu, perkenalkan saya Tara Ade Irfantin dari PT Interskala Medika Solusindo (PT IMS) plant Batang, Jawa Tengah, industri bisang radiofarmasi.

**Percakapan lengkap:**

- Pengguna: berarti saya edit nama si SI nya saja ya pak, untuk assign jadwal tdk akan ada proses validasi pddikti lagi pak? karena kalau ada pasti tdk valid...
- Pengguna: Selamat siang Pak/Bu, perkenalkan saya Tara Ade Irfantin dari PT Interskala Medika Solusindo (PT IMS) plant Batang, Jawa Tengah, industri bisang radiofarmasi.

---

## Kasus 29: Teman2 mereka justru pengin nya komposit

**Percakapan lengkap:**

- Pengguna: unwahas sudah ya bu≡ƒÖÅ≡ƒÅ╗
- Pengguna: alhamdulillah sudah bisa bu/pak, terimakasih banyak atas bantuannya≡ƒÖÅ≡ƒÅ╗
- Pengguna: Teman2 mereka justru pengin nya komposit

---

## Kasus 30: Kalo Malaysia cuman ada nomor STR dan informasi annual certificate

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: Tadi itu yg tak tanyakan, klo kolfar menyampaikan info sejelas ini, masih dibilang gak tau2.. Emang ada yg lain??
- Pengguna: Kalo Malaysia cuman ada nomor STR dan informasi annual certificate
- Kolegium: Semoga dapat membantu ya sejawat,

---

