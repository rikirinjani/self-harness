﻿# Helpdesk ΓÇö umum

Sumber: Chat WhatsApp Kolegium Farmasi (real cases)

## Kasus 1: 6281316141670@s.whatsapp.net

**Percakapan lengkap:**

- Pengguna: 6281316141670@s.whatsapp.net

---

## Kasus 2: Selamat sore Bapak/Ibu, izin mengganggu waktunya.

**Percakapan lengkap:**

- Pengguna: Selamat sore Bapak/Ibu, izin mengganggu waktunya.

---

## Kasus 3: Min tolong dong. Kalau memang di uapload kelulusannya di akun msing" itu jam berapaya? Kata prodiku bgitu≡ƒÿ¡≡ƒÿ¡≡ƒÿ¡

**Percakapan lengkap:**

- Pengguna: Min tolong dong. Kalau memang di uapload kelulusannya di akun msing" itu jam berapaya? Kata prodiku bgitu≡ƒÿ¡≡ƒÿ¡≡ƒÿ¡

---

## Kasus 4: Nama: NURLAELI DWI WAHYUNINGRUM

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM

---

## Kasus 5: Kmrin saya sudh telfon help desk nya tapi smpe saat ini akun nya blum bisa

**Percakapan lengkap:**

- Pengguna: Kmrin saya sudh telfon help desk nya tapi smpe saat ini akun nya blum bisa
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 6: Nama: Putri Marifatunisa

**Percakapan lengkap:**

- Pengguna: 11 hari kerja
- Pengguna: Nama: Putri Marifatunisa

---

## Kasus 7: Nama: ATIEN MELLYANA KURNIASIH

**Percakapan lengkap:**

- Pengguna: Nama: ATIEN MELLYANA KURNIASIH

---

## Kasus 8: https://youtu.be/hn11Vkex0SI

**Respon:**

Semoga dapat membantu ya sejawat,

**Percakapan lengkap:**

- Pengguna: 150474347049103@lid
- Pengguna: https://youtu.be/hn11Vkex0SI
- Kolegium: Semoga dapat membantu ya sejawat,

---

## Kasus 9: Halo selamat sore

**Percakapan lengkap:**

- Kolegium: Reimburse
- Kolegium: *Chat Bot Kolegium Farmasi*
- Kolegium: *Chat Bot Kolegium Farmasi*
- Pengguna: Halo selamat sore

---

## Kasus 10: kak mohon bantuan nya

**Percakapan lengkap:**

- Pengguna: *Create a friendly greeting message that says more than hello!* ≡ƒæï
- Pengguna: kak mohon bantuan nya

---

## Kasus 11: Nama: NURLAELI DWI WAHYUNINGRUM

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM

---

## Kasus 12: Maaf post test dari yg pemateri awal sy blm mendapatkan

**Percakapan lengkap:**

- Pengguna: Assalamualaikum warahmatullahi wabarokatuh
- Pengguna: Maaf post test dari yg pemateri awal sy blm mendapatkan

---

## Kasus 13: Nama = Andi Salmah Rahmah

**Percakapan lengkap:**

- Pengguna: Selamat Siang Bapak/ibu,
- Pengguna: Nama = Andi Salmah Rahmah

---

## Kasus 14: Kalau MPPD di luar kewenangan nya kolegium

**Percakapan lengkap:**

- Pengguna: Kalau MPPD di luar kewenangan nya kolegium

---

## Kasus 15: Selamat pagi, Bapak/Ibu. Salam sehat selalu.

**Percakapan lengkap:**

- Pengguna: Halo selamat sore, saya Laura mau tanya soal info UKOM bisa?
- Pengguna: Selamat siang..
- Pengguna: Selamat pagi, Bapak/Ibu. Salam sehat selalu.
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 16: 150474347049103@lid

**Percakapan lengkap:**

- Pengguna: 150474347049103@lid

---

## Kasus 17: AssalamuΓÇÖalaikum warahmatullahi wabarakatuh.

**Percakapan lengkap:**

- Pengguna: bu ida, mohon maaf izin bertanya lagi, apakah untuk nama2 yang diajukan pindah lokasi kota TUK nya harus diubah juga pada bagian Kab./Kota TUK di SI-Ukomednakes nya?
- Pengguna: AssalamuΓÇÖalaikum warahmatullahi wabarakatuh.

---

## Kasus 18: Ada yang punya tripod?

**Percakapan lengkap:**

- Pengguna: Ada yang punya tripod?

---

## Kasus 19: 86552902418556@lid

**Percakapan lengkap:**

- Pengguna: 86552902418556@lid

---

## Kasus 20: Nama: NURLAELI DWI WAHYUNINGRUM

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM

---

## Kasus 21: HalooooΓÇª apakah no ini ada petugasnya?

**Percakapan lengkap:**

- Pengguna: HalooooΓÇª apakah no ini ada petugasnya?

---

## Kasus 22: Assalamualaikum bpk ibu  ijin utk dapat  memasukkan ke grup  Ka.Prodi D3 Farmasi yg baru dari Institut Kesehatan Helvetia dgn ibu apt. Adek Chan, S.Si.,M.Si.≡ƒÖÅ.Berikut no bu adek chan : +62 813-7524-25

**Percakapan lengkap:**

- Pengguna: Assalamualaikum bpk ibu  ijin utk dapat  memasukkan ke grup  Ka.Prodi D3 Farmasi yg baru dari Institut Kesehatan Helvetia dgn ibu apt. Adek Chan, S.Si.,M.Si.≡ƒÖÅ.Berikut no bu adek chan : +62 813-7524-2519
- Kolegium: *Chat Bot Kolegium Farmasi*

---

## Kasus 23: Nama: NURLAELI DWI WAHYUNINGRUM

**Percakapan lengkap:**

- Pengguna: Nama: NURLAELI DWI WAHYUNINGRUM

---

## Kasus 24: Selamat pagi bapak/ibu

**Percakapan lengkap:**

- Pengguna: Selamat pagi bapak/ibu

---

## Kasus 25: Makasih ka. Atas sharingnya ≡ƒÖÅ

**Percakapan lengkap:**

- Pengguna: Makasih ka. Atas sharingnya ≡ƒÖÅ

---

## Kasus 26: soalnya tempat krja jg sdah mnta trus

**Respon:**

≡ƒôó *CALL FOR RESEARCHER*

**Percakapan lengkap:**

- Kolegium: ≡ƒôó *CALL FOR RESEARCHER*
- Pengguna: soalnya tempat krja jg sdah mnta trus

---

## Kasus 27: Nama: ATIEN MELLYANA KURNIASIH

**Percakapan lengkap:**

- Pengguna: Nama: ATIEN MELLYANA KURNIASIH

---

## Kasus 28: baik bu terimakasih, mohon maaf saya terlewat ≡ƒÖÅ≡ƒÅ╗

**Percakapan lengkap:**

- Pengguna: baik bu terimakasih, mohon maaf saya terlewat ≡ƒÖÅ≡ƒÅ╗

---

## Kasus 29: Selamat pagi kaaaa

**Percakapan lengkap:**

- Pengguna: Selamat pagi kaaaa

---

## Kasus 30: Tripod aku gak tahu hilang ke mana ≡ƒÿó

**Percakapan lengkap:**

- Pengguna: Tripod aku gak tahu hilang ke mana ≡ƒÿó

---

