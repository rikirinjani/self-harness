

Q: Hape rusak, file SERKOM hilang. Bisa download ulang?
A: 
- Buka laptop lain, login ke akun yang sama
- Atau dari HP: Chrome -> cari portal Kolegium Farmasi -> cek menu sertifikat
- Setelah berhasil download, simpan ke email sebagai cadangan

Q: Lupa akun SERKOM, lupa username password?
A: 
- Jika lupa password aplikasi registrasi STR (kki.go.id/registrasi), klik Lupa Password pada halaman login dan ikuti instruksi via email terdaftar.
- Jika lupa akun portal SERKOM, siapkan data: nama lengkap, NIK, dan email. Akan diteruskan ke bagian terkait.