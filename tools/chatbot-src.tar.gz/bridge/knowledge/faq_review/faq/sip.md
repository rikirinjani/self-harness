

Q: Sudah lama tidak praktik, sekarang ingin buka apotek dan jadi APJ?
A: Urutan proses pengurusan:

1. STR Seumur Hidup - ajukan di kki.go.id/registrasi (STR adalah kewenangan KKI).
2. Sertifikasi Pemenuhan Kompetensi (ujian ulang) karena >5 tahun tidak praktik - diselenggarakan oleh Kolegium Farmasi.
3. Ajukan SIP ke MPP Digital Nasional atau Dinas Perizinan/PTSP setempat dengan syarat STR, tempat praktik, dan bukti pemenuhan kompetensi.

Untuk izin operasional apotek (Surat Izin Apotek/SIA), hubungi Dinas Kesehatan atau DPMPTSP setempat.