# FAQ — KKI

Sumber: Chat WhatsApp Kolegium Farmasi

Q: Apakah KKI buka? Perlu buat perjanjian?
A: Informasi jam operasional dan prosedur tidak tercantum di dokumen. Silakan hubungi:
- Telepon: 1500-567 Ext. 3
- Email: helpdesk.ditjennakes@kemkes.go.id
- Alamat: Jl. Hang Jebat Raya Blok F 3, Kebayoran Baru, Jakarta Selatan

Q: NIK sudah benar tapi ditolak saat daftar STR? Padahal belum pernah daftar.
A: Mohon maaf, untuk pengurusan STR merupakan kewenangan Konsil Kesehatan Indonesia (KKI). NIK bermasalah juga melibatkan Dinas Kependudukan (Dukcapil). Silakan hubungi KKI melalui kki.go.id / helpdesk.ditjennakes@kemkes.go.id / 1500-567 Ext. 3.

Q: Petunjuk pengurusan STRA?
A: STRA merupakan kewenangan KKI. Silakan akses kki.go.id/registrasi atau hubungi helpdesk.ditjennakes@kemkes.go.id / 1500-567 Ext. 3.

Q: KTKI minta SERKOM ttd ketua Kolegium, padahal sudah upload SERKOM ttd online?
A: Ini kendala di sistem KKI. Silakan hubungi helpdesk KKI di helpdesk.ditjennakes@kemkes.go.id / 1500-567 Ext. 3.
