PENJAGAAN KOMPETENSI &
SATUAN KREDIT PROFESI 
(SKP) | KOLEGIUM FARMASI
2025

DISCLAIMER & TRACK CHANGES | Informasi dalam “Penjagaan Kompetensi & Satuan Kredit Profesi (SKP)” disusun oleh Kolegium Farmasi, ditujukan untuk lulusan baru Apoteker dan Tenaga Vokasi Farmasi. Substansi berdasarkan pada regulasi sebagaimana dicantumkan pada halaman 3. Apabila terdapat perbedaan informasi dengan regulasi, maka yang digunakan adalah peraturan perundang-undangan/ regulasi eksisting. Sejawat diminta membaca secara komprehensif dasar regulasi yang digunakan. Bila dikemudian hari terdapat perkembangan regulasi, maka informasi disini akan disesuaikan. | Dibuat		: 9 Agustus 2025
Revisi terakhir 	: 12 September 2025
Versi		: Ke-2

UU No. 17 tahun 2023
tentang
Kesehatan | PP No. 28 tahun 2024
tentang
Peraturan Pelaksanaan 
UU 17/2023 tentang Kesehatan | KMK No. HK.01.07/MENKES/1561/2024
tentang
Pedoman Pengelolaan Pemenuhan Kecukupan SKP bagi Tenaga Medis dan Tenaga Kesehatan | Ditetapkan 20 September 2024 | Ditetapkan 8 Agustus 2023 | Ditetapkan 26 Juli 2024 | DASAR REGULASI | unduh disini | KepDirjend SDMK No. HK.02.02/F/20249/2025
Tentang
SKP Program Penanggulangan TBC dan PKG | Ditetapkan 8 Mei 2025

Menteri Kesehatan | KONSIL – KOLEGIUM - MDP | PRESIDEN | Tim AdHoc 
Pemeriksa Provinsi

Pendidikan & Pelatihan | Perizinan & Pembinaan | Menyusun standar kompetensi;
Menyusuan standar kurikulum pelatihan. | Melaksanakan penegakan disiplin profesi tenaga medis dan tenaga  kesehatan berdasarkan ketentuan penegakan disiplin yang ditetapkan oleh Menteri | Menerbitkan Sertifikat Kompetensi | Peran | Wewe-nang | Melakukan registrasi tenaga medis dan tenaga kesehatan;
Melakukan pembinaan teknis keprofesian. | Menerbitkan, menonaktifkan, dan mencabut STR | Penegakan Disiplin | Dalam menjalankan tugas dan fungsinya Konsil, Kolegium, dan MDP bersifat independen | KONSIL – KOLEGIUM – MDP (2) | Dasar | UU 17/2023 Pasal 272
PP 28/2024 Pasal 704 - 711 | UU 17/2023 Pasal 268 - 271
PP 28/2024 Pasal 694 - 703 | UU 17/2023 Pasal 304
PP 28/2024 Pasal 712 - 718

STR(Surat Tanda Registrasi) | SKP 
(Satuan Kredit Profesi) | SIP
(Surat Izin Praktik) | Ijazah dan/atau sertifikat profesi
Sertifikat Kompetensi | Kecukupan SKP dari 3 Ranah:
Pembelajaran 
Profesionalisme/ Praktik
Pengabdian | STR
Tempat Praktik
Kecukupan SKP 
        (khusus perpanjangan SIP) | Konsil atas nama Menkes | Kemenkes | Pelayanan Terpadu Satu Pintu (PTSP) Kabupaten/Kota | Dokumen | Validator | Penerbit | Kolegium | Fasyankes dan/atau Dinas Kesehatan | SKP merupakan bentuk penjagaan kompetensi setelah lulus pendidikan (lifelong learning) | PENERBITAN STR DAN SIP | Fungsi | Bukti telah terdaftar (pengakuan negara)
Syarat wajib untuk praktik | Bentuk penjagaan kompetensi
Syarat perpanjangan SIP | Bukti legal izin berpraktik sesuai profesi,  kompetensi & kewenangan | Konsil

KONSEP PEMENUHAN SKP | Dokumen Anda (saat ini):
Ijazah/ Sertifikat Profesi
Sertifikat Kompetensi (SERKOM)
Surat Tanda Registrasi (STR)a | Dokumen Anda (nanti):
STR
Surat Izin Praktik (SIP)b
Kecukupan SKP (SKP Platform)c
Sertifikasi Pemenuhan Kompetensid | Keterangan:
a STR berlaku seumur hidup, untuk pembuatan STR pertama kali dikenakan biaya. Registrasi pertama melalui kki.go.id/registrasi;
b SIP = Surat Izin Praktik, berlaku maksimal 5 (lima) tahun, melalui MPP Digital Nasional atau Dinas Perizinan/PTSP atau Dinas Kesehatan;
c SKP dikumpulkan dalam periode berpraktik (5 tahun), untuk digunakan sebagai perpanjangan periode berikutnya (5 tahun selanjutnya);
d Sertifikasi Pemenuhan Kompetensi ≈ Ujian Kompetensi ulang, perlu dilakukan jika dalam waktu 5 tahun tidak berpraktik | 2025 | 2030

KETENTUAN PENGAJUAN SIP | Perpanjangan | Pertama kali | SIP 2 atau 3 | STR
Tempat Praktik | 5 tahun | Lulusan  5 thn dengan STR lama yg masih berlaku/STR Seumur Hidup | Tidak pernah praktik >5 thn sejak sebelum UU 17/2023 | Dengan:
STR lama yg masih berlaku --> Maka Masa berlaku SIP = masa berlaku STR
STR Seumur Hidup = 5 tahun | 1




2 | STR
Tempat Praktik
Bukti pemenuhan kompetensi | STR
Tempat Praktik
Bukti Kecukupan SKP | 5 tahun | STR
SIP ke 1 dan/atau SIP ke 2
Tempat praktik | STR lama yg masih berlaku/STR Seumur Hidup | Dengan:
STR lama yg masih berlaku --> Maka Masa berlaku SIP = masa berlaku STR
STR Seumur Hidup --> mengikuti masa berlaku SIP 1 | Persyaratan | Masa Berlaku SIP | STR lama yg masih berlaku/STR Seumur Hidup

Pengabdian | RANAH DAN PROPORSI PEMENUHAN SKP | Ranah | Proporsi (%) 1 | Apoteker & 
Apt. Spesialis | Tenaga Vokasi Farmasi | Umum | Khusus 3 | Pembelajaran 2 | Profesi | (praktik/ pelayanan) | 1 Sisa presentase (15%) dapat dipenuhi dari ranah manapun
2 Wajib memenuhi 20% SKP Pembelajaran/tahun
3 Kondisi khusus ditetapkan oleh Menteri, misalnya DTPK (daerah tertinggal, terluar, kepulauan) | min. 100 SKP | min. 50 SKP

SKP PLATFORM
Pengumpulan SKP 3 Ranah
Pembelajaran
Profesionalisme
Pengabdian | SatuSehat SDMK
Perizinan Praktik (SIP) | Plataran Sehat
SKP PEMBELAJARAN | RME SatuSehat a
SKP PROFESIONALISME | SKP PENGABDIAN | EKOSISTEM SATUSEHAT | EKOSISTEM SATUSEHAT | (praktik/ pelayanan) | a Selama proses integrasi RM Fasyankes ke RME SatuSehat, SKP Profesionalisme bidang pelayanan
    (Apotek, Puskesmas, Klinik, RS) dibuat dalam bentuk logbook

KETENTUAN PENGAJUAN SIP | Seminar/ Webinar
Workshop
Simposium/ Konferensi
Pembelajaran Mandiri
Pelatihan | Jenis Kegiatan | Cara Perolehan | Pengabdian | (praktik/ pelayanan) | Mengikuti kegiatan melalui | Asuhan 
Non-asuhan 
Administratif 
Manajerial
Riset & Publikasi
dlsb | Data RME  terintegrasi SatuSehat dan/ atau Melaporkan Logbook melalui | Melaporkan Logbook melalui | Pengobatan massal (kolaboratif)
Penyuluhan kesehatan
Tim Khusus (relawan bencana, tim nakes haji)
Edukasi media sosial
dlsb

CONTOH JENIS KEGIATAN PROFESIONALISME (1) | Mendokumentasikan kegiatan-kegiatan RnD, Produksi, QC, QA,K3, Halal Assurance, pelaporan eksternal, dlsb | Industri | Distribusi | Pelayanan | Mendokumentasikan kegiatan-kegiatan penerimaan, pendistribusian, pemusnahan,K3, pelaporan eksternal, dlsb | Mendokumentasikan kegiatan-kegiatan pengadaan, penerimaan,penyimpanan penyerahan, pemusnahan, pelaporan eksternal, dlsb | Pelayanan langsung kepada pasien, seperti pelayanan resep & non-resep, KIE, PIO, home care, visite, PTO, MESO/ PV, dlsb | Pelayanan tidak langsung kepada pasien, seperti penyiapan resep, iv admixture, peracikan, handling sitostatika, dlsb | Kegiatan keprofesian terkait distribusi, seperti membuat perencanaan, melakukan pengadaan, menjamin mutu selama penyimpanan, mendistribusikan, dlsb | Kegiatan keprofesian terkait manufakturing, seperti melakukan RnD, Produksi, QC, QA,K3, Halal Assurance, pelaporan eksternal, dlsb | Bidang Industri & Distribusi tidak melakukan pelayanan langsung pada pasien

Video Tutorial dan FAQ | youtube.com/@KonsilKesehatanIndonesia | buka disini

Rekomendasi Playlist | buka disini | youtube.com/@Kolegium_Farmasi

Frequently asked questions (FAQ) | unduh disini | s.kemkes.go.id/UpdateInformasiSKPApotekerdanTVF

HELPDESK STR – SKP – SIP - MPPD | helpdesk.ditjennakes@kemkes.go.id | Jl. Hang Jebat Raya Blok F 3, 
Kebayoran Baru, Jakarta Selatan | Sampaikan kendala melalui email helpdesk dengan melampirkan data diri dan data pendukung secara lengkap sebagai berikut:

Nama lengkap
NIK & Foto KTP
STR & SERKOM (jika ada)
Email
Rincian kendala (narasi)
Bukti kendala (screenshot)

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi