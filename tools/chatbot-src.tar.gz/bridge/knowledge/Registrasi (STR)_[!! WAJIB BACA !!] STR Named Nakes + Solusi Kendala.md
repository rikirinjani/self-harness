<i J
REFRESHMENT

Pengaturan Registrasi Tenaga Medis dan Tenaga Kesehatane? Kemenkes
pasca Undang-Undang Nomor 17 Tahun 2023 tentang Kesehatan

Surat Tanda Registrasi

1. Surat Tanda Registrasi (STR) adalah bukti tertulis yang diberikan kepada Tenaga
Medis dan Tenaga Kesehatan yang telah diregistrasi.

STR tidak berlaku apabila:

2. Tenaga Medis dan Tenaga Kesehatan yang akan menjalankan praktik wajib

memiliki STR Yang bersangkutan

3. STR diterbitkan oleh Konsil atas nama Menteri. meninggal dunia;
Dinonaktifkan atau dicabu
4. Permohonan STR diajukan secara daring (online) melalui sistem yang terintegrasi oleh Konsileinouene

dengan Sistem Informasi Kesehatan Nasional. Menteri; atau
; Dicabut berdasarkan
5. STR WNI berlaku seumur hidup. putusan pengadilan yang

6. Pengajuan STR harus memenuhi persyaratan paling sedikit terdiri atas: telah berkekuatan hukum
tetap.
QO) ijazah dan/atau Sertifikat Profesi, dan
QO) Sertifikat Kompetensi

7. Dalam hal terdapat perubahan kualifikasi kompetensi dan/atau beralih profesi,

Tenaga Kesehatan dapat mengagjukan perubahan data STR.

Mekanisme Pengajuan STR secara online bagi
tenaga medis dan tenaga kesehatan

https://satusehat.kemkes.go.id/sdmk

Pembaharuan STR lama
menjadi STR Seumur Hidup SATUSEHAT SDMK

rtal untuk SOMK di Indonesia yang terpusat dan terintegrasi
Perbarui data diri dan profesional Anda, serta akses berbagal layanan dalam satu akun.

Dengan
l. STR dalarn masa — kki.go.id/registrasi melengkapi
endidikan (PPDS/ ) : a dokumen yang

2. Peningkatan > x .
Kompetensi/kualifikasi eb ttn tepsa crn — dipersyaratkan

tambahan/naik level

3. STR pertama kali
(termasuk STR internsip) : APLIKASI REGISTRASI ONLINE
4. Adaptasi bagi WN! KONSIL KESEHATAN INDONESIA

Lulusan Luar Negeri
5. Warga Negara Asing

PORTAL UINTUK TENAGA MEDES DAN TENAGA KESEHATAN Ot INDONESIA

OuFTA SEAR

Implementasi UU 17/2023, Kemenkes telah mempermudah
proses Registrasi tenaga medis & tenaga kesehatan

Registrasi Sua’

1.663.474 STR Seumur Hidup

Telah diterbitkan bagi Tenaga Medis dan Tenaga Kesehatan 75Z%odari Total 2.226.013 Tenaga Medis
dan Tenaga Kesehatan yang teregistrasi aktif)

APLIKASI REGISTRASI ONLINE
KONSIL KESEHATAN INDONESIA SATUSEHAT SDMK

PORTAL ONTUK TENAGA MEDIS DAM TENAGA KESEMATAN DI INDONESIA Portal untuk SOME & Indonesis yang terpusat dan terintog’ asi
Perbarvi data dirt Gan profesional Anda, sorta akses berbaga! layenan calam satu akun

od =

STR berlaku menjadi Seumur Hidup dengan
melalui Aplikasi KKI dan SATUSEHATSDMK

Mekanisme Penerbitan STR Bagi Tenaga Medis dan Tenaga Kesehatan
melalui

Ome) Ofna] e
NAMED/NAKES
= Register / Log in SIR
kkigo.id/registrasi BERBAYAR?

==<p * Melengkapi / Unggah

H Dokumen Tidak Lengkap Lengkap

r | (perbaikan) (Diterima)
i] MELENGKAPT

i]
i]
i]
i]
i]
i]

6
D rprovar| TTE
= Terbit STR

PEMBAYARAN
KODE BILLING
Tidak -
Expired.

[MDITOLAK
| BY SISTEM

* Draft PDF e-STR
= Tanggal
Penetapan SIR

--------- Es
STR TIDAK
BERBAYAR*)
9) STR Berbayar. : STR Pertama Kali/Baru, STR Internsip, STR Adaptasi WNI LLN 1x, STR WNA

SIR Tidak Berbayar: STR Pembaharuan, STR Selesai Internsip, STR Pendidikan, STR Naik/Turun Level, STR Alih Profesi

9 Ditolak : Oleh validator bagi STR Nakes dengan kondisi dokumen yang diusulkan diragukan keabsahannya/palsu, salah pilih jenis STR, salah pilih
tahun lulusan, all

\ Pengajuan STR bagi lulusan Pendidikan

Contoh STR Tenaga Medis dan Tenaga Kesehatan

bd

¥

Surat Tanda Registrasi Surat Tanda Registrasi Surat Tanda Registrasi Surat Tanda Registrasi
Doreen ry Kare rerpetshary Cergas 0 Karn crerpatatcar Cer gar 9 Kam meyer Cer ae ey Caeser
XXXXXXXXXAX XXXNXXXNAN XXXXNNXNXX
scenes oped CAESAR peat Tet res sa wont ERE SEA ost re wane One Eo
rereurgas baths rice soorepengas Bilis sages rere meas te cormene becithan wees
DOKTER DOKTER SPESIALIS ANAK PERAWAT VORASI LEVEL 5 ccumamn a
bn ee nb toon trom nape ged 2b e019 : a
rete wrest sta i ri ara Cor Mami Pee po ra 3 et a pa ga
a sheets = ae
an tte Casha an arte tern Sige tores tone rene
ct ae eT nae = eg
’ Ae ps Md
beishsenectaiaia dg. Anes Aewnye, MIM

Surat Tanda Registrasi
Gergen in Kars nerwatanan
~ NXXNXXNXXXN
Gergen norsr wegaittae DROOL) Hoe 79%
Hoes amr ce mereeye tsi KO
Surat Tanda RegistrasiKualifikasi Tambahan NERS SPESIALIS KEPERAWATAN ANAK

Dengan ing Karr rmerryotakan ‘Lates dar) Poets Camentam latarta | pate tangaal 26 Apet 2019

dakarta, Tangge! Qaden Taos
erty Sevens Hone

engan Hamer FeghIRS MHBECOZIIGEIESE

rwergpurya abtihan saa - | +,
DOKTER SPESIALISOBSTETRI DAN GINEKOLOG!
Maillon: Werkotier : 5
Sishopesints Fertibtan Erateerivedingi Reppresatess SOs Aes Anny,
Luka dari Krdeghum Otutets dan Ganatolog! ndoneus pada twngga 20 Maret 2003 Sc a
‘Butan Tae

Bevake Seurrar Hedup

Penulisan Kualifikasi Kompetensi
da STR Nakes ditambahkan level/ienjang

a
Kualfikasi padalKKNIsesvai perpres 6/2012

atas nama Menteri Kesehatan

Saat ini STR ditandatangani

HAL-HAL YANG PERLU DIPERHATIKAN SAAT REGISTRASI BARU

\jazah /sertifikat profesi Sertifikat Kompetensi

Kendala TERTINGGI Named/Nakes terkait Registrasi
dari email, call center,layanan tatap muka dll.

6523

4424 4200

Kendala

Perubahan Alamat Email Kendala Profil & Penggantian Data

Sumber : Sekretariat Direktorat Jenderal SDM kesehatan, Periode 1-31 Januari 202

Solusi : Step by Step Penggantian e-mail Nakes Mandiri

3. Klik Menu Edit Profil

- Login di laman _ 2. Pilih dan klik tenaga kesehatan
https://kki.go.id/registrasi

Registrasi
Aplikasi Registrasi Online | @ Tenaga Kesehatan
KONSIL KESEHATAN INDONESIA i Pendaftaran Untuk Tenaga Kesehatan
i (Tenaga Keperawatan, Tenaga Kebidanan,

Tenaga Farmasi, Tenaga Gizi, Tenaga
Kesehatan Lingkungan, Tenaga Kesehatan
Masyarakat, Tenaga Keteknisian Medis,
Tenaga Keterapian Fisik, Teknik Biomedika,
Psikologi Klinis, Tenaga Kesehatan
Tradisional)

Untuk tenaga kesehatan yang bisa
mengajukan STR hanya vokasi / profesi

Nakes melalui

Named &

Silahkan menghubungi email
helpdesk.ditjennakes@kemkes.
go.id dengan dengan format diri:
Nama Lengkap :

NIK:

Profesi:

Alamat email pengganti yang
aktif:

menyertakan scan KTP dan
swafoto dengan KTP, surat
permohonan bermaterai

Contoh Surat Permohonan

SURAT PERMOHONAN PERUBAMAN ALAMAT SURAT ELEKTRONIK (ernest), .

‘Seva yang bertandatangan & bamat or

ff

No? nat
No STR

Erotten |

Qengan c mengawtan permohonan gendtaben samat sarat elekinank (ema
Gkareratar STP MeNjEmN bamwa samat ermal yang digenahan tame
dengan aamat emael pribad yang Squeakan \akhf)

Agata & Nemudan ben tertuil ademe cotedete yong tidak bene dalam
PEIMONGNAN (Ch Maka Maye Dervedia mempertanepeneiewebhan yesue GOrNWRT
penandang undangan are beriats

Oemien awrat permcforan if) saya Quit uctisk dapat Operpnekan setegnmana

comerrry,

(17 Gan Mama Lenghag) _

Silahkan menghubungi email
helpdesk.ditjennakes@kemkes.go.id dengan
dengan format diri:

Nama Lengkap :

NIK

Profesi:

Alamat email terdaftar

Rincian Kendala

menyertakan foto KTP, STR lama, ijazah, sertifikat
kompetensi dan surat pernyataan bermaterai

Solusi : Step by Step Lengkapi Data STR lama Nakes

2. Masukkan Nomor STR
erase

Kendala
®&) °
Validasi STR belum berhasil

Terdapat data yang tidak lengkap di Konsil Kesehatan
indonesia. Berikut data Anda yang belum lengkap:

1. Pilih Menu Lengkapi Data STR Lama

No. |Jazah, Tanggal Lulus, Nama Perguruan Tinggi, No.
Sertifikat Kompetensi.

Masukan 7 digit terakhir nomor STR Anda.
Untuk profesi Apoteker masukan nomor str apoteker lama dengan
lengkap

Silakan lengkapi data Anda di Konsil Kesenatan Indonesia

3. Masukkan data Saudara dan submit
Pemohon yang terkendala Data STR lama Anda belum lengkap —— mnie
data belum lengkap dapat
. Data STR Lama
melengkapi data melalui web Profesi Kompetensi
' | O fe} i n Masukan data anda sesual data yang tertera pada STR lama
menggunakan akun yang | pooooDB000N00NC Homer Sertiat Kempston
sudah ada
maksimal 3 hari kerja “
7 7 File Foto
kemudian masuk kembali ke veo tane snmp Seaman Note choen
aplikasi SatuSehat SDMK untuk Pas foto formal terbaru ukuran 4x6 menghadap kedepan, berlatar belakang warna merah, dan waiah

terihat jelas tanpa penutup wajah (format file jpeg dengan ukuran maksimal 200 KB)

melanjutkan proses

Jenis Kelamin
Subevt
Peremouan

Solusi : Step by Step Perbaikan Data STR Nakes

1. Pilih Menu Pengajuan Cetak Ulang STR 3 Masukkan Nomor STR

Perbaikan Data STR Expired

‘STR Anda (")

Untuk pemohon yang sudah memiliki STR seumur hidup isikan nomor STR seumur hidup secara
lengkap.
Untuk profesi selain apoteker dan tenaga vokasi farmasi isikan 7 digit terakhir nomor STR Anda.

Pengajuan Cetak Ulang STR

Untuk profesi apoteker dengan nomor STRA lama masukan nomor str secara lengkap (Contoh
20000008/S TRA 000/000) 000000)

Untuk profesi apoteker dengan nomor STR baru dan tenaga vokasi kefarmasian isikan 8 digit
terakhir nomor STR.

Perbaikan Data STR Aktif Perbaikan Data STR Expired

- 20 Januari 1988
co)

“Bagaimana jika saya sudah memiliki akun di KTKI,
G) apakah perlu membuat akun di aplikasi
kki.kemkes.go.id/registrasi?”

CA) Nakes tidak perlu membuat akun kembali, cukup
login dengan akun yang sudah dimiliki sebelumnya

“Saya lupa password saya, bagdimana cara
mengaturnya ulang 2”

Klik ada halaman login dan ikuti
instruksi Untuk . Pengajuan lupa

password menggunakan email yang telah
didaftarkan. Pastikan memiliki akses ke alamat
email tersebut.

“Bagaimana jika saya sebelumnya belum memiliki akun
@® di aplikasi KK] ataupun KTKI 2”

Named/Nakes dapat melakukan pendafiaran akun
pada aplikasi registrasi online Konsil Kesehatan Indonesia
dengan memilih ilahkan

upload KTP kemudian isikan data email, no handphone

“Apakah saya perlu verifikasi akun setelah

© mendaftar 2

Ya, setelah menyelesaikan pendaftaran, Anda
akan menerima email dari KKI. Silakan buka email

tersebut dan klik pada link verifikasi yan
© disecickan untuk mengakfifkan dan memvetifikasi

Anda.

y
>

“Bagaimana cara mengajukan registrasi STR setelah
©) login pada aplikasi kki.kemkes.go.id/registrasi¢?”

@© mendaftar 2
Setelah Anda berhasil login silahkan pilih Tenaga Medis

Ya, setelah menyelesaikan pendaftaran, Anda untuk Named dan lanjutkan pengajyan dengan memilih

akan menerima email dari KKI. Silakan buka email TA ) jenis pengajuan yang dibutuhkan.
Untuk Nakes silahkan pilih Tenaga Kesehatan dan

tersebut dan klik pada link verifikasi yan ae .
disediakan Untuk mengaktifkan dan memverifikasi lanjutkan pengajuan dengan memiilih jenis pengajuan

“Apakah saya perlu verifikasi akun setelah

Anda yang dibutuhkan
“Apakah akun yang saya miliki di satusehat SDMK, : .
bisa digunakan untuk login di aplikasi Bagaimana jika saya tidak bisa lengkapi data STR lama,
kki.kKemkes.go.id/registrasi? muncul notifikasi nama di akun pemohon dengan nama

di STR lama tidak sama?”

@ Named/Nakes bisa melakukan pendaftaran akun Pastikan data akun dan data STR ss
os -. wel yang Anda miliki harus
pada aplikasi KKI jika belum memiliki akun. untuk menghindari penyalahgunaan data orang

lain.

y
>

“Bagaimana jika
yang belum memiliki STR yang diterbitkan oleh Konsil?”

Silahkan melakukan pengajuan registrasi STR pada
© cpio: kkikemkes.goid/regisras:

Login kemudian pilih menu registrasi baru

“Bagaimana jika STR sudah terbit, namun tidak
@ STR yang diunduh pada Satusehat
SDMK 2”

Silahkan menghubungi email
dengan dengan

format diri:

Q Nama Lengkap:

QO NIK

Q Profesi:

Q Alamat email terdaftar

Q Rincian Kendala

menyertakan foto KTP, ljazah dan screenshoot kendala

“Bagaimana jika tombol unduh STR di satusehat SDMK

belum muncul?”

Silahkan pad kembali dan Spend Fg
Atau data pengajvan STR Anda masih menunggu proses
Tanda Tangan Elektronik oleh Konsil Kesehatan Indonesia

“Data STR saya yang telah terbit terdapat data yang
© tidak sesuai, bagaimana cara memperbaikinya?”

Silahkan lakukan pengajuan cetak vlang perbaikan
data STR pada aplikasi kki.

Login aplikasi kemudian pilih menu cetak ulang

perbaikan data SIR, isikan data yang benar.

@ — jika saat sit



SANKS!I PEMALSUAN
IJAZAH, SERKOM

Undang-Undang Nomor 1 Tahun 2023 tentang Kitab
Undang-Undang Hukum Pidana

a. Pasal 272 ayat (1) : “Setiap Orang yang memalsukan
atau membuat palsu ijazah atau sertifikat kompetensi
dan dokumen yang menyertainya, dipidana dengan
pidana penjara paling lama 6 (enam) tahun atau
pidana denda paling banyak kategori V".

b. Pasal 272 ayat (2), “Setiap Orang yang menggunakan
ijazah, sertifikat kompetensi, gelar akademik, profesi, Pasal 441 Undang-Undang No 17 Tahun 2023 tentang

atau vokasi palsu, dipidana dengan pidana penjara Kesehatan
“ Setiap Orang yang menggunakan identitas berupa gelar

ling I 6 tah t id dend
pa “ng ama (enam) ia On ata pidana denda atau bentuk lain yang menimbulkan kesan bagi masyarakat
paling banyak kategori V”. .
eas . yang bersangkutan adalah Tenaga Medis atau Tenaga
c. Pasal 272 ayat (3), “Setiap Orang yang mener bitkan Kesehatan yang telah memiliki STR dan/ atau SIP sebagaimana
dan/ atau memberikan ijazah, sertifikat kompetensi, dimaksud dalam Pasa] 312 huruf a dipidana dengan pidana
gelar akademik, profesi, atau vokasi palsu dipidana penjara paling lama 5 {lima) tahun atau pidana denda paling

dengan pidana penjara paling lama 10 (sepuluh) banyak Rp500.000.000,00 (lima ratus juta rupiah).”
tahun atau pidana denda paling banyak kategori V

<f: Kemenkes 17

APABILA MENGALAMI KENDALA,
SILAHKAN MENGHUBUNGI HELPDESK:

Q Helpdesk Ditjen Nakes
1500-567 Ext. 3

bX) helodesk.ditilennakes@kemkes.go.id

Atau dapat mengakses FaQ di:
faq.kemkes.go.id

Video tutorial STR dapat diakses di:

- Video Tutorial
STR TENAGA MEDIS &
TENAGA KESEHATAN