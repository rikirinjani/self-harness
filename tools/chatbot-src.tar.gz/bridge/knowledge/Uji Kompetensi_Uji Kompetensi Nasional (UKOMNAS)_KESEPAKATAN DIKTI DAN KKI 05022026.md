Kesepakatan Bersama
Kementerian Pendidikan Tinggi, Sains, dan Teknologi dan
Konsil Kesehatan Indonesia
dalam Pelaksanaan Uji Kompetensi Nasional
Tenaga Medis dan Tenaga Kesehatan

1. Mckanisme Pengelolaan pembiayaan Uji Kompetensi dilaksanakan melalui akun bersama
(Tim Adhoo) penwakilan kolegium dan penyclenggara Pendidikan, yang dikelola oleh
kolegium dan dipantau oleh kedua_belah pihak. Pengelolaan dilaksanakan_ secara
transparan, akuntabel, dan sesuai dengan ketcntuan peraturan perundang-undangan yang
berlaku. Dilaksanakan Audit keuangan secara berkala oleh lembaga audit yang berwenang.

9, Sistem Informasi yang akan digunakan adalah Sistem Informasi Uji Kompetensi Nasional
Tenaga Medis dan Tenaga Kesehatan, yang disingkat SIL-UKOMEDNAKES. Sistem ini
terintegrasi dengan pangkalan data pendidikan tinggi dan memanfaatkan praktik baik sistem
Uji _Kompetensi terdahulu. Pengawasan terhadap pengelolaan SI-UKOMEDNAKES
dilakukan bersama oleh KKI dan Kemdiktisaintek.

3. Pengadaan soal Uji Kompetensi dapat dilakukan oleh institusi pendidikan, kolegium, dan
para ahli, Selanjutnya dilakukan verifikasi dan review oleh panel ahli menggunakan SI-
UKOMEDNAKES. Penetapan akhir soal uji kompetensi dilakukan secara bersama oleh
tim adhoc yang dipimpin oleh kolegium.

4. Kesepakatan ini harus menjadi bagian dari petunjuk teknis uji kompetensi nasional yang

disusun bersama oleh tim adhoc (Unsur Kolegium dan Penyelenggara Pendidikan).

Jakarta, 5 Februari 2026

Ketua Konsil Keschatan Indonesia Dircktur Jenderal Pendidikan Tinggi

a

drg. Arianti Anaya, MKM. Prof, Dr. Khairul Munadi, M.Eng.