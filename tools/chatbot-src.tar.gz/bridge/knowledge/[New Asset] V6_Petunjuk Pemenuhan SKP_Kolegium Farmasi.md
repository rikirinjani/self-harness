PETUNJUK PEMENUHAN 
KECUKUPAN SKP | KOLEGIUM FARMASI
2025 | 1

DISCLAIMER & TRACK CHANGES | Informasi dalam “Petunjuk Pemenuhan Kecukupan SKP” yang disusun Kolegium Farmasi berdasarkan pada dasar regulasi sebagaimana dicantumkan pada halaman 5. Apabila terdapat perbedaan informasi dalam Petunjuk ini dengan regulasi, maka yang digunakan adalah peraturan perundang-undangan/ regulasi eksisting. Sejawat diminta membaca secara komprehensif dasar regulasi yang digunakan dalam Petunjuk ini. Bila dikemudian hari terdapat perkembangan regulasi, maka petunjuk ini akan disesuaikan. | Dibuat		: 28 Maret 2025
Revisi terakhir 	: 16 Mei 2025
Versi		: Ke-6 | 2

YANG DIBAHAS DALAM PETUNJUK INI | Pemenuhan Satuan Kredit Profesi (SKP) | Melaporkan SKP melalui SKP Platform | Memverifikasi data SIP pada Satusehat dan SISDMK | 4 - 21 | 22 - 48 | 49 - 62 | Pertanyaan dan Permasalahan yang Sering Muncul | 63 - 69 | Topik | Halaman | 3

Pemenuhan
Satuan Kredit Profesi (SKP) | KOLEGIUM FARMASI
2025 | 4

UU No. 17 tahun 2023
tentang
Kesehatan | PP No. 28 tahun 2024
tentang
Peraturan Pelaksanaan 
UU 17/2023 tentang Kesehatan | KMK No. HK.01.07/MENKES/1561/2024
tentang
Pedoman Pengelolaan Pemenuhan Kecukupan SKP bagi Tenaga Medis dan Tenaga Kesehatan | Ditetapkan 20 September 2024 | Ditetapkan 8 Agustus 2023 | Ditetapkan 26 Juli 2024 | DASAR REGULASI | 5 | KepDirjend SDMK No. HK.02.02/F/20249/2025
Tentang
SKP Program Penanggulangan TBC dan PKG | Ditetapkan 8 Mei 2025

KONSEP PEMENUHAN SKP | Bukti kecukupan SKP:
STR (lama)
SERKOM | Bukti kecukupan SKP:
STR (aktif)
SERKOM (berlaku) 
	atau 
         Kecukupan SKP 
         (skp.kemkes.go.id) | Bukti kecukupan SKP:
STR (seumur hidup)
Kecukupan SKP 
         (skp.kemkes.go.id) | Keterangan:
SIP berlaku maksimal 5 (lima) tahun;
SKP dikumpulkan dalam periode berpraktik (5 tahun) untuk digunakan sebagai perpanjangan periode berikutnya (5 tahun selanjutnya). Contoh: Seorang Apoteker telah memenuhi SKP pada periode pemenuhan SKP 1 Sept 2019-1 Sept 2024. Yang bersangkutan mengajukan SIP Perpanjangan di DPMPTSP wilayahnya pada tanggal 21 September 2026. Maka, SIP yang dikeluarkan memiliki periode 21 September 2026 - 1 September 2029. | 6

Registrasi | Perizinan | STR Seumur Hidup | SKP 
(Satuan Kredit Profesi) | SIP
(Surat Izin Praktik) | Penjagaan Kompetensi | Ijazah dan/atau sertifikat profesi
Sertifikat Kompetensi | Kecukupan SKP dari 3 Ranah:
Pembelajaran 
Profesionalisme/ Pelayanan
Pengabdian Masyarakat | STR
Tempat Praktik
Kecukupan SKP 
        (khusus perpanjangan SIP) | Konsil atas nama Menkes | Kemenkes | Pelayanan Terpadu Satu Pintu (PTSP) Kabupaten/Kota | Dokumen | Validator | Penerbit | Konsil | Kolegium | Fasyankes dan/atau Dinas Kesehatan | Seluruh proses tidak memerlukan rekomendasi dari Organisasi Profesi | PENERBITAN STR DAN SIP | 7

KETENTUAN PENGAJUAN SIP | Perpanjangan | Pertama kali | SIP 2 atau 3 | STR
Tempat Praktik | 5 tahun | Lulusan  5 thn dengan STR lama yg masih berlaku/STR Seumur Hidup | Tidak pernah praktik >5 thn sejak sebelum UU 17/2023 | Dengan:
STR lama yg masih berlaku > Masa berlaku SIP = masa berlaku STR
STR Seumur Hidup = 5 tahun | 1




2 | STR
Tempat Praktik
Bukti pemenuhan kompetensi | STR
Tempat Praktik
Bukti Kecukupan SKP | 5 tahun | STR
SIP ke 1 dan/atau SIP ke 2
Tempat praktik | STR lama yg masih berlaku/STR Seumur Hidup | Dengan:
STR lama yg masih berlaku > Masa berlaku SIP = masa berlaku STR
STR Seumur Hidup > mengikuti masa berlaku SIP 1 | Persyaratan | Masa Berlaku SIP | STR lama yg masih berlaku/STR Seumur Hidup | 8

Pengabdian | RANAH DAN PROPORSI PEMENUHAN SKP | Ranah | Proporsi (%) 1 | Apoteker & 
Apt. Spesialis | Tenaga Vokasi Farmasi | Umum | Khusus 3 | Pembelajaran 2 | Profesi | (praktik/ pelayanan) | 1 Sisa presentase (15%) dapat dipenuhi dari ranah manapun
2 Wajib memenuhi 20% SKP Pembelajaran/tahun
3 Kondisi khusus ditetapkan oleh Menteri, misalnya DTPK (daerah tertinggal, terluar, kepulauan) | min. 100 SKP | min. 50 SKP | 9

SKP PLATFORM
Pengumpulan SKP 3 Ranah
Pembelajaran
Profesionalisme
Pengabdian | SatuSehat SDMK
Perizinan Praktik (SIP) | Plataran Sehat
SKP PEMBELAJARAN | RME SatuSehat a
SKP PROFESIONALISME | SKP PENGABDIAN | EKOSISTEM SATUSEHAT | EKOSISTEM SATUSEHAT | (praktik/ pelayanan) | a Selama proses integrasi RM Fasyankes ke RME SatuSehat, SKP Profesionalisme bidang pelayanan
    (Apotek, Puskesmas, Klinik, RS) dibuat dalam bentuk logbook | 10

KETENTUAN PENGAJUAN SIP | Seminar/ Webinar
Workshop
Simposium/ Konferensi
Pembelajaran Mandiri
Pelatihan | Jenis Kegiatan | Cara Perolehan | Pengabdian | (praktik/ pelayanan) | Mengikuti kegiatan melalui | Asuhan 
Non-asuhan 
Administratif 
Manajerial
Riset & Publikasi
dlsb | Data RME  terintegrasi SatuSehat dan/ atau Melaporkan Logbook melalui | Melaporkan Logbook melalui | Pengobatan massal (kolaboratif)
Penyuluhan kesehatan
Tim Khusus (relawan bencana, tim nakes haji)
Edukasi media sosial
dlsb | 11

CONTOH JENIS KEGIATAN PEMBELAJARAN | 12

CONTOH JENIS KEGIATAN PROFESIONALISME (1) | Mendokumentasikan kegiatan-kegiatan RnD, Produksi, QC, QA,K3, Halal Assurance, pelaporan eksternal, dlsb | Industri | Distribusi | Pelayanan | Mendokumentasikan kegiatan-kegiatan penerimaan, pendistribusian, pemusnahan,K3, pelaporan eksternal, dlsb | Mendokumentasikan kegiatan-kegiatan pengadaan, penerimaan,penyimpanan penyerahan, pemusnahan, pelaporan eksternal, dlsb | Pelayanan langsung kepada pasien, seperti pelayanan resep & non-resep, KIE, PIO, home care, visite, PTO, MESO/ PV, dlsb | Pelayanan tidak langsung kepada pasien, seperti penyiapan resep, iv admixture, peracikan, handling sitostatika, dlsb | Kegiatan keprofesian terkait distribusi, seperti membuat perencanaan, melakukan pengadaan, menjamin mutu selama penyimpanan, mendistribusikan, dlsb | Kegiatan keprofesian terkait manufakturing, seperti melakukan RnD, Produksi, QC, QA,K3, Halal Assurance, pelaporan eksternal, dlsb | Bidang Industri & Distribusi tidak melakukan pelayanan langsung pada pasien | 13

CONTOH JENIS KEGIATAN PROFESIONALISME (2) | 14

CONTOH JENIS KEGIATAN PROFESIONALISME (3)
Tambahan Khusus Program TBC dan PKG | 15

CONTOH JENIS KEGIATAN PENGABDIAN | 16

CONTOH JENIS KEGIATAN PENGABDIAN (2)
Tambahan Khusus Program TBC dan PKG | 17

PEDOMAN LENGKAP PEMENUHAN SKP | unduh disini | 18

SIMULASI PEMENUHAN SKP (Apoteker) | PROFESI APOTEKER (100 SKP/ 5 tahun) | PEMBELAJARAN
(min. 45% = 45 SKP/ 5 th) | PROFESIONALISME 
(min. 35% = 35 SKP/ 5 th) | PENGABDIAN
(min. 5% = 5 SKP/ 5 tahun) | Seminar & Webinar
8 x @ 4 SKP = 32 SKP | Workshop
1 x @ 10 SKP = 10 SKP | Simposium/ Konferensi
1 x @ 15 SKP = 15 SKP | Asuhan
24 SKP/ 5 tahun | Non Asuhan
24 SKP/ 5 tahun | Administratif
24 SKP/ 5 tahun | Total (A) = 57 SKP 1 | Total (B)= 72 SKP 2 | Bakti Sosial 
1 x @ 10 SKP = 10 SKP | Penyuluhan
1 x @ 3 SKP = 3 SKP | Total (C) = 16 SKP | Grand Total = A  + B + C = 145 SKP  memenuhi | Keterangan:
1 Merata minimal 20% per tahun, yakni 9 SKP/ tahun;
2  Jika bridging eRM dengan SatuSehat sudah selesai, namun kegiatan pelayanan masih belum terintegrasi maka terkena “pinalti/ potongan” 50% | Edukasi Media Sosial
6 x @ 0,5 SKP = 3 SKP | 19

TENAGA VOKASI FARMASI (50 SKP/ 5 tahun) | PEMBELAJARAN
(min. 45% = 22,5 SKP/ 5 th) | PROFESIONALISME 
(min. 35% = 17,5 SKP/ 5 th) | PENGABDIAN
(min. 5% = 2,5 SKP/ 5 tahun) | Seminar & Webinar
10 x @ 2 SKP = 20 SKP | Workshop
1 x @ 5 SKP = 5 SKP | Non Asuhan
12 SKP/ 5 tahun | Administratif
12 SKP/ 5 tahun | Total (A) = 25 SKP 1 | Total (B)= 24 SKP 2 | Penyuluhan
1 x @ 3  SKP = 3 SKP | Edukasi Media Sosial
6 x @ 0,5 SKP = 3 SKP | Total (C) = 6 SKP | Grand Total = A  + B + C = 55 SKP  memenuhi | Keterangan:
1 Merata minimal 20% per tahun, yakni 4,5 SKP/ tahun;
2  Jika bridging eRM dengan SatuSehat sudah selesai, namun kegiatan pelayanan masih belum terintegrasi maka terkena “pinalti/ potongan” 50% | SIMULASI PEMENUHAN SKP (Tenaga Vokasi Farmasi) | 20

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi | 21

Melaporkan Logbook melalui
SKP Platform | KOLEGIUM FARMASI
2025 | 22

LOGIN DI SATUSEHAT SDMK | klik “Masuk” | isi Email, Kata sandi dan Captcha | 1 | 2 | klik “Masuk” | 3 | satusehat.kemkes.go.id/sdmk | 23

BERHASIL LOGIN – Halaman Beranda | Status kecukupan SKP | 1 | Belum tercukupi | Tercukupi | Periode SIP 
(max. 5 tahun) | 2 | Perolehan & Target SKP
(100 untuk Apt, 50 untuk TVF) | 3 | 24

MENUJU SKP PLATFORM | klik 
“Pengelolaan SKP” | klik 
“SKP Platform” | 2 | 1 | 25

BERHASIL MASUK SKP PLATFORM – Halaman Beranda | Tampilan di Satusehat SDMK | Tampilan di SKP Platform | 26

MENUJU FORMULIR PENGISIAN – Pilih Kegiatan (1) | klik 
“Formulir Pengisian” | 1 | pilih kegiatan | 2 | Perhatikan | klik “Input” sesuai kegiatan | 3 | 27

MENUJU FORMULIR PENGISIAN – Pilih Kegiatan (2) | klik 
“Formulir Pengisian” | 1 | pilih kegiatan | 2 | klik “Input” sesuai kegiatan | 3 | Ranah Profesionalisme | 28

MENUJU FORMULIR PENGISIAN – Pilih Kegiatan (3) | klik 
“Formulir Pengisian” | 1 | pilih kegiatan | 2 | klik “Input” sesuai kegiatan | 3 | Ranah Pengabdian | 29

CONTOH – Melaporkan Ranah Profesionalisme (1a) | Rekap jenis dan jumlah kegiatan profesionalisme;
Buat Logbook bukti kegiatan/ praktik;
Pastikan memuat informasi/ data 
Kop Instansi;
Identitas (nama, No. STR, No. SIP, tgl. ED SIP);
Periode kegiatan;
Jenis dan jumlah kegiatan.
Logbook ditanda tangani dan stempel basah atau e-sign yang dapat diverifikasi oleh tenaga medis/ tenaga kesehatan yang ber-SIP, yakni misalnya: Apoteker Penanggung Jawab (APJ) Apotek, atau pimpinan langsung (misal Ka. IFRS jika praktik di RS), atau pimpinan Fasyankes (misal direktur RS, Kepala Puskesmas, atau pimpinan/ Penanggung Jawab klinik);
Disimpan dalam bentuk .pdf dan berukuran maksimal 250 kb. | a | Contoh Logbook Bidang Pelayanan | 30

CONTOH – Melaporkan Ranah Profesionalisme (1b) | Rekap jenis dan jumlah kegiatan profesionalisme;
Buat Logbook bukti kegiatan/ praktik;
Pastikan memuat informasi/ data 
Kop Instansi;
Identitas (nama, No. STR, No. SIP, tgl. ED SIP);
Periode kegiatan;
Jenis dan jumlah kegiatan.
Logbook ditanda tangani dan stempel basah atau e-sign yang dapat diverifikasi  oleh Apoteker yang ber-SIP, yakni misalnya: Apoteker Penanggung Jawab (APJ), atau pimpinan langsung (misal PJ bagian Produksi/ QA /QC / RnD);
Disimpan dalam bentuk .pdf dan berukuran maksimal 250 kb. | b | Contoh Logbook Bidang Industri | 31

CONTOH – Melaporkan Ranah Profesionalisme (1c) | Rekap jenis dan jumlah kegiatan profesionalisme;
Buat Logbook bukti kegiatan/ praktik;
Pastikan memuat informasi/ data 
Kop Instansi;
Identitas (nama, No. STR, No. SIP, tgl. ED SIP);
Periode kegiatan;
Jenis dan jumlah kegiatan.
Logbook ditanda tangani dan stempel basah atau e-sign yang dapat diverifikasi oleh Apoteker yang ber-SIP, yakni misalnya: Apoteker Penanggung Jawab (APJ), atau pimpinan langsung;
Disimpan dalam bentuk .pdf dan berukuran maksimal 250 kb. | c | Contoh Logbook Bidang Distribusi | 32

CONTOH – Melaporkan Ranah Profesionalisme (2a) | Masuk “Satusehat SDMK”
Masuk “SKP Platform”
Masuk  “Formulir Pengisian”
Pilih Ranah & Kegiatan
(lihat tabel 12 Pedoman Kecukuapan SKP) | 2 | Gunakan Pedoman | 33

CONTOH – Melaporkan Ranah Profesionalisme (2b) | Masuk “Satusehat SDMK”
Masuk “SKP Platform”
Masuk  “Formulir Pengisian”
Pilih Ranah & Kegiatan
(lihat tabel 12 Pedoman Kecukuapan SKP) | 2 | Gunakan Pedoman | 34

CONTOH – Melaporkan Kegiatan Asuhan (3) | 3 | 1 | 2 | 35

CONTOH – Melaporkan Kegiatan Administratif (4a) | 1 | Sesuai data SIP di SatuSehat SDMK dan SISDMK | CONTOH BUKTI | 2 | 3 | 4 | 36

CONTOH – Melaporkan Kegiatan Asuhan (4b) | 1 | Sesuai data SIP di SatuSehat SDMK dan SISDMK | CONTOH BUKTI | 2 | 3 | 4 | 37

PERINGATAN BERHASIL/ GAGAL MENYIMPAN | Berhasil | Gagal | Dokumen bukti yang di upload berupa file PDF dan ukuran file max. 250 KB;
Tanggal mulai dan berakhir kegiatan berada dalam periode berlakunya SIP. | Perlu Diperhatikan | 38

CONTOH – Melaporkan Kegiatan Pengabdian (1a) | Ikuti/ laksanakan kegiatan pengabdian sesuai ketentuan;
Harus berkaitan dengan kesehatan & sesuai kompetensi;
Kegiatan intervensi/ operatif wajib berkoordinasi dengan dinas kesehatan/ RSUD/ puskesmas setempat;
Scan sertifikat atau berita acara kegiatan, disimpan dalam bentuk .pdf dan berukuran maksimal 250 kb.
Pastikan sertifikat/ berita acara memuat informasi/ data 
Kop Instansi/ logo penyelenggara;
Kegiatan yang dilaksanakan;
Tempat & tanggal pelaksanaan.
Syarat dan ketentuan bukti menyesuaikan jenis kegiatan (lihat tabel 13 pada Pedoman Pengelolaan Pemenuhan Kecukupan SKP) | 1 | No. sertifikat | 39

CONTOH – Melaporkan Kegiatan Pengabdian (1b) | Ikuti/ laksanakan kegiatan pengabdian sesuai ketentuan;
Harus berkaitan dengan kesehatan & sesuai kompetensi;
Kegiatan intervensi/ operatif wajib berkoordinasi dengan dinas kesehatan/ RSUD/ puskesmas setempat;
Scan sertifikat atau berita acara kegiatan, disimpan dalam bentuk .pdf dan berukuran maksimal 250 kb.
Pastikan sertifikat/ berita acara memuat informasi/ data 
Kop Instansi/ logo penyelenggara;
Kegiatan yang dilaksanakan;
Tempat & tanggal pelaksanaan.
Syarat dan ketentuan bukti menyesuaikan jenis kegiatan (lihat tabel 13 pada Pedoman Pengelolaan Pemenuhan Kecukupan SKP) | 1 | CONTOH BERITA ACARA | 40

CONTOH – Melaporkan Kegiatan Pengabdian (2a) | Masuk “Satusehat SDMK”
Masuk “SKP Platform”
Masuk  “Formulir Pengisian”
Pilih Ranah & Kegiatan
Klik “Input” | 2 | Gunakan Pedoman | 41

CONTOH – Melaporkan Kegiatan Pengabdian (2b) | Masuk “Satusehat SDMK”
Masuk “SKP Platform”
Masuk  “Formulir Pengisian”
Pilih Ranah & Kegiatan
Klik “Input” | 2 | Gunakan Pedoman | 42

CONTOH – Melaporkan Kegiatan Pengabdian (3a) | 1 | 2 | 3 | 4 | 5 | 43 | CONTOH SERTIFIKAT | Nama Sejawat | ttd + stempel | ttd + stempel organisasi | logo

CONTOH – Melaporkan Kegiatan Pengabdian (3b) | 1 | 3 | 5 | CONTOH BUKTI UNGGAHAN | 2 | 44

PERLU DIPERHATIKAN (1) | Gunakan foto terbaru yang menampilkan tampak depan wajah tanpa kacamata atau masker dengan latar belakang merah.
Pastikan foto jelas, berkualitas tinggi minimal 354 pixel x 472 pixel, dan berdimensi 3x4.
Format gambar: JPG, JPEG, atau PNG, dan ukuran file tidak melebihi 2MB. | Jenis profesi dan Kompetensi terisi | 2 | 1 | 45

PERLU DIPERHATIKAN (2) | Status pekerjaan (praktik)                                        melalui SISDMK | 3 | Tanggal mulai dan berakhir SIP terisi, 
dengan rentang maksimal 5 tahun | 4 | 46

PERLU DIPERHATIKAN (3) | Status pekerjaan (praktik)                                        melalui SISDMK | 4 | Tanggal mulai dan berakhir SIP terisi, maksimal 5 tahun | 5 | Mengapa SKP saya tak kunjung di verifikasi?
Mengapa SKP saya ditolak/ diberi NOL ? | Foto sudah diunggah di SatuSehat SDMK sesuai ketentuan | 1 | Data di profil SatuSehat SDMK, mulai “Data Diri”, “Keprofesian”, “Pekerjaan” sampai “Data Pendukung” sudah terisi dengan benar dan lengkap | 2 | Jenis Profesi dan Kompetensi terisi sesuai STR | 3 | Logbook dan/ atau berita acara, dibuat sesuai ketentuan, nampak jelas identitasnya, tidak buram, terdapat kop surat dan ditandatangani oleh tenaga kesehatan ber-SIP (misal APJ, Ka-IFRS, Direktur/PJ Klinik, Kepala Puskesmas, Direktur RS) | 6 | Sertifikat asli, jelas jenis kegiatan, jelas identitas penerbit dan pemiliknya, serta tercantum besaran SKP nya (jika merupakan sertifikat sebelum 1 Maret 2024) | 7 | Kegiatan sesuai ketentuan, Logbook dan/atau berita acara sesuai tempat praktik atau domisili. Bukan merupakan kegiatan yang diada-adakan | 8 | 47

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi | 48

Memverifikasi data SIP pada
Satusehat SMDK & SISDMK | KOLEGIUM FARMASI
2025 | 49

LOGIN DI SATUSEHAT SDMK | klik “Masuk” | isi Email, Kata sandi dan Captcha | 1 | 2 | klik “Masuk” | 3 | satusehat.kemkes.go.id/sdmk | 50

BERHASIL LOGIN – Halaman Beranda | Perhatikan | Data SIP belum sinkron 
artinya
Data SKP TIDAK SINKRON | 51

Jika Data SIP belum sinkron | Perhatikan | Data SKP Pembelajaran dari LMS PlataranSehat bisa tampil, namun SKP Profesionalisme dan SKP Pengabdian tidak bisa masuk | SKP PLATFORM | 52

Data Pekerjaan (Praktik) di Satusehat SDMK | klik 
“Profil saya” | 1 | klik 
“Pekerjaan” | 2 | klik 
“Tambah pekerjaan” | 3 | 53

Lengkapi Data Pekerjaan (Praktik) di Satusehat SDMK | 54

Data Pekerjaan (Praktik) Muncul di Satusehat SDMK | Validasi data SIP di SISDMK
oleh Faskes/ Dinas Kesehatan | 55

LOGIN SISDMK | Menuju halaman login | isi Email & Kata sandi | 1 | 2 | klik “Masuk” | 4 | sisdmk.kemkes.go.id/login | centang “saya bukan robot” | 3 | Email & Kata Sandi dipegang oleh Pimpinan/ Penanggung Jawab Fasilitas;
Jika belum memiliki akun SISDMK atau Fasilitas belum terdaftar maka perlu melapor ke Dinas Kesehatan Kabupaten/ Kota;
Disarankan menggunakan email instansi/ fasilitas yang dibuat khusus, bukan email pribadi (perseorangan). | Perhatikan | 56

BERHASIL LOGIN – Halaman Beranda SISDMK | 57

Validasi data Satusehat SDMK | klik 
“Validasi Satusehat SDMK” | 1 | klik 
“Validasi Data Eksisting” | 2 | klik “Cari” | 3 | 58

Validasi data SIP di  SISDMK | Cari data yang hendak divalidasi” | 1 | klik “Lihat” | 2 | 59

Validasi data SIP di SISDMK | klik “Proses”
jika data sudah sesuai | 2 | Lihat dan Periksa 
kesesuaian data
(Biodata & Pekerjaan) | 1 | 60

Data Pekerjaan (Praktik) Tervalidasi di Satusehat SDMK | Data SIP di Satusehat SDMK | Validasi data SIP di SISDMK
oleh Faskes/ Dinas Kesehatan | 61

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi | 62

Pertanyaan & Permasalahan
yang Sering Muncul | KOLEGIUM FARMASI
2025 | 63

Frequently asked questions (FAQ) | unduh disini | 64

Video Tutorial dan FAQ | youtube.com/@KonsilKesehatanIndonesia | buka disini | 65

66 | Rekomendasi Playlist | buka disini | youtube.com/@Kolegium_Farmasi

Fast track verifikasi SKP diberikan bagi sejawat yang SIP nya sudah ED atau menjelang ED (< 6 bulan) | Kegiatan Pengabdian hanya dapat diberikan sesuai ketentuan. Kegiatan pengobatan masal, penyuluhan dan sejenisnya hanya dapat diberikan bagi Apoteker/ TVF yang hadir menjadi panita ditempat kegiatan. Peran sebagai donatur saja, meskipun hal tersebut mulia, tidak dapat diberikan SKP. Sedangkan jika melalukan edukasi di media sosial akun tidak boleh di private. | Sertifikat asli, jelas jenis kegiatan, jelas identitas penerbit dan pemiliknya, serta tercantum besaran SKP nya (jika merupakan sertifikat kegiatan pembelajaran sebelum 1 Maret 2024). Kegiatan Pembelajaran setelah 1 Maret 2025 wajib melalui LMS PlataranSehat dan tidak perlu upload mandiri di SKP Platform. | Logbook dan/ atau berita acara, dibuat sesuai ketentuan, nampak jelas identitasnya, tidak buram, terdapat kop surat dan ditanda tangani oleh tenaga kesehatan ber-SIP (misal APJ, Ka-IFRS, Direktur/PJ Klinik, Kepala Puskesmas, Direktur RS). | PERMASALAHAN YANG SERING DITEMUI | 4 | 3 | Pastikan profil di SatuSehat SDMK, dan LMS PlataranSehat sudah terisi dengan lengkap. Khususnya data pekerjaan (praktik) atau SIP dalam status                                         melalui SISDMK. Termasuk tanggal mulai dan berakhirnya SIP (maksimal dalam rentang 5 tahun). | 1 | Jenis Profesi dan Kompetensi terisi sesuai data STR. Misal pada Profesi Apoteker terdapat 2 jenis Kompetensi (Apoteker dan Apoteker Spesialis). Sedangkan untuk TVF ada Tenaga Vokasi Farmasi dan Analis Farmasi dan Makanan. | 2 | 5 | 6 | 67

68 | PROGRES VERIFIKASI SKP 
(15 Mei 2025)

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi | 69