KOLEGIUM
Q FARMASI

PENJAGAAN KOMPETENSI &
SATUAN KREDIT PROFESI
(SKP)

KOLEGIUM FARMASI
2025

4 KOLEGIUM

DISCLAIMER & TRACK CHANGES  Farmasi

Informasi dalam “Penjagaan Kompetensi & Satuan Kredit Profesi (SKP)” disusun

oleh Kolegium Farmasi, ditujukan untuk lulusan baru Apoteker dan Tenaga

Vokasi Farmasi. Substansi berdasarkan pada regulasi sebagaimana

dicantumkan pada halaman 3. Apabila terdapat perbedaan informasi dengan

regulasi, maka yang digunakan adalah peraturan perundang-undangan/

regulasi eksisting. Sejawat diminta membaca secara komprehensif dasar

regulasi yang digunakan. Bila dikemudian hari terdapat perkembangan regulasi,

maka informasi disini akan disesuaikan.

Dibuat :9 Agustus 2025

Revisiterakhir :12September2025

| Versi :Ke-2

\ :

4 KOLEGIUM

DASAR REGULASI  Farmasi

UU No. 17 tahun 2023 PP No. 28 tahun 2024 KMK No. HK.01.07/MENKES/1561/2024
tentang tentang tentang
Kesehatan Peraturan Pelaksanaan Pedoman Pengelolaan Pemenuhan
Ditetapkan 8 Agustus 2023 UU17/2023 tentang Kesehatan Kecukupan SKP bagi Tenaga Medis dan

Ditetapkan 26 Juli2024 Tenaga Kesehatan

Ditetapkan 20 September 2024

KepDirjend SDMK No. HK.02.02/F/20249/2025
Tentang

SKP Program Penanggulangan TBC dan PKG

Ditetapkan 8 Mei 2025

4 KOLEGIUM
FARMASI

PRESIDEN
Menteri Kesehatan

MOH,
Pa Ay,
ih » 7)

ee ee

Wika

¥.

KONSIL KESEHATAN INDONESIA
MAJELIS DISIPLIN PROFESI
PROFESSIONAL DISCIPLINARY BOARD

KONSIL - KOLEGIUM - MDP

®  KONSIL
Ve KESEHATAN
INDONESIA

Konsil masing-masing
kelompok

=

dan 12 lainnya

Tim AdHoc

Pemeriksa Provinsi

@ KOLEGIUM
KESEHATAN

a?
“V¥ © INDONESIA

4 KOLEGIUM
DOKTER

Keterangan:
Garis pertanggungjawaban
=== Garis koordinasi

4 KOLEGIUM
FARMASI

8 xowecium 8 ko.ecium
Q KEBIDANAN Q KEPERAWATAN
dan lain-lain
(total 81 Kolegium)

@ KOLEGIUM
DOKTER

GIGI

KONSIL - KOLEGIUM - MDP (2)

Dasar

Cc
©
pe
o
oO

Wewe-

nang

Pendidikan & Pelatihan

UU 17/2023 Pasal 272
PP 28/2024 Pasal 704 -711

1. Menyusunstandar kompetensi;
2. Menyusuan standar kurikulum
pelatihan.

Menerbitkan Sertifikat Kompetensi

jalankan tv

Perizinan & Pembinaan

KR KOLEGIUM

| FARMASI

Penegakan Disiplin

UU 17/2023 Pasal 268 - 271
PP 28/2024 Pasal694 -703

1. Melakukan registrasi tenaga

medis dan tenaga kesehatan;

2. Melakukan pembinaan teknis

keprofesian.

Menerbitkan, menonaktifkan, dan
mencabut STR

UU 17/2023 Pasal304
PP 28/2024 Pasal 712 - 718

Melaksanakan penegakan disiplin
profesitenaga medis dantenaga
kesehatan berdasarkan ketentuan
penegakan disiplin yang
ditetapkan oleh Menteri

8 koLecium
| FARMASI

SIP

PENERBITAN STR DAN SIP

rat Izin Praktik)

Bukti telah terdaftar 1. Bentuk penjagaan Bukti legalizin berpraktik sesuai

(PTSP) Kabupaten/Kota

1 I
1 I
: ' I
Fungsi (pengakuan negara) I kompetensi profesi, kompetensi &
. Syarat wajib untuk praktik : 2. Syarat perpanjangan SIP ' kewenangan
1 I
. ljazah dan/atau sertifikat : Kecukupan SKP dari 3 Ranah: ' 1. STR
Dokumen profesi ' 1. Pembelajaran 1 2.TempatPraktik
. Sertifikat Kompetensi 1 2. Profesionalisme/Praktik ' 3. Kecukupan SKP
1 3. Pengabdian (khusus perpanjangan SIP)
1 I
1 :
B Validator Konsil 1 "Ee | Fasyankes dan/atau Dinas
' Kesehatan
1 I
—* 1
= Penerbit Konsil atas nama Menkes Kemenkes Pelayanan Terpadu Satu Pintu
1 I

(& SKP merupakan bentuk penjagaan kompetensi setelah lulus pendidikan (lifelong learning)

RK KOLEGIUM

KONSEP PEMENUHAN SKP 1 FARMas!
2025 2030
Ome ee ee ee =>

5 tahun pengumpulan SKP

Dokumen Anda (saat ini): Dokumen Anda (nanti):
1. Ijazah/Sertifikat Profesi 1. STR
2. Sertifikat Kompetensi (SERKOM) 2. Surat lIzin Praktik (SIP)
3. Surat Tanda Registrasi (STR)@ 3. Kecukupan SKP (SKP Platform):

4. Sertifikasi Pemenuhan Kompetensi¢4

Keterangan:

a STR berlaku seumur hidup, untuk pembuatan STR pertama kali dikenakan biaya. Registrasi pertama melalui kki.go.id/registrasi;

> SIP = Surat Izin Praktik, berlaku maksimal 5 (lima) tahun, melalui MPP Digital Nasional atau Dinas Perizinan/PTSP atau Dinas Kesehatan;
¢SKP dikumpulkan dalam periode berpraktik (5 tahun), untuk digunakan sebagai perpanjangan periode berikutnya (5 tahun selanjutnya);
4 Sertifikasi Pemenuhan Kompetensi = Ujian Kompetensi ulang, perlu dilakukan jika dalam waktu 5 tahun tidak berpraktik

KETENTUAN PENGAJUAN SIP

EJ Persyaratan

8 koLecium
| FARMASI

< Masa Berlaku SIP

H D :
UN evel os dengan STR oe STR 1. SIR lamayg masih berlaku --> Maka
pra that ox 2. Tempat Praktik Masa berlaku SIP = masa berlaku STR
H 2. STRSeumur Hidup =5 tahun
2 Tidakpemahpraktik>5thn | |. STR
= 2. Tempat Praktik
sejak sebelum UU 17/2023 3 Bukti enuhan 5 tahun
kompetensi
1. STR
STRlama yg masih 2. TempatPraktik 5 tahun
berlaku/STR SeumurHidup 3. BuktiKecukupan SKP
} STR Dengan:
STRlamaygmasih 2. SIPkeldan/atauSIPke2 _ eye See nedakuere
berlaku/STR Seumur Hidup 3. Tempatpraktik : 2. STRSeumur Hidup --> mengikuti masa

berlaku SIP 1

co

9 KoLecium
Q FARMASI

RANAH DAN PROPORSI PEMENUHAN SKP

 Khusus? Apoteker & Tenaga Vokasi
Apt. Spesialis Farmasi

Ranah

I
I
I
I I
| |
Pembelajaran 2
) >45 | >25 > 45 I ->22,5
I I
Frofesionalisme >35 | >55 > 35 1 2175
I ;
| |
Pengabdian >5 1 >5 >5 ' >25
I I
l I

2Wajib memenuhi 20% SKP Pembelajaran/tahun
3Kondisikhusus ditetapkan oleh Menteri, misalnya DTPK (daerah tertinggal, terluar, Kepulauan) 9

EKOSISTEM SATUSEHAT

EKOSISTEM SATUSEHAT

Ww

Plataran Sehat
SKP PEMBELAJARAN

SKP PLATFORM

Pengumpulan SKP 3 Ranah

Pembelajaran

RME SatuSehat2 Profesionalisme
Pengabdian
SKP PROFESIONALISME

(praktik/ pelayanan)
2 SKP PENGABDIAN

a Selama proses integrasi RM Fasyankes ke RME SatuSehat, SKP Profesionalisme bidang pelayanan

(Apotek, Puskesmas, Klinik, RS) dibuat dalam bentuk logbook

KOLEGIUM
FARMASI

4 KOLEGIUM

KETENTUAN PENGAJUAN SIP  FaRMas:

Jenis Kegiatan | Cara Perolehan |

. Seminar/ Webinar Mengikuti kegiatan melalui
. Workshop

. Simposium/ Konferensi
. Pembelajaran Mandiri

. Pelatihan

. Asuhan Data RME terintegrasi SatuSehat dan/ atau

. Non-asuhan Melaporkan Logbook melalui
. Administratif H

. Manajerial
. Riset & Publikasi
. disb

. Pengobatan massal (kolaboratif) Melaporkan Logbook melalui
. Penyuluhan kesehatan :

. TimKhusus (relawan bencana, tim
nakes haji) i
. Edukasi media sosial E
. disb E ‘

1

CONTOH JENIS KEGIATAN PROFESIONALISME (1)

8 koLecium
| FARMASI

hea Industri fA Distribusi | & Pelayanan |

Mendokumentasikan
kegiatan-kegiatan RnD,
Produksi, QC, QA,K3, Halal
Assurance, pelaporan
eksternal, disb

Administ

| Mendokumentasikan kegiatan-
i kegiatan penerimaan,

i pendistribusian,

? pemusnahan,K3, pelaporan

i eksternal, disb

: Mendokumentasikan kegiatan-
i kegiatan pengadaan,

i penerimaan,penyimpanan

i penyerahan, pemusnahan,

i pelaporan eksternal, disb

Kegiatan keprofesian terkait
manufakturing, seperti
melakukan RnD, Produksi,
QC, QA,K3, Halal Assurance,
pelaporan eksternal, disb

Bidang Industri & Distribusi tidak melakukan pelayanan langsung pada pasien

i Kegiatan keprofesian terkait
: distribusi, seperti membuat

i perencanaan, melakukan

i pengadaan, menjamin mutu

i selama penyimpanan,

? mendistribusikan, disb

: Pelayananlangsung kepada
i pasien, seperti pelayanan

i resep &non-resep, KIE, PIO,
? homecare, visite, PTO,

i MESO/PV,disb

i; Pelayanan tidak langsung
i kepada pasien, seperti

i penyiapan resep, iv

? admixture, peracikan,

i handling sitostatika, disb

12

8 koLecium
| FARMASI

Video Tutorial dan FAQ

nsil Kesehatan Indonesia 1D
@KonsilKesehatanindonesia - 14 rb subscriber - 58 video GP YouTube

Konsil Kesehatan Indonesia ...selengkapnya

Tombol Unduh STR Tidak Muncul = FAQ SKP CARA PENGHITUNGAN {  Gimana yaah caranya melengkapi } Pengajuan STR Tenaga Medis &
297 x @tonton + 2 minggu yang lake ‘SKP data STR yang belurn ter-verifikasi... Tenaga Kesehatan melalui aplikasi...

‘305 x ditonton - 2 minggu yang lalu ‘560 x ditomton * 1 bulan yang lalu 1510 x Gtonton - 1 Dulan yang lau

STR TEMAGA MEDIS &
TENAGA KESEHATAN

“Makan yong sutoh
pune amun @ KTK
horus buat akun tage?”

a

Tenaga Kesehatan Perlukah Daftar :  Tutorialmasuk akun SKP Platform : Video Tutorial SKP Platform 3 Video Tutorial STR Tenaga Medis :
dan Tenaga Kesehatan

527 x gitonton « 1 bulan yang lalu §9 rb x ditonton + 2 bulan yang laks

buka disini

‘Akun di KKI? 726 x ditonton + 1 butan yang tal 43 rb x ditonton + 2 butan yang tatu

4 KOLEGIUM

Rekomendasi Playlist & FaRMasi

youtube .com/@Kolegium_Farmasi

4 KOLEGIUM
Frequently asked questions (FAQ) | FARMASI

4 KOLEGIUM

HELPDESK STR - SKP - SIP - MPPD  FaRmas:

ey helpdesk.ditjennakes@kemkes.go.id

9, Jl. Hang Jebat Raya Blok F 3,
Kebayoran Baru, Jakarta Selatan

Sampaikan kendala melalui email helpdesk
dengan melampirkan data diri dan data

pendukung secara lengkap sebagai berikut:

¥Y Namalengkap

¥ NIK & Foto KTP

¥ STR &SERKOM (jika ada)

¥ Email

Y Rincian kendala (narasi)

Y Buktikendala (screenshot)

KR KOLEGIUM

| FARMASI

(~) GZ] 0821 1121 8822 (chat only)

kolegium-farmasi@kki.go.id

Pokies

- ne
@kolegiumfarmasi Rr:

ral et ~~
(>) @Kolegium_Farmasi Fey

Gay kki.go.id/kolegium/farmasi