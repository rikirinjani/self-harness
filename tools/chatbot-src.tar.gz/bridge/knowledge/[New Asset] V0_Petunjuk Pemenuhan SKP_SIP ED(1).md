STRENGHTENING PHARMACY WORKFORCE IN INDONESIA | KOLEGIUM FARMASI
2025 | 1 | Funding Proposal to the GF

OBJECTIVE | 2 | Enhance pharmaceutical workforce capacity through a nationally standardised competence & professional development framework | OUTPUT | National competency framework & service standards
CPD System & Modules
Defined pharmacist role for HIV/ AIDS, Tuberculosis, and Malaria elimination program
Strenghtened pharmacy workforce supporting health system

Situasional
Analysis | 2025 | APPROACH | 3 | Framework
Development | Pilot
Implementation | National
Rollout | 2026 | SUSTAINABILITY & TRANSITION | Framework integration to: National policies, licensing system, education standards
Partnership with Universities and proffesional pharmacy associations;
Hosting CPD modules to national platform (PlataranSehat)

0821 1121 8822 (chat only) | kolegium-farmasi@kki.go.id | @kolegiumfarmasi | @Kolegium_Farmasi | kki.go.id/kolegium/farmasi | 4