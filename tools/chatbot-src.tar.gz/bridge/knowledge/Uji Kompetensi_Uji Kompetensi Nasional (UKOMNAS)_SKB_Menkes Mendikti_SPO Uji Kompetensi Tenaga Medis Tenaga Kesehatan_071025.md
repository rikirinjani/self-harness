KEPUTUSAN BERSAMA
MENTERI PENDIDIKAN TINGGI, SAINS, DAN TEKNOLOGI
DAN MENTERI KESEHATAN REPUBLIK INDONESIA
NOMOR 4/M/KB/2025
NOMOR HK.01.08/MENKES/948/ 2025
TENTANG
STANDAR PROSEDUR OPERASIONAL UJI KOMPETENSI SECARA NASIONAL
BAGI PESERTA DIDIK PADA PENDIDIKAN VOKASI DAN PENDIDIKAN
PROFESI, DAN UJI KOMPETENSI BERSTANDAR NASIONAL BAGI PESERTA
DIDIK PADA PENDIDIKAN PROFESI PROGRAM SPESIALIS/SUBSPESIALIS
TENAGA MEDIS DAN TENAGA KESEHATAN

DENGAN RAHMAT TUHAN YANG MAHA ESA

MENTERI PENDIDIKAN TINGGI, SAINS, DAN TEKNOLOGI
DAN MENTERI KESEHATAN,

Menimbang : bahwa untuk melaksanakan ketentuan Pasal 591 ayat (5)
Peraturan Pemerintah Nomor 28 Tahun 2024 tentang
Peraturan Pelaksanaan Undang-Undang Nomor 17 Tahun
2023 tentang Kesehatan, perlu menetapkan Keputusan
Bersama Menteri Pendidikan Tinggi, Sains, dan Teknologi
dan Menteri Kesehatan tentang Standar Prosedur
Operasional Uji Kompetensi Secara Nasional bagi Peserta
Didik pada Pendidikan Vokasi dan Pendidikan Profesi, dan
Uji Kompetensi Berstandar Nasional bagi Peserta Didik pada
Pendidikan Profesi Program Spesialis/Subspesialis Tenaga
Medis dan Tenaga Kesehatan;

Mengingat : 1. Undang-Undang Nomor 12 Tahun 2012 tentang
Pendidikan Tinggi (Lembaran Negara Republik
Indonesia Tahun 2012 Nomor 158, Tambahan
Lembaran Negara Republik Indonesia Nomor 5336);

2. Undang-Undang Nomor 17 Tahun 2023 tentang
Kesehatan (Lembaran Negara Republik Indonesia Tahun
2023 Nomor 105, Tambahan Lembaran Negara Republik
Indonesia Nomor 6887);

3.  Peraturan Pemerintah Nomor 4 Tahun 2014 tentang
Penyelenggaraan Pendidikan Tinggi dan Pengelolaan
Perguruan Tinggi (Lkembaran Negara Republik Indonesia
Tahun 2014 Nomor 16, Tambahan Lembaran Negara
Republik Indonesia Nomor 5500);

4. Peraturan Pemerintah Nomor 28 Tahun 2024 tentang
Peraturan Pelaksanaan Undang-Undang Nomor 17
Tahun 2023 tentang Kesehatan (Lembaran Negara
Republik Indonesia Tahun 2024 Nomor 135, Tambahan
Lembaran Negara Republik Indonesia Nomor 6952);

Menetapkan

KESATU

KEDUA

KETIGA

KEEMPAT

KELIMA

= B=

MEMUTUSKAN:

KEPUTUSAN BERSAMA MENTERI PENDIDIKAN TINGGI,
SAINS, DAN TEKNOLOGI DAN MENTERI KESEHATAN
TENTANG STANDAR PROSEDUR OPERASIONAL UJI
KOMPETENSI SECARA NASIONAL BAGI PESERTA DIDIK
PADA PENDIDIKAN VOKASI DAN PENDIDIKAN PROFESI,
DAN UJI KOMPETENSI BERSTANDAR NASIONAL BAGI
PESERTA DIDIK PADA PENDIDIKAN PROFESI PROGRAM
SPESIALIS/SUBSPESIALIS TENAGA MEDIS DAN TENAGA
KESEHATAN.

Menetapkan Standar Prosedur Operasional Uji Kompetensi
Secara Nasional bagi Peserta Didik pada Pendidikan Vokasi
dan Pendidikan Profesi, dan Uji Kompetensi Berstandar
Nasional bagi Peserta Didik pada Pendidikan Profesi Program
Spesialis/Subspesialis Tenaga Medis dan Tenaga Kesehatan
yang selanjutnya disebut SPO Uji Kompetensi, sebagaimana
tercantum dalam Lampiran yang merupakan bagian tidak
terpisahkan dari Keputusan Bersama ini.

SPO Uji Kompetensi sebagaimana dimaksud dalam Diktum

KESATU mengatur mengenai:

a. penyelenggaraan uji kompetensi secara nasional bagi
peserta didik pada pendidikan vokasi dan pendidikan
profesi tenaga medis dan tenaga kesehatan; dan

b. penyelenggaraan uji kompetensi berstandar nasional
bagi peserta didik pada pendidikan profesi program
spesialis/subspesialis tenaga medis dan _ tenaga
kesehatan.

Uji kompetensi sebagaimana dimaksud dalam Diktum

KEDUA:

a. dilaksanakan dalam rangka menilai pencapaian standar
kompetensi tenaga medis atau tenaga kesehatan
mencakup penilaian pengetahuan, keterampilan, dan
perilaku peserta didik;

b.  dilaksanakan pada akhir masa pendidikan sebagai satu
kesatuan ujian yang menjadi dasar penentuan
kelulusan; dan

c. dilaksanakan oleh penyelenggara pendidikan tinggi
tenaga medis dan tenaga kesehatan bekerja sama
dengan kolegium sesuai tugas, fungsi, dan kewenangan
masing-masing.

Penyelenggara pendidikan tinggi tenaga medis dan tenaga
kesehatan sebagaimana dimaksud dalam Diktum KETIGA
huruf c ditetapkan oleh Menteri Pendidikan Tinggi, Sains,
dan Teknologi.

Kolegium sebagaimana dimaksud dalam Diktum KETIGA
huruf c merupakan kolegium yang disahkan oleh Menteri
Kesehatan untuk ditetapkan oleh Ketua Konsil Kesehatan
Indonesia.

KEENAM

KETUJUH

KEDELAPAN

KESEMBILAN

KESEPULUH

KESEBELAS

. 3.

Dalam rangka pelaksanaan uji kompetensi, penyelenggara
pendidikan tinggi sebagaimana dimaksud dalam Diktum
KEEMPAT dan kolegium sebagaimana dimaksud dalam
Diktum KELIMA membentuk tim ad hoc yang memiliki tugas:
a. menyusun petunjuk teknis penyelenggaraan uji
kompetensi;

menetapkan besaran biaya uji kompetensi;

menyusun soal uji kompetensi;

melaksanakan kegiatan uji kompetensi; dan
melaksanakan kegiatan dan/atau hal lain yang perlu
disepakati atau dibutuhkan dalam penyelenggaraan uji
kompetensi.

ono 5

Petunjuk teknis sebagaimana dimaksud dalam Diktum
KEENAM huruf a ditetapkan paling lama 1 (satu) bulan
terhitung sejak tanggal Keputusan Bersama ini ditetapkan
dan dapat diperbaharui sesuai kebutuhan.

Pembiayaan uji kompetensi dapat berasal dari:

a. biaya pendidikan;

b. anggaran Kementerian Pendidikan Tinggi, Sains dan
Teknologi;

c. anggaran Kementerian Kesehatan;

d. anggaran Konsil Kesehatan Indonesia; dan/atau

e. sumber lain yang sah,

sesuai dengan ketentuan peraturan perundang-undangan.

Pengelolaan pembiayaan uji kompetensi sebagaimana
dimaksud dalam Diktum KEDELAPAN  dilakukan
berdasarkan prinsip pengelolaan keuangan yang baik sesuai
dengan ketentuan peraturan perundang-undangan.

Pembinaan dan pengawasan  penyelenggaraan uji
kompetensi dilaksanakan bersama oleh Kementerian
Pendidikan Tinggi, Sains, dan Teknologi, Kementerian
Kesehatan, dan Konsil Kesehatan Indonesia, sesuai dengan
tugas, fungsi, dan kewenangan masing-masing.

Pada saat Keputusan Bersama ini mulai berlaku, uji
kompetensi tenaga medis dan tenaga kesehatan tetap
dilaksanakan sesuai dengan Surat Edaran Menteri
Kesehatan Nomor HK.02.01/MENKES/28/2025 tentang
Pelaksanaan Uji Kompetensi dan Penerbitan Sertifikat
Kompetensi Tenaga Medis dan Tenaga Kesehatan dan Surat
Edaran Menteri Pendidikan Tinggi, Sains, dan Teknologi
Nomor 1 Tahun 2025 tentang Kebijakan Transisi Uji
Kompetensi Nasional sampai dengan ditetapkan petunjuk
teknis berdasarkan Keputusan Bersama ini serta dinyatakan
sah dan diakui sesuai dengan ketentuan dalam Keputusan
Bersama ini.

2 Ae

KEDUABELAS : Pada saat Keputusan Bersama ini mulai berlaku:

a. Surat Edaran Menteri Kesehatan Nomor
HK.02.01/MENKES/28/2025 tentang Pelaksanaan Uji
Kompetensi dan Penerbitan Sertifikat Kompetensi
Tenaga Medis dan Tenaga Kesehatan; dan

b. Surat Edaran Menteri Pendidikan Tinggi, Sains, dan
Teknologi Nomor 1 Tahun 2025 tentang Kebijakan
Transisi Uji Kompetensi Nasional,

dicabut dan dinyatakan tidak berlaku.

KETIGABELAS : Keputusan Bersama ini mulai berlaku pada _ tanggal

ditetapkan.
Ditetapkan di Jakarta
pada tanggal 7 Oktober 2025
ER RENDIDIKAN TINGGI, <BBRI KESEHATAN
XN TEKNOLOGI K INDONESIA,

Blk INDONESIA,

LAMPIRAN
KEPUTUSAN BERSAMA MENTERI PENDIDIKAN
TINGGI, SAINS, DAN TEKNOLOGI DAN
MENTERI KESEHATAN REPUBLIK INDONESIA
NOMOR 4/M/KB/2025

NOMOR HK.01.08/MENKES/948/ 2025
TENTANG

STANDAR PROSEDUR OPERASIONAL  UUJI
KOMPETENSI SECARA NASIONAL  BAGI
PESERTA DIDIK PADA PENDIDIKAN VOKASI
DAN PENDIDIKAN PROFESI, DAN UuI
KOMPETENSI BERSTANDAR NASIONAL BAGI
PESERTA DIDIK PADA PENDIDIKAN PROFESI
PROGRAM SPESIALIS/SUBSPESIALIS TENAGA
MEDIS DAN TENAGA KESEHATAN

STANDAR PROSEDUR OPERASIONAL UJI KOMPETENSI SECARA NASIONAL
BAGI PESERTA DIDIK PADA PENDIDIKAN VOKASI DAN PENDIDIKAN
PROFESI, DAN UJI KOMPETENSI BERSTANDAR NASIONAL BAGI PESERTA
DIDIK PADA PENDIDIKAN PROFESI PROGRAM SPESIALIS/SUBSPESIALIS
TENAGA MEDIS DAN TENAGA KESEHATAN

BAB I
PENDAHULUAN

A. Latar Belakang

Sesuai dengan amanah Undang-Undang Nomor 17 Tahun 2023
tentang Kesehatan, dalam rangka penilaian pencapaian standar
kompetensi tenaga medis dan tenaga kesehatan, perlu diselenggarakan uji
kompetensi bagi tenaga medis dan tenaga kesehatan. Ketentuan Pasal 213
ayat (2) Undang-Undang Nomor 17 Tahun 2023 mengatur bahwa uji
kompetensi diselenggarakan oleh penyelenggara pendidikan tinggi bekerja
sama dengan kolegium. SPO Uji Kompetensi disusun untuk melaksanakan
ketentuan Pasal 591 ayat (5) Peraturan Pemerintah Nomor 28 Tahun 2024
tentang Peraturan Pelaksanaan Undang-Undang Nomor 17 Tahun 2023
tentang Kesehatan, sehingga perlu menetapkan Keputusan Bersama
Menteri Pendidikan Tinggi, Sains, dan Teknologi dan Menteri Kesehatan
tentang Standar Prosedur Operasional Uji Kompetensi Secara Nasional bagi
Peserta Didik pada Pendidikan Vokasi dan Pendidikan Profesi, dan Uji
Kompetensi Berstandar Nasional bagi Peserta Didik pada Pendidikan Profesi
Program Spesialis/Subspesialis Tenaga Medis dan Tenaga Kesehatan.

B. Tujuan Uji Kompetensi

1. Menilai pencapaian standar kompetensi tenaga medis dan tenaga
kesehatan yang disusun oleh kolegium dan ditetapkan oleh Menteri
Kesehatan, mencakup penilaian baik dalam aspek pengetahuan,
keterampilan, maupun sikap/perilaku.

2. Sebagai dasar penerbitan sertifikat kompetensi dan ijazah/sertifikat
profesi lulusan pendidikan tinggi tenaga medis dan tenaga kesehatan.

3. Memberikan umpan balik terhadap kualitas pendidikan tinggi tenaga
medis dan tenaga kesehatan untuk pengembangan maupun
pembinaan lebih lanjut.

A.

-2-

BABII
KEBIJAKAN DAN TATA KELOLA UJI KOMPETENSI

Kebijakan Pelaksanaan Uji Kompetensi

L.

Uji kompetensi harus dilakukan secara nasional atau berstandar

nasional.

a. Secara nasional artinya uji kompetensi peserta didik pada
pendidikan vokasi dan pendidikan profesi tenaga medis dan
tenaga kesehatan dilaksanakan serentak dalam waktu tertentu.
Hal ini terutama dilakukan untuk menjamin aspek validitas dan
reliabilitas dari hasil ujian karena dengan pelaksanaan nasional
memungkinkan peserta memenuhi syarat untuk perhitungan
berbagai parameter psikometrik dari suatu uji yang handal.
Pendidikan profesi yang dimaksud dalam ketentuan ini adalah
pendidikan profesi pada program profesi.

b. Berstandar nasional artinya uji kompetensi peserta didik pada
pendidikan profesi program spesialis/subspesialis tenaga medis
dan tenaga kesehatan yang berupa pengukuran pengetahuan,
keterampilan, dan perilaku peserta didik sesuai dengan standar
nasional dan berlaku secara nasional.

Peserta didik yang telah lulus uji kompetensi pada akhir masa

pendidikan vokasi dan pendidikan profesi tenaga medis dan tenaga

kesehatan memperoleh:

a.  sertifikat kompetensi yang diterbitkan oleh penyelenggara
pendidikan tinggi bekerja sama dengan kolegium; dan

b. ijazah/sertifikat profesi dan gelar dari perguruan tinggi.

Peserta didik yang telah lulus uji kompetensi pada akhir masa

pendidikan profesi program spesialis/subspesialis tenaga medis dan

tenaga kesehatan memperoleh:

a. sertifikat kompetensi yang diterbitkan oleh kolegium; dan

b. _ sertifikat profesi dan gelar dari perguruan tinggi bersama mitra
fasilitas pelayanan kesehatan atau Rumah Sakit Penyelenggara
Pendidikan Utama (RSPPU) bersama dengan mitra perguruan
tinggi.

Peserta didik yang tidak lulus uji kompetensi dapat mengikuti uji

kompetensi ulang sampai dengan batas maksimal masa studi sesuai

dengan ketentuan peraturan perundang-undangan.

Uji kompetensi yang baik dilaksanakan dengan memenuhi prinsip

metode uji berupa valid dan koheren, handal, konsisten, ekuivalen,

feasibilitas/mampu laksana, efek edukatif, efek katalik, penerimaan,
transparan, dan akuntabel.

Pelaksanaan uji kompetensi wajib menggunakan teknologi informasi

yang didukung oleh sistem dan teknologi yang handal, paling sedikit

meliputi fault tolerance, security, fraud resilience, concurrence,
interconnection quality, dan user friendliness.

Uji kompetensi meliputi penilaian aspek pengetahuan (kognitif),

keterampilan, dan sikap/perilaku profesional yang dilaksanakan

dalam dua bentuk, yaitu uji kognitif dan/atau uji berbasis performa

(performance-based).

Metode uji kognitif dapat digunakan untuk menilai pengetahuan

dengan menggunakan soal berbasis respon pilihan (selected-response

item), antara lain berupa Multiple Choice Questions (MCQ), Extended

Matching Questions (EMQ), dan Teslet yang merupakan bentuk yang

paling sering digunakan dan memiliki kehandalan serta kesahihan

yang baik dan dapat dipertanggungjawabkan.

-3-

Metode uji berbasis performa (performance-based) dapat digunakan
untuk menilai penguasaan keterampilan dan _ sikap/perilaku
profesional, antara lain berupa Objective Structured Clinical
Examination (OSCE), workplace based assesment, dan Mini Clinical
Evaluation Exercise (Mini-CEX) untuk menilai performa penguasaan
keterampilan klinis dan perilaku profesional.

B. Tata Kelola Penyelenggaraan Uji Kompetensi

1.

Bentuk kerja sama antara penyelenggara pendidikan tinggi dan

kolegium berupa kegiatan yang dilaksanakan dalam rangkaian uji

kompetensi, terdiri atas:

a. persiapan uji kompetensi;

b. pelaksanaan uji kompetensi; dan

c. pasca uji kompetensi.

Dalam rangka pelaksanaan uji kompetensi, penyelenggara pendidikan

tinggi dan kolegium membentuk tim ad hoc yang terdiri dari:

a. perwakilan ketua program studi ex officio untuk penyelenggara
pendidikan tinggi tenaga medis dan tenaga kesehatan; dan

b. perwakilan dari kolegium tiap disiplin ilmu untuk kolegium.

Susunan anggota tim ad hoc pada setiap kegiatan atau periode uji

kompetensi dapat diubah sesuai dengan kebutuhan.

Sistem Informasi

Sistem informasi uji kompetensi menggunakan sistem terintegrasi

yang dikelola bersama oleh penyelenggara pendidikan tinggi dan

kolegium, yang akan diatur pada petunjuk teknis.

Sistem informasi uji kompetensi memfasilitasi seluruh rangkaian uji

kompetensi, paling sedikit memuat:

a. pendaftaran peserta;

b. pengadaan soal (penulisan dan reviu) serta bank soal;

c. pelaksanaan ujian, dapat berupa CBT dan/atau OSCE, yang
terintegrasi dengan bank soal serta item analysis;

d. pengumuman kelulusan, serta pemberian umpan balik individu
dan institusi pendidikan; dan

e. penerbitan sertifikat kompetensi dan ijazah/sertifikat profesi
berdasarkan hasil kelulusan uji kompetensi.

Pembiayaan

a. Mekanisme pengelolaan pembiayaan uji kompetensi ditentukan
oleh penyelenggara pendidikan tinggi bekerja sama dengan
kolegium yang diatur pada petunjuk teknis.

b. Penetapan biaya uji kompetensi berdasarkan proses bisnis
penyelenggaraan uji kompetensi dan sesuai dengan ketentuan
yang berlaku.

-4-

BAB III
TATA CARA UJI KOMPETENSI

A. Cetak Biru dan Pengelolaan Soal Uji Kompetensi
1. Penyusunan Cetak Biru Uji Kompetensi

a) Cetak biru uji kompetensi disusun berdasarkan standar
kompetensi tenaga medis dan tenaga kesehatan.

b) Cetak biru disusun untuk uji kompetensi pengetahuan maupun
berbasis performa.

c) Cetak biru menentukan domain tinjauan kompetensi, jumlah,
dan jenis soal uji.

d)  Cetak biru uji kompetensi menjadi acuan untuk konten hasil uji
kompetensi yang diberikan kepada peserta uji kompetensi
sekaligus sebagai umpan balik performa peserta dan institusi
dalam pelaksanaan uji kompetensi.

e) Cetak biru ditinjau setiap tahun untuk disesuaikan dengan
pengembangan pengetahuan dan kompetensi.

2. Pengadaan Soal

a) Pengadaan soal uji kompetensi melalui kegiatan penulisan soal
yang dilakukan secara kontinyu dan/atau undangan khusus.

b) Penulisan soal uji kompetensi berdasarkan pada cetak biru dan
format penulisan soal.

c) Penulisan soal dilakukan oleh para penulis soal yang telah
tersertifikasi sebagai penulis soal uji kompetensi nasional.

d) Soal yang akan diujikan harus melalui proses reviu yang
dilakukan oleh para pereviu soal sesuai ketentuan.

e) Soal yang telah direviu dilakukan uji coba untuk memastikan
kesesuaian dengan kriteria soal, tingkat kesulitan, dan
diskriminan yang dapat diterima.

f) | Seluruh item soal harus dapat terjaga kerahasiaannya.

g) Soal yang telah dilakukan uji coba dapat digunakan sebagai
bahan kajian (expert review).

B. Kriteria Peserta Uji Kompetensi
1. peserta didik telah menyelesaikan seluruh tahapan pendidikan; dan
2. peserta didik yang mengikuti uji kompetensi harus masih aktif
terdaftar pada PDDikti.

C. Prosedur Pendaftaran

1. Peserta didik pada pendidikan vokasi dan pendidikan profesi yang
telah memenuhi kriteria didaftarkan oleh penyelenggara pendidikan
tinggi secara kolektif melalui sistem informasi uji kompetensi.

2. Peserta didik pada pendidikan profesi program spesialis/subspesialis
mendaftar secara mandiri pada sistem informasi uji kompetensi.

3.  Peserta didik yang telah terdaftar akan divalidasi oleh penyelenggara
pendidikan tinggi dan kolegium melalui sistem informasi uji
kompetensi.

4.  Peserta didik yang sudah dinyatakan lolos validasi akan diberikan
nomor peserta uji kompetensi setelah melakukan pembayaran biaya
uji kompetensi.

D. Jadwal Uji Kompetensi

1. Jadwal uji kompetensi disusun dengan mempertimbangkan kalender
akademik penyelenggara pendidikan tinggi.

- 5s

2. Jadwal uji kompetensi ditetapkan dan diumumkan secara terbuka
setiap akhir tahun untuk pelaksanaan uji kompetensi pada tahun
yang akan datang.

Tempat Uji Kompetensi

Uji kompetensi dilaksanakan pada tempat uji kompetensi di penyelenggara
pendidikan tinggi dan/atau tempat lainnya sesuai persyaratan yang
ditetapkan oleh tim ad hoc.

Penentuan Kelulusan dan Hasil Uji Kompetensi

1. Penentuan kelulusan uji kompetensi dilakukan dengan menggunakan
standar penentuan batas lulus (standard setting).

2. Hasil uji kompetensi diumumkan secara terbuka.

3. Hasil kelulusan uji kompetensi digunakan untuk kepentingan
penerbitan ijazah/sertifikat profesi, gelar, dan sertifikat kompetensi.

-6-

BAB IV

PENJAMINAN MUTU DAN PENGEMBANGAN SISTEMATIKA UJI KOMPETENSI

A. Penjaminan Mutu

Ls

2)

3.

Penjaminan mutu uji kompetensi menjadi bagian dari sistem
penjaminan mutu internal penyelenggara pendidikan tinggi.
Penjaminan mutu dilakukan dengan mengadopsi praktik baik sistem
penjaminan mutu lembaga layanan publik.

Penjaminan mutu dilakukan paling sedikit meliputi penetapan standar
mutu, organisasi mutu, evaluasi/audit, pengendalian, dan
peningkatan/tindak lanjut.

Penjaminan mutu dapat dilakukan dengan melibatkan stakeholder
eksternal untuk memantau implementasi standar mutu dalam
pengelolaan uji kompetensi.

Hasil penjaminan mutu dipublikasikan secara terbuka kepada
masyarakat.

B. Pengembangan Sistematika Uji Kompetensi
Sistematika uji kompetensi dapat dikembangkan dengan berbasis bukti
(evidence based) untuk menjaga implementasi prinsip asesmen berharkat
tinggi yang baik.

2 iJ 5

BAB V
KODE ETIK KOMPONEN PELAKSANA UJI KOMPETENSI

Seluruh individu dan institusi yang terlibat dalam pengelolaan dan pelaksanaan
uji kompetensi wajib menjunjung tinggi kode etik, tidak memiliki konflik
kepentingan, serta wajib menjaga kejujuran, kerahasiaan, dan keamanan
pelaksanaan uji kompetensi.

-8-

BAB VI
PENUTUP

Standar Prosedur Operasional ini ditetapkan sebagai acuan bagi penyelenggara
pendidikan tinggi, kolegium, peserta didik, dan pihak lain yang terkait dalam
penyelenggaraan uji kompetensi peserta didik, baik pada pendidikan vokasi dan
pendidikan profesi, maupun pendidikan profesi program spesialis/subspesialis
tenaga medis dan tenaga kesehatan. Penyelenggaraan uji kompetensi sesuai
dengan Standar Prosedur Operasional ini akan memberikan kejelasan dalam
proses penilaian pencapaian standar kompetensi tenaga medis dan tenaga
kesehatan.

AaB NLERI KESEHATAN
PURLIK INDONESIA,